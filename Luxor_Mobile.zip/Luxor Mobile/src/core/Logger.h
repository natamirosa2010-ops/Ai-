#pragma once

#include <QString>
#include <QFile>
#include <QMutex>
#include <QDateTime>
#include <QObject>

namespace Luxor {

enum class LogLevel {
    Debug,
    Info,
    Warning,
    Error
};

class Logger : public QObject {
    Q_OBJECT
public:
    static Logger& instance();

    void init(const QString& logDirPath = QString());
    void log(LogLevel level, const QString& category, const QString& message);

    static void debug(const QString& category, const QString& message) {
        instance().log(LogLevel::Debug, category, message);
    }
    static void info(const QString& category, const QString& message) {
        instance().log(LogLevel::Info, category, message);
    }
    static void warn(const QString& category, const QString& message) {
        instance().log(LogLevel::Warning, category, message);
    }
    static void error(const QString& category, const QString& message) {
        instance().log(LogLevel::Error, category, message);
    }

    QStringList getRecentLogs(int maxCount = 100);

    /** Routes qDebug/qWarning, QML warnings and console.* output into the same log file. */
    static void installQtMessageHandler();

signals:
    void logAdded(const QString& formattedLine, int level);

private:
    Logger() = default;
    ~Logger();
    Q_DISABLE_COPY(Logger)

    static QString sanitize(const QString& raw);

    QMutex m_mutex;
    QFile m_logFile;
    QStringList m_recentBuffer;
    bool m_initialized = false;
};

} // namespace Luxor
