#include "Logger.h"
#include <QStandardPaths>
#include <QDir>
#include <QTextStream>
#include <QRegularExpression>
#include <iostream>
#include <QMutexLocker>

namespace Luxor {

static thread_local bool t_inLog = false;   // set while Logger::log holds its mutex

static void luxorQtMessageHandler(QtMsgType type, const QMessageLogContext& ctx, const QString& msg) {
    if (t_inLog) {                           // Qt complained while the logger itself was writing: avoid deadlock
        std::cerr << msg.toUtf8().constData() << std::endl;
        return;
    }
    LogLevel level = LogLevel::Debug;
    switch (type) {
    case QtDebugMsg: level = LogLevel::Debug; break;
    case QtInfoMsg: level = LogLevel::Info; break;
    case QtWarningMsg: level = LogLevel::Warning; break;
    case QtCriticalMsg:
    case QtFatalMsg: level = LogLevel::Error; break;
    }
    QString text = msg;
    if (ctx.file && *ctx.file) text += QStringLiteral(" (%1:%2)").arg(QString::fromUtf8(ctx.file)).arg(ctx.line);
    const bool hasCategory = ctx.category && *ctx.category && qstrcmp(ctx.category, "default") != 0;
    Logger::instance().log(level, hasCategory ? QString::fromUtf8(ctx.category) : QStringLiteral("qt"), text);
}

void Logger::installQtMessageHandler() { qInstallMessageHandler(luxorQtMessageHandler); }

Logger& Logger::instance() {
    static Logger s_inst;
    return s_inst;
}

Logger::~Logger() {
    QMutexLocker locker(&m_mutex);
    if (m_logFile.isOpen()) {
        m_logFile.close();
    }
}

void Logger::init(const QString& logDirPath) {
    QMutexLocker locker(&m_mutex);
    if (m_initialized) return;

    QString dirPath = logDirPath;
    if (dirPath.isEmpty()) {
        dirPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/logs";
    }

    QDir dir(dirPath);
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    QString filePath = dir.filePath("luxor.log");
    m_logFile.setFileName(filePath);
    m_logFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
    m_initialized = true;
}

QString Logger::sanitize(const QString& raw) {
    QString clean = raw;
    // Redact standard API key patterns (Bearer ..., sk-..., etc.)
    static const QRegularExpression keyRegex(QStringLiteral("(?:sk-[a-zA-Z0-9_-]{10,}|Bearer\\s+[a-zA-Z0-9._-]{10,}|api[_-]?key[\"':\\s=]+[a-zA-Z0-9._-]{10,})"), QRegularExpression::CaseInsensitiveOption);
    clean.replace(keyRegex, QStringLiteral("[REDACTED_CREDENTIAL]"));
    return clean;
}

void Logger::log(LogLevel level, const QString& category, const QString& message) {
    QMutexLocker locker(&m_mutex);
    t_inLog = true;

    QString levelStr;
    switch (level) {
        case LogLevel::Debug: levelStr = QStringLiteral("DEBUG"); break;
        case LogLevel::Info: levelStr = QStringLiteral("INFO "); break;
        case LogLevel::Warning: levelStr = QStringLiteral("WARN "); break;
        case LogLevel::Error: levelStr = QStringLiteral("ERROR"); break;
    }

    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
    QString safeMessage = sanitize(message);
    QString formatted = QStringLiteral("[%1] [%2] [%3] %4")
                            .arg(timestamp, levelStr, category, safeMessage);

    if (m_logFile.isOpen()) {
        QTextStream out(&m_logFile);
        out << formatted << "\n";
        out.flush();
    }

    std::cout << formatted.toUtf8().constData() << std::endl;

    m_recentBuffer.append(formatted);
    while (m_recentBuffer.size() > 500) {
        m_recentBuffer.removeFirst();
    }

    t_inLog = false;
    locker.unlock();
    emit logAdded(formatted, static_cast<int>(level));
}

QStringList Logger::getRecentLogs(int maxCount) {
    QMutexLocker locker(&m_mutex);
    if (maxCount <= 0 || maxCount >= m_recentBuffer.size()) {
        return m_recentBuffer;
    }
    return m_recentBuffer.mid(m_recentBuffer.size() - maxCount);
}

} // namespace Luxor
