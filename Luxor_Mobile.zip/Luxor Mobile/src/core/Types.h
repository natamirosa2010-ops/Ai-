#pragma once

#include <QString>
#include <QStringList>
#include <QDateTime>
#include <QJsonObject>
#include <QJsonArray>
#include <QMetaType>

namespace Luxor {

enum class ThinkingMode {
    Weak = 0,    // Слабый: Minimal latency, straightforward questions/translations
    Medium = 1,  // Средний: Daily coding, doc analysis, small programs
    High = 2,    // Высокий: Complex architecture, bug finding, multi-step verification
    Ultra = 3    // Ультра: Deep verification, multi-stage PC interaction, self-auditing
};

enum class ModelId {
    Qwen = 0,
    Claw = 1,
    DeepSeekChat = 2,
    DeepSeekReasoner = 3,
    Qwen38_27B = 4
};

enum class MessageRole {
    System,
    User,
    Assistant,
    Tool
};

enum class AgentStatusType {
    Idle,
    Analyzing,       // Анализирует запрос...
    Searching,       // Выполняет поиск...
    ReadingFiles,    // Изучает файлы...
    WorkingWithPC,   // Работает с компьютером...
    RunningCommand,  // Выполняет команду...
    Verifying,       // Проверяет результат...
    PreparingAnswer, // Подготавливает ответ...
    Error
};

enum class PermissionLevel {
    ReadOnly = 0,        // Чтение файлов и информации без модификации
    ReadWrite = 1,       // Создание и изменение файлов в разрешённых папках
    PromptCommands = 2,  // Выполнение команд с обязательным подтверждением
    FullTrust = 3        // Расширенные полномочия (опасные операции всё равно проверяются)
};

struct FileAttachment {
    QString id;
    QString filePath;
    QString fileName;
    qint64 fileSizeBytes = 0;
    QString mimeType;
    bool isImage = false;
    QString previewBase64;
};

struct ToolCallRecord {
    QString callId;
    QString toolName;
    QJsonObject arguments;
    QString resultOutput;
    QString errorMessage;
    bool success = false;
    qint64 durationMs = 0;
    QDateTime timestamp;
};

struct SearchSource {
    QString title;
    QString url;
    QString snippet;
    QString date;
    QString sourceName;
};

struct ChatMessage {
    QString id;
    QString conversationId;
    MessageRole role = MessageRole::User;
    QString content;
    QString reasoningContent; // Chain-of-thought if provided by model (e.g. deepseek-reasoner)
    QDateTime timestamp;
    QList<FileAttachment> attachments;
    QList<ToolCallRecord> toolCalls;
    QList<SearchSource> sources;
    int tokenCount = 0;
    bool isStreaming = false;
};

struct Conversation {
    QString id;
    QString title;
    QDateTime createdAt;
    QDateTime updatedAt;
    QString modelName;
    ThinkingMode thinkingMode = ThinkingMode::Medium;
    int messageCount = 0;
};

struct AgentRuleItem {
    QString id;
    QString title;
    QString ruleText;
    bool isEnabled = true;
    QDateTime createdAt;
};

struct MemoryItem {
    QString id;
    QString key;
    QString value;
    QString category;
    QDateTime updatedAt;
};

struct AuditLogEntry {
    qint64 id = 0;
    QDateTime timestamp;
    QString conversationId;
    QString toolName;
    QString actionDescription;
    QString argumentsSummary;
    bool requiresConfirmation = false;
    bool userApproved = true;
    bool success = false;
    QString outcome;
    qint64 durationMs = 0;
};

// String conversion helpers
inline QString thinkingModeToString(ThinkingMode mode) {
    switch (mode) {
        case ThinkingMode::Weak: return QStringLiteral("Слабый");
        case ThinkingMode::Medium: return QStringLiteral("Средний");
        case ThinkingMode::High: return QStringLiteral("Высокий");
        case ThinkingMode::Ultra: return QStringLiteral("Ультра");
    }
    return QStringLiteral("Средний");
}

inline ThinkingMode stringToThinkingMode(const QString& str) {
    if (str == QStringLiteral("Слабый") || str.toLower() == QStringLiteral("weak")) return ThinkingMode::Weak;
    if (str == QStringLiteral("Высокий") || str.toLower() == QStringLiteral("high")) return ThinkingMode::High;
    if (str == QStringLiteral("Ультра") || str.toLower() == QStringLiteral("ultra")) return ThinkingMode::Ultra;
    return ThinkingMode::Medium;
}

inline QString modelIdToString(ModelId model) {
    switch (model) {
        case ModelId::Qwen: return QStringLiteral("qwen");
        case ModelId::Claw: return QStringLiteral("claw");
        case ModelId::DeepSeekChat: return QStringLiteral("deepseek-chat");
        case ModelId::DeepSeekReasoner: return QStringLiteral("deepseek-reasoner");
        case ModelId::Qwen38_27B: return QStringLiteral("qwen3.8-27b");
    }
    return QStringLiteral("deepseek-chat");
}

inline ModelId stringToModelId(const QString& str) {
    if (str == QStringLiteral("qwen")) return ModelId::Qwen;
    if (str == QStringLiteral("claw")) return ModelId::Claw;
    if (str == QStringLiteral("deepseek-reasoner")) return ModelId::DeepSeekReasoner;
    if (str == QStringLiteral("qwen3.8-27b")) return ModelId::Qwen38_27B;
    return ModelId::DeepSeekChat;
}

inline QString statusTypeToString(AgentStatusType status) {
    switch (status) {
        case AgentStatusType::Idle: return QStringLiteral("");
        case AgentStatusType::Analyzing: return QStringLiteral("Анализирует запрос...");
        case AgentStatusType::Searching: return QStringLiteral("Выполняет поиск...");
        case AgentStatusType::ReadingFiles: return QStringLiteral("Изучает файлы...");
        case AgentStatusType::WorkingWithPC: return QStringLiteral("Работает с компьютером...");
        case AgentStatusType::RunningCommand: return QStringLiteral("Выполняет команду...");
        case AgentStatusType::Verifying: return QStringLiteral("Проверяет результат...");
        case AgentStatusType::PreparingAnswer: return QStringLiteral("Подготавливает ответ...");
        case AgentStatusType::Error: return QStringLiteral("Ошибка выполнения");
    }
    return QString();
}

} // namespace Luxor

Q_DECLARE_METATYPE(Luxor::ThinkingMode)
Q_DECLARE_METATYPE(Luxor::ModelId)
Q_DECLARE_METATYPE(Luxor::AgentStatusType)
Q_DECLARE_METATYPE(Luxor::PermissionLevel)
