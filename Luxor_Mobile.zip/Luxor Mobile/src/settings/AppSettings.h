#pragma once

#include <QObject>
#include <QSettings>
#include <QString>
#include <QStringList>
#include "../core/Types.h"
#include "../security/CredentialStore.h"

namespace Luxor {

class AppSettings : public QObject {
    Q_OBJECT

    // 1. General
    Q_PROPERTY(QString language READ language WRITE setLanguage NOTIFY languageChanged)
    Q_PROPERTY(bool startWithWindows READ startWithWindows WRITE setStartWithWindows NOTIFY startWithWindowsChanged)
    Q_PROPERTY(bool minimizeToTray READ minimizeToTray WRITE setMinimizeToTray NOTIFY minimizeToTrayChanged)

    // 2. AI & Models
    Q_PROPERTY(QString defaultModel READ defaultModel WRITE setDefaultModel NOTIFY defaultModelChanged)
    Q_PROPERTY(double temperature READ temperature WRITE setTemperature NOTIFY temperatureChanged)
    Q_PROPERTY(double topP READ topP WRITE setTopP NOTIFY topPChanged)
    Q_PROPERTY(int maxTokens READ maxTokens WRITE setMaxTokens NOTIFY maxTokensChanged)

    // 3. API
    Q_PROPERTY(QString apiBaseUrl READ apiBaseUrl WRITE setApiBaseUrl NOTIFY apiBaseUrlChanged)
    Q_PROPERTY(bool hasApiKey READ hasApiKey NOTIFY apiKeyChanged)

    // 4. Thinking Modes
    Q_PROPERTY(int defaultThinkingMode READ defaultThinkingMode WRITE setDefaultThinkingMode NOTIFY defaultThinkingModeChanged)
    Q_PROPERTY(int ultraModeMaxIterations READ ultraModeMaxIterations WRITE setUltraModeMaxIterations NOTIFY ultraModeMaxIterationsChanged)


    // 7. Voice
    Q_PROPERTY(QString voiceInputLanguage READ voiceInputLanguage WRITE setVoiceInputLanguage NOTIFY voiceInputLanguageChanged)
    Q_PROPERTY(QString voiceInputDevice READ voiceInputDevice WRITE setVoiceInputDevice NOTIFY voiceInputDeviceChanged)
    Q_PROPERTY(bool voiceStreaming READ voiceStreaming WRITE setVoiceStreaming NOTIFY voiceStreamingChanged)

    // 8. Search
    Q_PROPERTY(QString defaultSearchEngine READ defaultSearchEngine WRITE setDefaultSearchEngine NOTIFY defaultSearchEngineChanged)
    Q_PROPERTY(bool searchEnabled READ searchEnabled WRITE setSearchEnabled NOTIFY searchEnabledChanged)
    Q_PROPERTY(int maxSearchResults READ maxSearchResults WRITE setMaxSearchResults NOTIFY maxSearchResultsChanged)

    // 9. Attachments
    Q_PROPERTY(int maxAttachmentSizeMb READ maxAttachmentSizeMb WRITE setMaxAttachmentSizeMb NOTIFY maxAttachmentSizeMbChanged)
    Q_PROPERTY(bool autoResizeImages READ autoResizeImages WRITE setAutoResizeImages NOTIFY autoResizeImagesChanged)

    // 10. Appearance
    Q_PROPERTY(QString theme READ theme WRITE setTheme NOTIFY themeChanged)
    Q_PROPERTY(QString accentColor READ accentColor WRITE setAccentColor NOTIFY accentColorChanged)
    Q_PROPERTY(double uiScale READ uiScale WRITE setUiScale NOTIFY uiScaleChanged)
    Q_PROPERTY(int fontSize READ fontSize WRITE setFontSize NOTIFY fontSizeChanged)

    // 11. Animations
    Q_PROPERTY(bool animationsEnabled READ animationsEnabled WRITE setAnimationsEnabled NOTIFY animationsEnabledChanged)
    Q_PROPERTY(double animationSpeed READ animationSpeed WRITE setAnimationSpeed NOTIFY animationSpeedChanged)
    // Profile / start screen
    Q_PROPERTY(QString userName READ userName WRITE setUserName NOTIFY userNameChanged)
    Q_PROPERTY(bool introSeen READ introSeen WRITE setIntroSeen NOTIFY introSeenChanged)

    // 12. History & Memory
    Q_PROPERTY(bool memoryEnabled READ memoryEnabled WRITE setMemoryEnabled NOTIFY memoryEnabledChanged)
    Q_PROPERTY(int contextHistoryLimit READ contextHistoryLimit WRITE setContextHistoryLimit NOTIFY contextHistoryLimitChanged)

    // 13. Privacy
    Q_PROPERTY(bool telemetryEnabled READ telemetryEnabled WRITE setTelemetryEnabled NOTIFY telemetryEnabledChanged)
    Q_PROPERTY(bool localAuditLogsOnly READ localAuditLogsOnly WRITE setLocalAuditLogsOnly NOTIFY localAuditLogsOnlyChanged)

    // 14. Performance
    Q_PROPERTY(int maxConcurrentTasks READ maxConcurrentTasks WRITE setMaxConcurrentTasks NOTIFY maxConcurrentTasksChanged)
    Q_PROPERTY(int networkTimeoutSec READ networkTimeoutSec WRITE setNetworkTimeoutSec NOTIFY networkTimeoutSecChanged)
    Q_PROPERTY(bool streamingEnabled READ streamingEnabled WRITE setStreamingEnabled NOTIFY streamingEnabledChanged)

public:
    static AppSettings& instance();

    // API Key handled securely through CredentialStore
    Q_INVOKABLE bool setApiKey(const QString& key);
    Q_INVOKABLE QString getApiKey();
    Q_INVOKABLE void clearApiKey();

    // Getters and Setters
    QString language() const; void setLanguage(const QString& val);
    bool startWithWindows() const; void setStartWithWindows(bool val);
    bool minimizeToTray() const; void setMinimizeToTray(bool val);

    QString defaultModel() const; void setDefaultModel(const QString& val);
    double temperature() const; void setTemperature(double val);
    double topP() const; void setTopP(double val);
    int maxTokens() const; void setMaxTokens(int val);

    QString apiBaseUrl() const; void setApiBaseUrl(const QString& val);
    bool hasApiKey() const;

    int defaultThinkingMode() const; void setDefaultThinkingMode(int val);
    int ultraModeMaxIterations() const; void setUltraModeMaxIterations(int val);


    QString voiceInputLanguage() const; void setVoiceInputLanguage(const QString& val);
    QString voiceInputDevice() const; void setVoiceInputDevice(const QString& val);
    bool voiceStreaming() const; void setVoiceStreaming(bool val);

    QString defaultSearchEngine() const; void setDefaultSearchEngine(const QString& val);
    bool searchEnabled() const; void setSearchEnabled(bool val);
    int maxSearchResults() const; void setMaxSearchResults(int val);

    int maxAttachmentSizeMb() const; void setMaxAttachmentSizeMb(int val);
    bool autoResizeImages() const; void setAutoResizeImages(bool val);

    QString theme() const; void setTheme(const QString& val);
    QString accentColor() const; void setAccentColor(const QString& val);
    double uiScale() const; void setUiScale(double val);
    int fontSize() const; void setFontSize(int val);

    bool animationsEnabled() const; void setAnimationsEnabled(bool val);
    double animationSpeed() const; void setAnimationSpeed(double val);
    QString userName() const; void setUserName(const QString& val);
    bool introSeen() const; void setIntroSeen(bool val);

    bool memoryEnabled() const; void setMemoryEnabled(bool val);
    int contextHistoryLimit() const; void setContextHistoryLimit(int val);

    bool telemetryEnabled() const; void setTelemetryEnabled(bool val);
    bool localAuditLogsOnly() const; void setLocalAuditLogsOnly(bool val);

    int maxConcurrentTasks() const; void setMaxConcurrentTasks(int val);
    int networkTimeoutSec() const; void setNetworkTimeoutSec(int val);
    bool streamingEnabled() const; void setStreamingEnabled(bool val);

signals:
    void languageChanged();
    void startWithWindowsChanged();
    void minimizeToTrayChanged();

    void defaultModelChanged();
    void temperatureChanged();
    void topPChanged();
    void maxTokensChanged();

    void apiBaseUrlChanged();
    void apiKeyChanged();

    void defaultThinkingModeChanged();
    void ultraModeMaxIterationsChanged();


    void voiceInputLanguageChanged();
    void voiceInputDeviceChanged();
    void voiceStreamingChanged();

    void defaultSearchEngineChanged();
    void searchEnabledChanged();
    void maxSearchResultsChanged();

    void maxAttachmentSizeMbChanged();
    void autoResizeImagesChanged();

    void themeChanged();
    void accentColorChanged();
    void uiScaleChanged();
    void fontSizeChanged();

    void animationsEnabledChanged();
    void animationSpeedChanged();
    void userNameChanged();
    void introSeenChanged();

    void memoryEnabledChanged();
    void contextHistoryLimitChanged();

    void telemetryEnabledChanged();
    void localAuditLogsOnlyChanged();

    void maxConcurrentTasksChanged();
    void networkTimeoutSecChanged();
    void streamingEnabledChanged();

private:
    AppSettings();
    ~AppSettings() = default;
    Q_DISABLE_COPY(AppSettings)

    QSettings m_settings;
};

} // namespace Luxor
