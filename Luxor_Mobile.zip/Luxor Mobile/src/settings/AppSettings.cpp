#include "AppSettings.h"
#include <QCoreApplication>
#include <QDir>

namespace Luxor {

AppSettings& AppSettings::instance() {
    static AppSettings s_inst;
    return s_inst;
}

AppSettings::AppSettings()
    : m_settings(QSettings::IniFormat, QSettings::UserScope, "LuxorAI", "LuxorDesktop")
{
}

bool AppSettings::setApiKey(const QString& key) {
    bool ok = CredentialStore::storeSecret("sjtu_api_key", key);
    emit apiKeyChanged();
    return ok;
}

QString AppSettings::getApiKey() {
    return CredentialStore::getSecret("sjtu_api_key");
}

void AppSettings::clearApiKey() {
    CredentialStore::removeSecret("sjtu_api_key");
    emit apiKeyChanged();
}

bool AppSettings::hasApiKey() const {
    return CredentialStore::hasSecret("sjtu_api_key");
}

// 1. General
QString AppSettings::language() const { return m_settings.value("general/language", "ru").toString(); }
void AppSettings::setLanguage(const QString& val) { m_settings.setValue("general/language", val); emit languageChanged(); }

bool AppSettings::startWithWindows() const { return m_settings.value("general/startWithWindows", false).toBool(); }
void AppSettings::setStartWithWindows(bool val) { m_settings.setValue("general/startWithWindows", val); emit startWithWindowsChanged(); }

bool AppSettings::minimizeToTray() const { return m_settings.value("general/minimizeToTray", false).toBool(); }
void AppSettings::setMinimizeToTray(bool val) { m_settings.setValue("general/minimizeToTray", val); emit minimizeToTrayChanged(); }

// 2. AI & Models
QString AppSettings::defaultModel() const { return m_settings.value("ai/defaultModel", "deepseek-chat").toString(); }
void AppSettings::setDefaultModel(const QString& val) { m_settings.setValue("ai/defaultModel", val); emit defaultModelChanged(); }

double AppSettings::temperature() const { return m_settings.value("ai/temperature", 0.7).toDouble(); }
void AppSettings::setTemperature(double val) { m_settings.setValue("ai/temperature", val); emit temperatureChanged(); }

double AppSettings::topP() const { return m_settings.value("ai/topP", 0.95).toDouble(); }
void AppSettings::setTopP(double val) { m_settings.setValue("ai/topP", val); emit topPChanged(); }

int AppSettings::maxTokens() const { return m_settings.value("ai/maxTokens", 4096).toInt(); }
void AppSettings::setMaxTokens(int val) { m_settings.setValue("ai/maxTokens", val); emit maxTokensChanged(); }

// 3. API
QString AppSettings::apiBaseUrl() const { return m_settings.value("api/baseUrl", "https://models.sjtu.edu.cn/api/v1").toString(); }
void AppSettings::setApiBaseUrl(const QString& val) { m_settings.setValue("api/baseUrl", val); emit apiBaseUrlChanged(); }

// 4. Thinking Modes
int AppSettings::defaultThinkingMode() const { return m_settings.value("thinking/defaultMode", static_cast<int>(ThinkingMode::Medium)).toInt(); }
void AppSettings::setDefaultThinkingMode(int val) { m_settings.setValue("thinking/defaultMode", val); emit defaultThinkingModeChanged(); }

int AppSettings::ultraModeMaxIterations() const { return m_settings.value("thinking/ultraIterations", 8).toInt(); }
void AppSettings::setUltraModeMaxIterations(int val) { m_settings.setValue("thinking/ultraIterations", val); emit ultraModeMaxIterationsChanged(); }

// 7. Voice
QString AppSettings::voiceInputLanguage() const { return m_settings.value("voice/language", "ru").toString(); }
void AppSettings::setVoiceInputLanguage(const QString& val) { m_settings.setValue("voice/language", val); emit voiceInputLanguageChanged(); }

QString AppSettings::voiceInputDevice() const { return m_settings.value("voice/device", "default").toString(); }
void AppSettings::setVoiceInputDevice(const QString& val) { m_settings.setValue("voice/device", val); emit voiceInputDeviceChanged(); }

bool AppSettings::voiceStreaming() const { return m_settings.value("voice/streaming", true).toBool(); }
void AppSettings::setVoiceStreaming(bool val) { m_settings.setValue("voice/streaming", val); emit voiceStreamingChanged(); }

// 8. Search
QString AppSettings::defaultSearchEngine() const { return m_settings.value("search/engine", "duckduckgo").toString(); }
void AppSettings::setDefaultSearchEngine(const QString& val) { m_settings.setValue("search/engine", val); emit defaultSearchEngineChanged(); }

bool AppSettings::searchEnabled() const { return m_settings.value("search/enabled", true).toBool(); }
void AppSettings::setSearchEnabled(bool val) { m_settings.setValue("search/enabled", val); emit searchEnabledChanged(); }

int AppSettings::maxSearchResults() const { return m_settings.value("search/maxResults", 5).toInt(); }
void AppSettings::setMaxSearchResults(int val) { m_settings.setValue("search/maxResults", val); emit maxSearchResultsChanged(); }

// 9. Attachments
int AppSettings::maxAttachmentSizeMb() const { return m_settings.value("attachments/maxSizeMb", 25).toInt(); }
void AppSettings::setMaxAttachmentSizeMb(int val) { m_settings.setValue("attachments/maxSizeMb", val); emit maxAttachmentSizeMbChanged(); }

bool AppSettings::autoResizeImages() const { return m_settings.value("attachments/autoResize", true).toBool(); }
void AppSettings::setAutoResizeImages(bool val) { m_settings.setValue("attachments/autoResize", val); emit autoResizeImagesChanged(); }

// 10. Appearance
QString AppSettings::theme() const { return m_settings.value("appearance/theme", "dark").toString(); }
void AppSettings::setTheme(const QString& val) { m_settings.setValue("appearance/theme", val); emit themeChanged(); }

QString AppSettings::accentColor() const { return m_settings.value("appearance/accentColor", "#6366F1").toString(); }
void AppSettings::setAccentColor(const QString& val) { m_settings.setValue("appearance/accentColor", val); emit accentColorChanged(); }

double AppSettings::uiScale() const { return m_settings.value("appearance/uiScale", 1.0).toDouble(); }
void AppSettings::setUiScale(double val) { m_settings.setValue("appearance/uiScale", val); emit uiScaleChanged(); }

int AppSettings::fontSize() const { return m_settings.value("appearance/fontSize", 14).toInt(); }
void AppSettings::setFontSize(int val) { m_settings.setValue("appearance/fontSize", val); emit fontSizeChanged(); }

// 11. Animations
bool AppSettings::animationsEnabled() const { return m_settings.value("animations/enabled", true).toBool(); }
void AppSettings::setAnimationsEnabled(bool val) { m_settings.setValue("animations/enabled", val); emit animationsEnabledChanged(); }

double AppSettings::animationSpeed() const { return m_settings.value("animations/speed", 1.0).toDouble(); }
void AppSettings::setAnimationSpeed(double val) { m_settings.setValue("animations/speed", val); emit animationSpeedChanged(); }

// Profile / start screen
QString AppSettings::userName() const { return m_settings.value("profile/userName", QString()).toString(); }
void AppSettings::setUserName(const QString& val) {
    const QString v = val.simplified().left(40);
    if (v == userName()) return;
    m_settings.setValue("profile/userName", v);
    emit userNameChanged();
}

bool AppSettings::introSeen() const { return m_settings.value("profile/introSeen", false).toBool(); }
void AppSettings::setIntroSeen(bool val) {
    if (val == introSeen()) return;
    m_settings.setValue("profile/introSeen", val);
    emit introSeenChanged();
}

// 12. History & Memory
bool AppSettings::memoryEnabled() const { return m_settings.value("memory/enabled", true).toBool(); }
void AppSettings::setMemoryEnabled(bool val) { m_settings.setValue("memory/enabled", val); emit memoryEnabledChanged(); }

int AppSettings::contextHistoryLimit() const { return m_settings.value("memory/historyLimit", 20).toInt(); }
void AppSettings::setContextHistoryLimit(int val) { m_settings.setValue("memory/historyLimit", val); emit contextHistoryLimitChanged(); }

// 13. Privacy
bool AppSettings::telemetryEnabled() const { return m_settings.value("privacy/telemetry", false).toBool(); }
void AppSettings::setTelemetryEnabled(bool val) { m_settings.setValue("privacy/telemetry", val); emit telemetryEnabledChanged(); }

bool AppSettings::localAuditLogsOnly() const { return m_settings.value("privacy/localAuditOnly", true).toBool(); }
void AppSettings::setLocalAuditLogsOnly(bool val) { m_settings.setValue("privacy/localAuditOnly", val); emit localAuditLogsOnlyChanged(); }

// 14. Performance
int AppSettings::maxConcurrentTasks() const { return m_settings.value("performance/maxConcurrent", 4).toInt(); }
void AppSettings::setMaxConcurrentTasks(int val) { m_settings.setValue("performance/maxConcurrent", val); emit maxConcurrentTasksChanged(); }

int AppSettings::networkTimeoutSec() const { return m_settings.value("performance/timeoutSec", 45).toInt(); }
void AppSettings::setNetworkTimeoutSec(int val) { m_settings.setValue("performance/timeoutSec", val); emit networkTimeoutSecChanged(); }

bool AppSettings::streamingEnabled() const { return m_settings.value("performance/streaming", true).toBool(); }
void AppSettings::setStreamingEnabled(bool val) { m_settings.setValue("performance/streaming", val); emit streamingEnabledChanged(); }

} // namespace Luxor
