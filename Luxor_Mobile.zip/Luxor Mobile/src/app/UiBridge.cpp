#include "UiBridge.h"
#include <QClipboard>
#include <QCoreApplication>
#include <QDesktopServices>
#include <QDir>
#include <QGuiApplication>
#include <QStandardPaths>
#include <QUrl>

namespace Luxor {

UiBridge::UiBridge(QObject* parent) : QObject(parent) {}

QString UiBridge::appVersion() const { return QCoreApplication::applicationVersion(); }

void UiBridge::copyToClipboard(const QString& text) const {
    if (QClipboard* cb = QGuiApplication::clipboard()) cb->setText(text);
}

QString UiBridge::systemUserName() const {
#if defined(Q_OS_ANDROID) || defined(Q_OS_IOS)
    return QString();   // no meaningful account name on a phone
#else
    QString n = qEnvironmentVariable("USERNAME");
    if (n.isEmpty()) n = qEnvironmentVariable("USER");
    return n;
#endif
}

QString UiBridge::logFilePath() const {
    return QDir::toNativeSeparators(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
                                    + QStringLiteral("/logs/luxor.log"));
}

void UiBridge::openLogFolder() const {
    QDesktopServices::openUrl(QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
                                                  + QStringLiteral("/logs")));
}

} // namespace Luxor
