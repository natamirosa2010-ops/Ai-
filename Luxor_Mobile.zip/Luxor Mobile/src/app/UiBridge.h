#pragma once

#include <QObject>
#include <QString>

namespace Luxor {

/** Small QML helpers that Qt Quick does not provide on its own ("uiBridge" in QML). */
class UiBridge : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString appVersion READ appVersion CONSTANT)
public:
    explicit UiBridge(QObject* parent = nullptr);

    QString appVersion() const;

    Q_INVOKABLE void copyToClipboard(const QString& text) const;
    /** Windows account name (%USERNAME%), used only as a suggestion for the nickname. */
    Q_INVOKABLE QString systemUserName() const;
    Q_INVOKABLE QString logFilePath() const;
    Q_INVOKABLE void openLogFolder() const;
};

} // namespace Luxor
