#include "ConversationDao.h"
#include "DatabaseManager.h"
#include "../core/Logger.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

namespace Luxor {

QString ConversationDao::serializeAttachments(const QList<FileAttachment>& list) {
    QJsonArray arr;
    for (const auto& att : list) {
        QJsonObject obj;
        obj["id"] = att.id;
        obj["filePath"] = att.filePath;
        obj["fileName"] = att.fileName;
        obj["fileSizeBytes"] = att.fileSizeBytes;
        obj["mimeType"] = att.mimeType;
        obj["isImage"] = att.isImage;
        obj["previewBase64"] = att.previewBase64;
        arr.append(obj);
    }
    return QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact));
}

QList<FileAttachment> ConversationDao::deserializeAttachments(const QString& json) {
    QList<FileAttachment> result;
    if (json.isEmpty()) return result;
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isArray()) return result;
    for (const auto& val : doc.array()) {
        QJsonObject obj = val.toObject();
        FileAttachment att;
        att.id = obj["id"].toString();
        att.filePath = obj["filePath"].toString();
        att.fileName = obj["fileName"].toString();
        att.fileSizeBytes = obj["fileSizeBytes"].toInteger();
        att.mimeType = obj["mimeType"].toString();
        att.isImage = obj["isImage"].toBool();
        att.previewBase64 = obj["previewBase64"].toString();
        result.append(att);
    }
    return result;
}

QString ConversationDao::serializeToolCalls(const QList<ToolCallRecord>& list) {
    QJsonArray arr;
    for (const auto& tc : list) {
        QJsonObject obj;
        obj["callId"] = tc.callId;
        obj["toolName"] = tc.toolName;
        obj["arguments"] = tc.arguments;
        obj["resultOutput"] = tc.resultOutput;
        obj["errorMessage"] = tc.errorMessage;
        obj["success"] = tc.success;
        obj["durationMs"] = tc.durationMs;
        obj["timestamp"] = tc.timestamp.toString(Qt::ISODateWithMs);
        arr.append(obj);
    }
    return QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact));
}

QList<ToolCallRecord> ConversationDao::deserializeToolCalls(const QString& json) {
    QList<ToolCallRecord> result;
    if (json.isEmpty()) return result;
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isArray()) return result;
    for (const auto& val : doc.array()) {
        QJsonObject obj = val.toObject();
        ToolCallRecord tc;
        tc.callId = obj["callId"].toString();
        tc.toolName = obj["toolName"].toString();
        tc.arguments = obj["arguments"].toObject();
        tc.resultOutput = obj["resultOutput"].toString();
        tc.errorMessage = obj["errorMessage"].toString();
        tc.success = obj["success"].toBool();
        tc.durationMs = obj["durationMs"].toInteger();
        tc.timestamp = QDateTime::fromString(obj["timestamp"].toString(), Qt::ISODateWithMs);
        result.append(tc);
    }
    return result;
}

QString ConversationDao::serializeSources(const QList<SearchSource>& list) {
    QJsonArray arr;
    for (const auto& s : list) {
        QJsonObject obj;
        obj["title"] = s.title;
        obj["url"] = s.url;
        obj["snippet"] = s.snippet;
        obj["date"] = s.date;
        obj["sourceName"] = s.sourceName;
        arr.append(obj);
    }
    return QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact));
}

QList<SearchSource> ConversationDao::deserializeSources(const QString& json) {
    QList<SearchSource> result;
    if (json.isEmpty()) return result;
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isArray()) return result;
    for (const auto& val : doc.array()) {
        QJsonObject obj = val.toObject();
        SearchSource s;
        s.title = obj["title"].toString();
        s.url = obj["url"].toString();
        s.snippet = obj["snippet"].toString();
        s.date = obj["date"].toString();
        s.sourceName = obj["sourceName"].toString();
        result.append(s);
    }
    return result;
}

bool ConversationDao::createConversation(const Conversation& conv) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        INSERT INTO conversations (id, title, model, thinking_mode, created_at, updated_at)
        VALUES (:id, :title, :model, :thinking_mode, :created_at, :updated_at)
    )");
    q.bindValue(":id", conv.id);
    q.bindValue(":title", conv.title);
    q.bindValue(":model", conv.modelName);
    q.bindValue(":thinking_mode", static_cast<int>(conv.thinkingMode));
    q.bindValue(":created_at", conv.createdAt.toString(Qt::ISODateWithMs));
    q.bindValue(":updated_at", conv.updatedAt.toString(Qt::ISODateWithMs));

    if (!q.exec()) {
        Logger::error("ConversationDao", "Failed to create conversation: " + q.lastError().text());
        return false;
    }
    return true;
}

bool ConversationDao::updateConversationTitle(const QString& convId, const QString& newTitle) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE conversations SET title = :title, updated_at = :updated_at WHERE id = :id");
    q.bindValue(":title", newTitle);
    q.bindValue(":updated_at", QDateTime::currentDateTime().toString(Qt::ISODateWithMs));
    q.bindValue(":id", convId);
    return q.exec();
}

bool ConversationDao::updateConversationModel(const QString& convId, const QString& modelName, ThinkingMode mode) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE conversations SET model = :model, thinking_mode = :mode, updated_at = :updated_at WHERE id = :id");
    q.bindValue(":model", modelName);
    q.bindValue(":mode", static_cast<int>(mode));
    q.bindValue(":updated_at", QDateTime::currentDateTime().toString(Qt::ISODateWithMs));
    q.bindValue(":id", convId);
    return q.exec();
}

bool ConversationDao::updateConversationTimestamp(const QString& convId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE conversations SET updated_at = :updated_at WHERE id = :id");
    q.bindValue(":updated_at", QDateTime::currentDateTime().toString(Qt::ISODateWithMs));
    q.bindValue(":id", convId);
    return q.exec();
}

bool ConversationDao::deleteConversation(const QString& convId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("DELETE FROM conversations WHERE id = :id");
    q.bindValue(":id", convId);
    return q.exec();
}

std::optional<Conversation> ConversationDao::getConversation(const QString& convId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("SELECT id, title, model, thinking_mode, created_at, updated_at FROM conversations WHERE id = :id");
    q.bindValue(":id", convId);
    if (q.exec() && q.next()) {
        Conversation c;
        c.id = q.value(0).toString();
        c.title = q.value(1).toString();
        c.modelName = q.value(2).toString();
        c.thinkingMode = static_cast<ThinkingMode>(q.value(3).toInt());
        c.createdAt = QDateTime::fromString(q.value(4).toString(), Qt::ISODateWithMs);
        c.updatedAt = QDateTime::fromString(q.value(5).toString(), Qt::ISODateWithMs);
        c.messageCount = getMessageCount(c.id);
        return c;
    }
    return std::nullopt;
}

QList<Conversation> ConversationDao::getAllConversations() {
    QList<Conversation> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.exec(R"(
        SELECT c.id, c.title, c.model, c.thinking_mode, c.created_at, c.updated_at, COUNT(m.id) as msg_count
        FROM conversations c
        LEFT JOIN messages m ON c.id = m.conversation_id
        GROUP BY c.id
        ORDER BY c.updated_at DESC
    )");
    while (q.next()) {
        Conversation c;
        c.id = q.value(0).toString();
        c.title = q.value(1).toString();
        c.modelName = q.value(2).toString();
        c.thinkingMode = static_cast<ThinkingMode>(q.value(3).toInt());
        c.createdAt = QDateTime::fromString(q.value(4).toString(), Qt::ISODateWithMs);
        c.updatedAt = QDateTime::fromString(q.value(5).toString(), Qt::ISODateWithMs);
        c.messageCount = q.value(6).toInt();
        list.append(c);
    }
    return list;
}

bool ConversationDao::addMessage(const ChatMessage& msg) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        INSERT INTO messages (id, conversation_id, role, content, reasoning_content, timestamp, attachments_json, tool_calls_json, sources_json, token_count)
        VALUES (:id, :conversation_id, :role, :content, :reasoning_content, :timestamp, :attachments_json, :tool_calls_json, :sources_json, :token_count)
    )");

    QString roleStr = "user";
    if (msg.role == MessageRole::Assistant) roleStr = "assistant";
    else if (msg.role == MessageRole::System) roleStr = "system";
    else if (msg.role == MessageRole::Tool) roleStr = "tool";

    q.bindValue(":id", msg.id);
    q.bindValue(":conversation_id", msg.conversationId);
    q.bindValue(":role", roleStr);
    q.bindValue(":content", msg.content);
    q.bindValue(":reasoning_content", msg.reasoningContent);
    q.bindValue(":timestamp", msg.timestamp.toString(Qt::ISODateWithMs));
    q.bindValue(":attachments_json", serializeAttachments(msg.attachments));
    q.bindValue(":tool_calls_json", serializeToolCalls(msg.toolCalls));
    q.bindValue(":sources_json", serializeSources(msg.sources));
    q.bindValue(":token_count", msg.tokenCount);

    if (!q.exec()) {
        Logger::error("ConversationDao", "Failed to insert message: " + q.lastError().text());
        return false;
    }
    updateConversationTimestamp(msg.conversationId);
    return true;
}

bool ConversationDao::updateMessageContent(const QString& msgId, const QString& content, const QString& reasoningContent) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE messages SET content = :content, reasoning_content = :reasoning WHERE id = :id");
    q.bindValue(":content", content);
    q.bindValue(":reasoning", reasoningContent);
    q.bindValue(":id", msgId);
    return q.exec();
}

bool ConversationDao::deleteMessage(const QString& msgId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("DELETE FROM messages WHERE id = :id");
    q.bindValue(":id", msgId);
    return q.exec();
}

QList<ChatMessage> ConversationDao::getMessages(const QString& convId, int limit, int offset) {
    QList<ChatMessage> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        SELECT id, conversation_id, role, content, reasoning_content, timestamp, attachments_json, tool_calls_json, sources_json, token_count
        FROM messages
        WHERE conversation_id = :convId
        ORDER BY timestamp ASC, rowid ASC
        LIMIT :limit OFFSET :offset
    )");
    q.bindValue(":convId", convId);
    q.bindValue(":limit", limit);
    q.bindValue(":offset", offset);

    if (q.exec()) {
        while (q.next()) {
            ChatMessage msg;
            msg.id = q.value(0).toString();
            msg.conversationId = q.value(1).toString();
            QString roleStr = q.value(2).toString();
            if (roleStr == "assistant") msg.role = MessageRole::Assistant;
            else if (roleStr == "system") msg.role = MessageRole::System;
            else if (roleStr == "tool") msg.role = MessageRole::Tool;
            else msg.role = MessageRole::User;

            msg.content = q.value(3).toString();
            msg.reasoningContent = q.value(4).toString();
            msg.timestamp = QDateTime::fromString(q.value(5).toString(), Qt::ISODateWithMs);
            msg.attachments = deserializeAttachments(q.value(6).toString());
            msg.toolCalls = deserializeToolCalls(q.value(7).toString());
            msg.sources = deserializeSources(q.value(8).toString());
            msg.tokenCount = q.value(9).toInt();
            list.append(msg);
        }
    }
    return list;
}

int ConversationDao::getMessageCount(const QString& convId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("SELECT COUNT(*) FROM messages WHERE conversation_id = :convId");
    q.bindValue(":convId", convId);
    if (q.exec() && q.next()) {
        return q.value(0).toInt();
    }
    return 0;
}

QList<ChatMessage> ConversationDao::searchMessages(const QString& queryText) {
    QList<ChatMessage> list;
    if (queryText.trimmed().isEmpty()) return list;

    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        SELECT id, conversation_id, role, content, reasoning_content, timestamp, attachments_json, tool_calls_json, sources_json, token_count
        FROM messages
        WHERE content LIKE :pattern OR reasoning_content LIKE :pattern
        ORDER BY timestamp DESC
        LIMIT 50
    )");
    q.bindValue(":pattern", "%" + queryText + "%");

    if (q.exec()) {
        while (q.next()) {
            ChatMessage msg;
            msg.id = q.value(0).toString();
            msg.conversationId = q.value(1).toString();
            QString roleStr = q.value(2).toString();
            if (roleStr == "assistant") msg.role = MessageRole::Assistant;
            else if (roleStr == "system") msg.role = MessageRole::System;
            else if (roleStr == "tool") msg.role = MessageRole::Tool;
            else msg.role = MessageRole::User;

            msg.content = q.value(3).toString();
            msg.reasoningContent = q.value(4).toString();
            msg.timestamp = QDateTime::fromString(q.value(5).toString(), Qt::ISODateWithMs);
            list.append(msg);
        }
    }
    return list;
}

} // namespace Luxor
