#include "RulesDao.h"
#include "DatabaseManager.h"
#include "../core/Logger.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QUuid>

namespace Luxor {

bool RulesDao::addRule(const AgentRuleItem& rule) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        INSERT INTO agent_rules (id, title, rule_text, is_enabled, created_at)
        VALUES (:id, :title, :rule_text, :is_enabled, :created_at)
    )");
    q.bindValue(":id", rule.id.isEmpty() ? QUuid::createUuid().toString(QUuid::WithoutBraces) : rule.id);
    q.bindValue(":title", rule.title);
    q.bindValue(":rule_text", rule.ruleText);
    q.bindValue(":is_enabled", rule.isEnabled ? 1 : 0);
    q.bindValue(":created_at", rule.createdAt.isValid() ? rule.createdAt.toString(Qt::ISODateWithMs) : QDateTime::currentDateTime().toString(Qt::ISODateWithMs));

    if (!q.exec()) {
        Logger::error("RulesDao", "Failed to add agent rule: " + q.lastError().text());
        return false;
    }
    return true;
}

bool RulesDao::updateRule(const AgentRuleItem& rule) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE agent_rules SET title = :title, rule_text = :rule_text, is_enabled = :is_enabled WHERE id = :id");
    q.bindValue(":title", rule.title);
    q.bindValue(":rule_text", rule.ruleText);
    q.bindValue(":is_enabled", rule.isEnabled ? 1 : 0);
    q.bindValue(":id", rule.id);
    return q.exec();
}

bool RulesDao::toggleRuleEnabled(const QString& ruleId, bool isEnabled) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("UPDATE agent_rules SET is_enabled = :is_enabled WHERE id = :id");
    q.bindValue(":is_enabled", isEnabled ? 1 : 0);
    q.bindValue(":id", ruleId);
    return q.exec();
}

bool RulesDao::deleteRule(const QString& ruleId) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("DELETE FROM agent_rules WHERE id = :id");
    q.bindValue(":id", ruleId);
    return q.exec();
}

QList<AgentRuleItem> RulesDao::getAllRules() {
    QList<AgentRuleItem> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    if (q.exec("SELECT id, title, rule_text, is_enabled, created_at FROM agent_rules ORDER BY created_at ASC")) {
        while (q.next()) {
            AgentRuleItem r;
            r.id = q.value(0).toString();
            r.title = q.value(1).toString();
            r.ruleText = q.value(2).toString();
            r.isEnabled = q.value(3).toInt() == 1;
            r.createdAt = QDateTime::fromString(q.value(4).toString(), Qt::ISODateWithMs);
            list.append(r);
        }
    }
    return list;
}

QList<AgentRuleItem> RulesDao::getActiveRules() {
    QList<AgentRuleItem> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    if (q.exec("SELECT id, title, rule_text, is_enabled, created_at FROM agent_rules WHERE is_enabled = 1 ORDER BY created_at ASC")) {
        while (q.next()) {
            AgentRuleItem r;
            r.id = q.value(0).toString();
            r.title = q.value(1).toString();
            r.ruleText = q.value(2).toString();
            r.isEnabled = true;
            r.createdAt = QDateTime::fromString(q.value(4).toString(), Qt::ISODateWithMs);
            list.append(r);
        }
    }
    return list;
}

QString RulesDao::getCombinedActiveRulesPrompt() {
    QList<AgentRuleItem> active = getActiveRules();
    if (active.isEmpty()) return QString();

    QStringList rules;
    for (const auto& r : active) {
        rules.append(QStringLiteral("- %1: %2").arg(r.title, r.ruleText));
    }
    return QStringLiteral("\n\n### ПОЛЬЗОВАТЕЛЬСКИЕ ПРАВИЛА АГЕНТА (СТРОГО СОБЛЮДАТЬ):\n%1\n").arg(rules.join("\n"));
}

void RulesDao::seedDefaultRulesIfEmpty() {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.exec("SELECT COUNT(*) FROM agent_rules");
    if (q.next() && q.value(0).toInt() == 0) {
        addRule({
            "",
            QStringLiteral("Безопасность файлов"),
            QStringLiteral("Перед изменением или перезаписью исходного кода создавай резервную копию."),
            true,
            QDateTime::currentDateTime()
        });
        addRule({
            "",
            QStringLiteral("Верификация изменений"),
            QStringLiteral("Всегда проверяй изменения после редактирования и форматирования кода."),
            true,
            QDateTime::currentDateTime()
        });
        addRule({
            "",
            QStringLiteral("Системная безопасность"),
            QStringLiteral("Не изменяй системные настройки Windows и системные файлы C:/Windows без разрешения."),
            true,
            QDateTime::currentDateTime()
        });
    }
}

} // namespace Luxor
