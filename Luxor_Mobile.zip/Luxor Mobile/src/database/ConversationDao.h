#pragma once

#include <QString>
#include <QList>
#include <optional>
#include "../core/Types.h"

namespace Luxor {

class ConversationDao {
public:
    static bool createConversation(const Conversation& conv);
    static bool updateConversationTitle(const QString& convId, const QString& newTitle);
    static bool updateConversationModel(const QString& convId, const QString& modelName, ThinkingMode mode);
    static bool updateConversationTimestamp(const QString& convId);
    static bool deleteConversation(const QString& convId);
    static std::optional<Conversation> getConversation(const QString& convId);
    static QList<Conversation> getAllConversations();

    static bool addMessage(const ChatMessage& msg);
    static bool updateMessageContent(const QString& msgId, const QString& content, const QString& reasoningContent = QString());
    static bool deleteMessage(const QString& msgId);
    static QList<ChatMessage> getMessages(const QString& convId, int limit = 100, int offset = 0);
    static int getMessageCount(const QString& convId);
    static QList<ChatMessage> searchMessages(const QString& queryText);

private:
    static QString serializeAttachments(const QList<FileAttachment>& list);
    static QList<FileAttachment> deserializeAttachments(const QString& json);
    static QString serializeToolCalls(const QList<ToolCallRecord>& list);
    static QList<ToolCallRecord> deserializeToolCalls(const QString& json);
    static QString serializeSources(const QList<SearchSource>& list);
    static QList<SearchSource> deserializeSources(const QString& json);
};

} // namespace Luxor
