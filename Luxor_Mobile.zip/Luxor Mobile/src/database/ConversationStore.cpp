#include "ConversationStore.h"
#include "ConversationDao.h"
#include "../core/Logger.h"
#include <QDateTime>
#include <QRegularExpression>
#include <QSet>
#include <QUuid>

namespace Luxor {

namespace {
QString newId() { return QUuid::createUuid().toString(QUuid::WithoutBraces); }

QString collapse(const QString& s) {
    static const QRegularExpression ws(QStringLiteral("\\s+"));
    QString t = s;
    t.replace(ws, QStringLiteral(" "));
    return t.trimmed();
}

QString snippetAround(const QString& text, const QString& query) {
    const QString flat = collapse(text);
    const int pos = flat.indexOf(query, 0, Qt::CaseInsensitive);
    if (pos < 0) return flat.left(80);
    const int start = qMax(0, pos - 30);
    QString s = flat.mid(start, 90);
    if (start > 0) s.prepend(QStringLiteral("…"));
    if (start + 90 < flat.size()) s.append(QStringLiteral("…"));
    return s;
}
} // namespace

QString ConversationStore::makeTitle(const QString& firstPrompt) {
    QString t = collapse(firstPrompt);
    if (t.isEmpty()) return QStringLiteral("Новый чат");
    constexpr int kMax = 48;
    if (t.size() > kMax) {
        t = t.left(kMax);
        const int lastSpace = t.lastIndexOf(QLatin1Char(' '));
        if (lastSpace > kMax / 2) t = t.left(lastSpace);
        t = t.trimmed() + QStringLiteral("…");
    }
    return t;
}

QString ConversationStore::createConversation(const QString& firstPrompt, const QString& model, ThinkingMode mode) {
    Conversation c;
    c.id = newId();
    c.title = makeTitle(firstPrompt);
    c.modelName = model;
    c.thinkingMode = mode;
    c.createdAt = QDateTime::currentDateTime();
    c.updatedAt = c.createdAt;
    if (!ConversationDao::createConversation(c)) {
        Logger::warn("ConversationStore", "Conversation not persisted (database unavailable?)");
        return QString();
    }
    return c.id;
}

bool ConversationStore::appendMessage(const QString& convId, ChatMessage& msg) {
    if (convId.isEmpty()) return false;
    if (msg.id.isEmpty()) msg.id = newId();
    if (!msg.timestamp.isValid()) msg.timestamp = QDateTime::currentDateTime();
    msg.conversationId = convId;
    return ConversationDao::addMessage(msg);
}

bool ConversationStore::updateMessage(const ChatMessage& msg) {
    if (msg.id.isEmpty()) return false;
    const bool ok = ConversationDao::updateMessageContent(msg.id, msg.content, msg.reasoningContent);
    if (ok && !msg.conversationId.isEmpty()) ConversationDao::updateConversationTimestamp(msg.conversationId);
    return ok;
}

bool ConversationStore::removeMessages(const QStringList& messageIds) {
    bool ok = true;
    for (const QString& id : messageIds) {
        if (!id.isEmpty() && !ConversationDao::deleteMessage(id)) ok = false;
    }
    return ok;
}

QList<ChatMessage> ConversationStore::loadMessages(const QString& convId) {
    QList<ChatMessage> out;
    if (convId.isEmpty()) return out;
    const QList<ChatMessage> all = ConversationDao::getMessages(convId, 100000, 0);
    for (const ChatMessage& m : all) {
        if (m.role == MessageRole::User || m.role == MessageRole::Assistant) out.append(m);
    }
    return out;
}

QVariantMap ConversationStore::toVariant(const Conversation& c) {
    QVariantMap v;
    v[QStringLiteral("id")] = c.id;
    v[QStringLiteral("title")] = c.title;
    v[QStringLiteral("updatedAt")] = c.updatedAt.isValid() ? c.updatedAt.toMSecsSinceEpoch() : qint64(0);
    v[QStringLiteral("model")] = c.modelName;
    v[QStringLiteral("messageCount")] = c.messageCount;
    return v;
}

QVariantList ConversationStore::listConversations() {
    QVariantList list;
    for (const Conversation& c : ConversationDao::getAllConversations()) list << toVariant(c);
    return list;
}

QVariantList ConversationStore::search(const QString& query) {
    QVariantList out;
    const QString q = query.trimmed();
    if (q.isEmpty()) return out;

    QSet<QString> seen;
    const QList<Conversation> all = ConversationDao::getAllConversations();
    for (const Conversation& c : all) {
        if (c.title.contains(q, Qt::CaseInsensitive)) {
            QVariantMap v = toVariant(c);
            v[QStringLiteral("snippet")] = QString();
            out << v;
            seen.insert(c.id);
        }
    }
    for (const ChatMessage& m : ConversationDao::searchMessages(q)) {
        if (seen.contains(m.conversationId)) continue;
        for (const Conversation& c : all) {
            if (c.id != m.conversationId) continue;
            QVariantMap v = toVariant(c);
            v[QStringLiteral("snippet")] = snippetAround(m.content, q);
            out << v;
            seen.insert(c.id);
            break;
        }
    }
    return out;
}

bool ConversationStore::rename(const QString& convId, const QString& title) {
    const QString t = collapse(title).left(120);
    if (convId.isEmpty() || t.isEmpty()) return false;
    return ConversationDao::updateConversationTitle(convId, t);
}

bool ConversationStore::remove(const QString& convId) {
    if (convId.isEmpty()) return false;
    return ConversationDao::deleteConversation(convId);
}

QString ConversationStore::titleOf(const QString& convId) {
    const auto c = ConversationDao::getConversation(convId);
    return c ? c->title : QString();
}

} // namespace Luxor
