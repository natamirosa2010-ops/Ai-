#pragma once

#include <QSqlDatabase>
#include <QMutex>
#include <QString>

namespace Luxor {

class DatabaseManager {
public:
    static DatabaseManager& instance();

    bool init(const QString& dbFilePath = QString());
    void close();

    QSqlDatabase getDatabase();

    bool executeMigrations();

private:
    DatabaseManager() = default;
    ~DatabaseManager();
    Q_DISABLE_COPY(DatabaseManager)

    QMutex m_mutex;
    QString m_connectionName;
    bool m_initialized = false;
};

} // namespace Luxor
