#include "MemoryDao.h"
#include "DatabaseManager.h"
#include "../core/Logger.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QUuid>

namespace Luxor {

bool MemoryDao::setMemory(const QString& key, const QString& value, const QString& category) {
    if (key.trimmed().isEmpty()) return false;

    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        INSERT INTO memory (id, key, value, category, updated_at)
        VALUES (:id, :key, :value, :category, :updated_at)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            category = excluded.category,
            updated_at = excluded.updated_at
    )");
    q.bindValue(":id", QUuid::createUuid().toString(QUuid::WithoutBraces));
    q.bindValue(":key", key.trimmed());
    q.bindValue(":value", value);
    q.bindValue(":category", category);
    q.bindValue(":updated_at", QDateTime::currentDateTime().toString(Qt::ISODateWithMs));

    if (!q.exec()) {
        Logger::error("MemoryDao", "Failed to set memory: " + q.lastError().text());
        return false;
    }
    return true;
}

QString MemoryDao::getMemory(const QString& key) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("SELECT value FROM memory WHERE key = :key");
    q.bindValue(":key", key.trimmed());
    if (q.exec() && q.next()) {
        return q.value(0).toString();
    }
    return QString();
}

bool MemoryDao::deleteMemory(const QString& key) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare("DELETE FROM memory WHERE key = :key");
    q.bindValue(":key", key.trimmed());
    return q.exec();
}

bool MemoryDao::clearAllMemory() {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    return q.exec("DELETE FROM memory;");
}

QList<MemoryItem> MemoryDao::getAllMemory() {
    QList<MemoryItem> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    if (q.exec("SELECT id, key, value, category, updated_at FROM memory ORDER BY updated_at DESC")) {
        while (q.next()) {
            MemoryItem m;
            m.id = q.value(0).toString();
            m.key = q.value(1).toString();
            m.value = q.value(2).toString();
            m.category = q.value(3).toString();
            m.updatedAt = QDateTime::fromString(q.value(4).toString(), Qt::ISODateWithMs);
            list.append(m);
        }
    }
    return list;
}

QString MemoryDao::getFormattedMemoryPrompt() {
    QList<MemoryItem> items = getAllMemory();
    if (items.isEmpty()) return QString();

    QStringList lines;
    for (const auto& item : items) {
        lines.append(QStringLiteral("- [%1] %2: %3").arg(item.category, item.key, item.value));
    }
    return QStringLiteral("\n\n### ДОЛГОВРЕМЕННАЯ ПАМЯТЬ АГЕНТА О ПОЛЬЗОВАТЕЛЕ И ПРОЕКТЕ:\n%1\n").arg(lines.join("\n"));
}

} // namespace Luxor
