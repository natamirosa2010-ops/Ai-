#pragma once

#include <QString>
#include <QList>
#include "../core/Types.h"

namespace Luxor {

class MemoryDao {
public:
    static bool setMemory(const QString& key, const QString& value, const QString& category = QStringLiteral("general"));
    static QString getMemory(const QString& key);
    static bool deleteMemory(const QString& key);
    static bool clearAllMemory();
    static QList<MemoryItem> getAllMemory();
    static QString getFormattedMemoryPrompt();
};

} // namespace Luxor
