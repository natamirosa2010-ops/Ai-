#include "DatabaseManager.h"
#include "../core/Logger.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QStandardPaths>
#include <QDir>
#include <QThread>
#include <QMutexLocker>

namespace Luxor {

DatabaseManager& DatabaseManager::instance() {
    static DatabaseManager s_inst;
    return s_inst;
}

DatabaseManager::~DatabaseManager() {
    close();
}

void DatabaseManager::close() {
    QMutexLocker locker(&m_mutex);
    if (m_initialized) {
        QSqlDatabase db = QSqlDatabase::database(m_connectionName);
        if (db.isOpen()) {
            db.close();
        }
        QSqlDatabase::removeDatabase(m_connectionName);
        m_initialized = false;
    }
}

bool DatabaseManager::init(const QString& dbFilePath) {
    QMutexLocker locker(&m_mutex);
    if (m_initialized) return true;

    QString finalPath = dbFilePath;
    if (finalPath.isEmpty()) {
        QString appData = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir dir(appData);
        if (!dir.exists()) {
            dir.mkpath(".");
        }
        finalPath = dir.filePath("luxor.db");
    }

    m_connectionName = QStringLiteral("luxor_db_conn_%1").arg(reinterpret_cast<quintptr>(QThread::currentThreadId()));
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    db.setDatabaseName(finalPath);

    if (!db.open()) {
        Logger::error("DatabaseManager", "Failed to open SQLite database: " + db.lastError().text());
        return false;
    }

    // Configure SQLite for high concurrency and performance
    QSqlQuery pragma(db);
    pragma.exec("PRAGMA journal_mode = WAL;");
    pragma.exec("PRAGMA synchronous = NORMAL;");
    pragma.exec("PRAGMA foreign_keys = ON;");
    pragma.exec("PRAGMA temp_store = MEMORY;");

    m_initialized = true;
    Logger::info("DatabaseManager", "SQLite database opened at: " + finalPath);

    return executeMigrations();
}

QSqlDatabase DatabaseManager::getDatabase() {
    QMutexLocker locker(&m_mutex);
    return QSqlDatabase::database(m_connectionName);
}

bool DatabaseManager::executeMigrations() {
    QSqlDatabase db = getDatabase();
    QSqlQuery q(db);

    // Conversations table
    bool ok = q.exec(R"(
        CREATE TABLE IF NOT EXISTS conversations (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            model TEXT NOT NULL,
            thinking_mode INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
    )");
    if (!ok) {
        Logger::error("DatabaseManager", "Failed creating conversations table: " + q.lastError().text());
        return false;
    }

    // Messages table
    ok = q.exec(R"(
        CREATE TABLE IF NOT EXISTS messages (
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            reasoning_content TEXT,
            timestamp TEXT NOT NULL,
            attachments_json TEXT,
            tool_calls_json TEXT,
            sources_json TEXT,
            token_count INTEGER DEFAULT 0,
            FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        );
    )");
    if (!ok) {
        Logger::error("DatabaseManager", "Failed creating messages table: " + q.lastError().text());
        return false;
    }

    // Create index on conversation_id
    q.exec("CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, timestamp);");

    // Agent Rules table
    ok = q.exec(R"(
        CREATE TABLE IF NOT EXISTS agent_rules (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            rule_text TEXT NOT NULL,
            is_enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
    )");
    if (!ok) {
        Logger::error("DatabaseManager", "Failed creating agent_rules table: " + q.lastError().text());
        return false;
    }

    // Long-term Memory table
    ok = q.exec(R"(
        CREATE TABLE IF NOT EXISTS memory (
            id TEXT PRIMARY KEY,
            key TEXT UNIQUE NOT NULL,
            value TEXT NOT NULL,
            category TEXT,
            updated_at TEXT NOT NULL
        );
    )");
    if (!ok) {
        Logger::error("DatabaseManager", "Failed creating memory table: " + q.lastError().text());
        return false;
    }

    // Audit Log table
    ok = q.exec(R"(
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            conversation_id TEXT,
            tool_name TEXT NOT NULL,
            action_desc TEXT,
            args_json TEXT,
            requires_confirmation INTEGER DEFAULT 0,
            user_approved INTEGER DEFAULT 1,
            success INTEGER NOT NULL,
            outcome TEXT,
            duration_ms INTEGER DEFAULT 0
        );
    )");
    if (!ok) {
        Logger::error("DatabaseManager", "Failed creating audit_log table: " + q.lastError().text());
        return false;
    }

    Logger::info("DatabaseManager", "All database tables and indices verified successfully.");
    return true;
}

} // namespace Luxor
