#pragma once

#include <QString>
#include <QList>
#include "../core/Types.h"

namespace Luxor {

class RulesDao {
public:
    static bool addRule(const AgentRuleItem& rule);
    static bool updateRule(const AgentRuleItem& rule);
    static bool toggleRuleEnabled(const QString& ruleId, bool isEnabled);
    static bool deleteRule(const QString& ruleId);
    static QList<AgentRuleItem> getAllRules();
    static QList<AgentRuleItem> getActiveRules();
    static QString getCombinedActiveRulesPrompt();

    // Seeds sensible default agent rules if table is empty
    static void seedDefaultRulesIfEmpty();
};

} // namespace Luxor
