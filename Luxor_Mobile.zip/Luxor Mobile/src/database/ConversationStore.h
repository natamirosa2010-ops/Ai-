#pragma once

#include <QString>
#include <QStringList>
#include <QVariantList>
#include <QVariantMap>
#include <QList>
#include "../core/Types.h"

namespace Luxor {

/**
 * Chat persistence used by ChatEngine (thin, stateless layer over ConversationDao).
 * Every method is safe to call when the database is unavailable: it returns
 * false / an empty value and the chat keeps working in memory.
 */
class ConversationStore {
public:
    /** One-line title from the first prompt (whitespace collapsed, max 48 chars + "…"). */
    static QString makeTitle(const QString& firstPrompt);

    /** Creates a conversation row; returns its id or an empty string on failure. */
    static QString createConversation(const QString& firstPrompt, const QString& model, ThinkingMode mode);

    /** Inserts the message (assigns id / timestamp if missing, sets conversationId). */
    static bool appendMessage(const QString& convId, ChatMessage& msg);
    static bool updateMessage(const ChatMessage& msg);
    static bool removeMessages(const QStringList& messageIds);

    /** All user/assistant messages of a conversation in chronological order. */
    static QList<ChatMessage> loadMessages(const QString& convId);

    /** [{id, title, updatedAt (ms since epoch), model, messageCount}] newest first. */
    static QVariantList listConversations();
    /** Title matches first, then message-content matches: [{id, title, updatedAt, snippet}]. */
    static QVariantList search(const QString& query);

    static bool rename(const QString& convId, const QString& title);
    static bool remove(const QString& convId);
    static QString titleOf(const QString& convId);

    static QVariantMap toVariant(const Conversation& c);
};

} // namespace Luxor
