#include "AuditLogDao.h"
#include "DatabaseManager.h"
#include "../core/Logger.h"
#include <QSqlQuery>
#include <QSqlError>

namespace Luxor {

bool AuditLogDao::logAction(const AuditLogEntry& entry) {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    q.prepare(R"(
        INSERT INTO audit_log (timestamp, conversation_id, tool_name, action_desc, args_json, requires_confirmation, user_approved, success, outcome, duration_ms)
        VALUES (:timestamp, :conversation_id, :tool_name, :action_desc, :args_json, :requires_confirmation, :user_approved, :success, :outcome, :duration_ms)
    )");
    q.bindValue(":timestamp", entry.timestamp.isValid() ? entry.timestamp.toString(Qt::ISODateWithMs) : QDateTime::currentDateTime().toString(Qt::ISODateWithMs));
    q.bindValue(":conversation_id", entry.conversationId);
    q.bindValue(":tool_name", entry.toolName);
    q.bindValue(":action_desc", entry.actionDescription);
    q.bindValue(":args_json", entry.argumentsSummary);
    q.bindValue(":requires_confirmation", entry.requiresConfirmation ? 1 : 0);
    q.bindValue(":user_approved", entry.userApproved ? 1 : 0);
    q.bindValue(":success", entry.success ? 1 : 0);
    q.bindValue(":outcome", entry.outcome);
    q.bindValue(":duration_ms", entry.durationMs);

    if (!q.exec()) {
        Logger::error("AuditLogDao", "Failed to record audit log: " + q.lastError().text());
        return false;
    }
    return true;
}

QList<AuditLogEntry> AuditLogDao::getRecentLogs(int limit, const QString& conversationId) {
    QList<AuditLogEntry> list;
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);

    if (!conversationId.isEmpty()) {
        q.prepare(R"(
            SELECT id, timestamp, conversation_id, tool_name, action_desc, args_json, requires_confirmation, user_approved, success, outcome, duration_ms
            FROM audit_log
            WHERE conversation_id = :convId
            ORDER BY id DESC
            LIMIT :limit
        )");
        q.bindValue(":convId", conversationId);
        q.bindValue(":limit", limit);
    } else {
        q.prepare(R"(
            SELECT id, timestamp, conversation_id, tool_name, action_desc, args_json, requires_confirmation, user_approved, success, outcome, duration_ms
            FROM audit_log
            ORDER BY id DESC
            LIMIT :limit
        )");
        q.bindValue(":limit", limit);
    }

    if (q.exec()) {
        while (q.next()) {
            AuditLogEntry e;
            e.id = q.value(0).toLongLong();
            e.timestamp = QDateTime::fromString(q.value(1).toString(), Qt::ISODateWithMs);
            e.conversationId = q.value(2).toString();
            e.toolName = q.value(3).toString();
            e.actionDescription = q.value(4).toString();
            e.argumentsSummary = q.value(5).toString();
            e.requiresConfirmation = q.value(6).toInt() == 1;
            e.userApproved = q.value(7).toInt() == 1;
            e.success = q.value(8).toInt() == 1;
            e.outcome = q.value(9).toString();
            e.durationMs = q.value(10).toLongLong();
            list.append(e);
        }
    }
    return list;
}

bool AuditLogDao::clearLogs() {
    QSqlDatabase db = DatabaseManager::instance().getDatabase();
    QSqlQuery q(db);
    return q.exec("DELETE FROM audit_log;");
}

} // namespace Luxor
