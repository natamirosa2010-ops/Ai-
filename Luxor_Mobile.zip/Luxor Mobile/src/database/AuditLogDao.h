#pragma once

#include <QString>
#include <QList>
#include "../core/Types.h"

namespace Luxor {

class AuditLogDao {
public:
    static bool logAction(const AuditLogEntry& entry);
    static QList<AuditLogEntry> getRecentLogs(int limit = 50, const QString& conversationId = QString());
    static bool clearLogs();
};

} // namespace Luxor
