#include "CredentialStore.h"
#include "../core/Logger.h"

#ifdef Q_OS_WIN
#include <windows.h>
#include <wincrypt.h>
#pragma comment(lib, "Crypt32.lib")
#endif

#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QCryptographicHash>

namespace Luxor {

#ifndef Q_OS_WIN
static QByteArray mask(const QByteArray& in, const QString& keyName) {
    const QByteArray k = QCryptographicHash::hash(keyName.toUtf8() + "luxor-mobile", QCryptographicHash::Sha256);
    QByteArray out = in;
    for (int i = 0; i < out.size(); ++i) out[i] = char(out[i] ^ k[i % k.size()]);
    return out;
}
#endif

QString CredentialStore::getStoreFilePath(const QString& keyName) {
    QString appData = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(appData + "/secure");
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    QByteArray hash = QCryptographicHash::hash(keyName.toUtf8(), QCryptographicHash::Sha256).toHex();
    return dir.filePath(QString::fromUtf8(hash) + ".dat");
}

bool CredentialStore::storeSecret(const QString& keyName, const QString& secret) {
#ifdef Q_OS_WIN
    if (keyName.isEmpty()) return false;

    QByteArray rawData = secret.toUtf8();
    DATA_BLOB dataIn;
    dataIn.pbData = reinterpret_cast<BYTE*>(rawData.data());
    dataIn.cbData = static_cast<DWORD>(rawData.size());

    DATA_BLOB dataOut;
    // DPAPI CryptProtectData encrypts using the current logged-in Windows user master key
    if (!CryptProtectData(&dataIn, L"LuxorSecureSecret", nullptr, nullptr, nullptr, 0, &dataOut)) {
        Logger::error("CredentialStore", "Failed to encrypt secret via Windows DPAPI");
        return false;
    }

    QByteArray encrypted(reinterpret_cast<const char*>(dataOut.pbData), static_cast<qsizetype>(dataOut.cbData));
    LocalFree(dataOut.pbData);

    QString path = getStoreFilePath(keyName);
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        Logger::error("CredentialStore", "Failed to open credential file for writing: " + path);
        return false;
    }
    file.write(encrypted);
    file.close();

    Logger::info("CredentialStore", "Secret securely encrypted and stored for key: " + keyName);
    return true;
#else
    // Android/iOS: app-private sandbox storage (not readable by other apps). XOR-masked so the key is not plain text on disk.
    if (keyName.isEmpty()) return false;
    QFile file(getStoreFilePath(keyName));
    if (!file.open(QIODevice::WriteOnly)) return false;
    file.write(mask(secret.toUtf8(), keyName));
    return true;
#endif
}

QString CredentialStore::getSecret(const QString& keyName) {
#ifdef Q_OS_WIN
    QString path = getStoreFilePath(keyName);
    QFile file(path);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        return QString();
    }

    QByteArray encrypted = file.readAll();
    file.close();

    DATA_BLOB dataIn;
    dataIn.pbData = reinterpret_cast<BYTE*>(encrypted.data());
    dataIn.cbData = static_cast<DWORD>(encrypted.size());

    DATA_BLOB dataOut;
    if (!CryptUnprotectData(&dataIn, nullptr, nullptr, nullptr, nullptr, 0, &dataOut)) {
        Logger::error("CredentialStore", "Failed to decrypt secret via Windows DPAPI for key: " + keyName);
        return QString();
    }

    QByteArray decrypted(reinterpret_cast<const char*>(dataOut.pbData), static_cast<qsizetype>(dataOut.cbData));
    LocalFree(dataOut.pbData);

    return QString::fromUtf8(decrypted);
#else
    QFile file(getStoreFilePath(keyName));
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) return QString();
    return QString::fromUtf8(mask(file.readAll(), keyName));
#endif
}

bool CredentialStore::removeSecret(const QString& keyName) {
    QString path = getStoreFilePath(keyName);
    if (QFile::exists(path)) {
        return QFile::remove(path);
    }
    return true;
}

bool CredentialStore::hasSecret(const QString& keyName) {
    QString path = getStoreFilePath(keyName);
    return QFile::exists(path) && QFile(path).size() > 0;
}

} // namespace Luxor
