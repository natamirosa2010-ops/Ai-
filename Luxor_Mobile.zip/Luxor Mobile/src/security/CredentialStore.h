#pragma once

#include <QString>

namespace Luxor {

class CredentialStore {
public:
    static bool storeSecret(const QString& keyName, const QString& secret);
    static QString getSecret(const QString& keyName);
    static bool removeSecret(const QString& keyName);
    static bool hasSecret(const QString& keyName);

private:
    static QString getStoreFilePath(const QString& keyName);
};

} // namespace Luxor
