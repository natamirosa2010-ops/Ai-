#pragma once

#include <QString>

namespace Luxor {

class PromptInjectionFilter {
public:
    // Wraps untrusted external data (web results, files, user docs) with strict XML/markdown boundaries
    // and passive data instructions to instruct the LLM not to execute instructions embedded inside them.
    static QString sanitizeUntrustedContent(const QString& rawContent, const QString& sourceTag);

    // Checks for typical jailbreak or prompt injection attack patterns
    static bool containsSuspiciousPatterns(const QString& content);
};

} // namespace Luxor
