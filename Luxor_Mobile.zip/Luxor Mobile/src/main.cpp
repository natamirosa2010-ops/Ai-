#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QStandardPaths>
#include <QDir>

#include "core/Logger.h"
#include "database/DatabaseManager.h"
#include "settings/AppSettings.h"
#include "ai/ChatEngine.h"
#include "app/UiBridge.h"
#include <QColor>
#include <QPalette>
#include <QUrl>
#include <memory>
#include <QStringList>
#include <QQmlError>
#include <QQuickWindow>
#ifdef Q_OS_WIN
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <windows.h>
#endif

using namespace Luxor;

// Startup diagnostics: while the UI loads, keep every warning so a broken QML file
// shows a readable error window instead of the app silently closing.
static QStringList g_startupMessages;
static QtMessageHandler g_prevHandler = nullptr;
static void startupCapture(QtMsgType type, const QMessageLogContext& ctx, const QString& msg) {
    if (type != QtDebugMsg && type != QtInfoMsg && g_startupMessages.size() < 60) g_startupMessages << msg;
    if (g_prevHandler) g_prevHandler(type, ctx, msg);
}

static void showStartupError(const QString& logPath) {
    QStringList shown = g_startupMessages;
    shown.removeDuplicates();
    if (shown.size() > 10) shown = shown.mid(0, 10);
    const QString text = QStringLiteral("Не удалось загрузить интерфейс Luxor Mobile.\n\n")
        + (shown.isEmpty() ? QStringLiteral("(подробностей нет)") : shown.join(QStringLiteral("\n\n")))
        + QStringLiteral("\n\nПолный журнал: ") + logPath
        + QStringLiteral("");
    Logger::error("Main", "UI load failed: " + g_startupMessages.join(" | "));
#ifdef Q_OS_WIN
    MessageBoxW(nullptr, reinterpret_cast<LPCWSTR>(text.utf16()), L"Luxor Studio", MB_OK | MB_ICONERROR);
#endif
}

int main(int argc, char* argv[]) {
    QGuiApplication app(argc, argv);
    QGuiApplication::setOrganizationName("Luxor");
    QGuiApplication::setApplicationName("LuxorAI");
    QGuiApplication::setApplicationVersion("0.2.0");
    QQuickStyle::setStyle("Basic");
    {   // colours Qt Quick text items use for Markdown links and selections
        QPalette pal = QGuiApplication::palette();
        pal.setColor(QPalette::Link, QColor(0x7A, 0xB4, 0xFF));
        pal.setColor(QPalette::LinkVisited, QColor(0x9C, 0xC8, 0xFF));
        pal.setColor(QPalette::Highlight, QColor(0x35, 0x52, 0x86));
        pal.setColor(QPalette::HighlightedText, QColor(0xEC, 0xEC, 0xEE));
        QGuiApplication::setPalette(pal);
    }

    const QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dataDir);
    Logger::instance().init(dataDir + "/logs");
    Logger::installQtMessageHandler();             // QML warnings and console.* land in luxor.log too
    g_prevHandler = qInstallMessageHandler(startupCapture);
    Logger::info("Main", "LUXOR starting, data dir: " + dataDir);

    if (!DatabaseManager::instance().init(dataDir + "/luxor.db"))
        Logger::error("Main", "Database init failed; history will not be persisted this session");

    Logger::info("Main", "step: settings");
    AppSettings::instance();                       // load settings early
    Logger::info("Main", "step: chat engine");
    auto* chat = new ChatEngine(&app);
    auto* ui = new UiBridge(&app);
    Logger::info("Main", "step: ui bridge ok");

    QQmlApplicationEngine engine;
    QObject::connect(&engine, &QQmlEngine::warnings, &app, [](const QList<QQmlError>& list) {
        for (const QQmlError& e : list)
            if (g_startupMessages.size() < 60) g_startupMessages << e.toString();
    });
    engine.rootContext()->setContextProperty("aiClient", chat);
    engine.rootContext()->setContextProperty("appSettings", &AppSettings::instance());
    engine.rootContext()->setContextProperty("uiBridge", ui);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     []() { Logger::error("Main", "QML root object creation failed"); },
                     Qt::QueuedConnection);
    Logger::info("Main", "step: loading QML");
    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/LuxorAI/ui/qml/MainWindow.qml")));
    if (engine.rootObjects().isEmpty()) {
        showStartupError(QDir::toNativeSeparators(dataDir + "/logs/luxor.log"));
        return -1;
    }
    qInstallMessageHandler(g_prevHandler);          // UI is up: back to the normal logger only
    Logger::info("Main", "step: QML loaded");
    if (auto* w = qobject_cast<QQuickWindow*>(engine.rootObjects().constFirst())) {
        Logger::info("Main", QStringLiteral("window visible=%1 graphics=%2").arg(w->isVisible()).arg(int(QQuickWindow::graphicsApi())));
        auto conn = std::make_shared<QMetaObject::Connection>();
        *conn = QObject::connect(w, &QQuickWindow::frameSwapped, w, [conn]() {
            Logger::info("Main", "step: first frame shown");
            QObject::disconnect(*conn);
        });
    }

    QObject::connect(&app, &QCoreApplication::aboutToQuit, [&]() {
        Logger::info("Main", "Shutting down");
        chat->shutdown();
        DatabaseManager::instance().close();
    });

    return app.exec();
}
