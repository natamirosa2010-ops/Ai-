#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QElapsedTimer>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>
#include "../core/Types.h"
#include <QMap>

namespace Luxor {

class SseClient : public QObject {
    Q_OBJECT
public:
    explicit SseClient(QObject* parent = nullptr);
    ~SseClient();

    void sendRequest(const QString& url, const QString& apiKey, const QJsonObject& payload, int timeoutSec = 60);
    void abort();
    bool isRunning() const;

signals:
    void streamStarted();
    void deltaReceived(const QString& contentDelta, const QString& reasoningDelta);
    void toolCallDeltaReceived(const QString& callId, const QString& toolName, const QString& argumentsDelta);
    void metricsUpdated(double tokensPerSecond, qint64 timeToFirstTokenMs, int totalTokens);
    void finished(const QString& fullContent, const QString& fullReasoning, const QList<ToolCallRecord>& toolCalls);
    void errorOccurred(const QString& errorMessage, int httpStatusCode);

private slots:
    void onReadyRead();
    void onReplyFinished();
    void onReplyError(QNetworkReply::NetworkError code);
    void onTimeout();

private:
    void processLine(const QString& line);

    QNetworkAccessManager* m_nam = nullptr;
    QNetworkReply* m_reply = nullptr;
    QTimer m_timeoutTimer;

    QElapsedTimer m_requestTimer;
    qint64 m_timeToFirstTokenMs = -1;
    int m_tokenCount = 0;

    QString m_buffer;
    QString m_accumulatedContent;
    QString m_accumulatedReasoning;

    // Active tool calls being accumulated from stream chunks
    struct PartialToolCall {
        QString id;
        QString name;
        QString arguments;
    };
    QMap<int, PartialToolCall> m_partialToolCalls;

    bool m_aborted = false;
    bool m_finishedEmitted = false;
};

} // namespace Luxor
