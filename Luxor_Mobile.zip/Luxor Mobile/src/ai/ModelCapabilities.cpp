#include "ModelCapabilities.h"

namespace Luxor {

QList<ModelInfo> ModelCapabilities::getAllModels() {
    static const QList<ModelInfo> models = {
        {
            "deepseek-chat",
            "DeepSeek Chat",
            "Универсальная быстрая модель для повседневных задач, кодинга и диалогов",
            65536,
            false,
            true,
            false,
            0.7
        },
        {
            "deepseek-reasoner",
            "DeepSeek Reasoner",
            "Флагманская модель глубокого логического рассуждения (CoT) и математики",
            65536,
            false,
            true,  // tool_calls confirmed by api_probe 2026-11-09
            true,  // Produces reasoning_content in streaming
            0.6
        },
        {
            "qwen",
            "Qwen",
            "Мощная мультимодальная модель с поддержкой анализа изображений и инструментов",
            32768,
            true,  // Supports Vision
            true,  // Supports Tools
            false,
            0.7
        },
        {
            "claw",
            "Claw",
            "Оптимизированная агентная модель для автоматизации и выполнения системных задач",
            32768,
            false,
            true,
            true,  // claw returns reasoning_content (api_probe 2026-11-09)
            0.5
        },
        {
            "qwen3.8-27b",
            "Qwen 3.8 27B",
            "Высокопроизводительная модель для сложного программирования и архитектуры",
            32768,
            false,
            true,
            false,
            0.6
        }
    };
    return models;
}

ModelInfo ModelCapabilities::getModelInfo(const QString& modelId) {
    for (const auto& m : getAllModels()) {
        if (m.id.compare(modelId, Qt::CaseInsensitive) == 0) {
            return m;
        }
    }
    return getAllModels().first();
}

bool ModelCapabilities::supportsVision(const QString& modelId) {
    return getModelInfo(modelId).supportsVision;
}

bool ModelCapabilities::supportsTools(const QString& modelId) {
    return getModelInfo(modelId).supportsTools;
}

bool ModelCapabilities::supportsReasoningContent(const QString& modelId) {
    return getModelInfo(modelId).supportsReasoningContent;
}

int ModelCapabilities::getContextWindow(const QString& modelId) {
    return getModelInfo(modelId).contextWindow;
}

} // namespace Luxor
