#pragma once

#include <QString>
#include "../core/Types.h"

namespace Luxor {

struct ModelInfo {
    QString id;
    QString displayName;
    QString description;
    int contextWindow = 32768;
    bool supportsVision = false;
    bool supportsTools = true;
    bool supportsReasoningContent = false;
    double defaultTemperature = 0.7;
};

class ModelCapabilities {
public:
    static QList<ModelInfo> getAllModels();
    static ModelInfo getModelInfo(const QString& modelId);
    static bool supportsVision(const QString& modelId);
    static bool supportsTools(const QString& modelId);
    static bool supportsReasoningContent(const QString& modelId);
    static int getContextWindow(const QString& modelId);
};

} // namespace Luxor
