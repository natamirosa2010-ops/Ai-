#include "ContextOptimizer.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QFileInfo>
#include <QFile>

namespace Luxor {

int ContextOptimizer::estimateTokens(const QString& text) {
    if (text.isEmpty()) return 0;
    // Approximates tokens: ~1 token per 3.5 English characters, or ~1.5 per Russian word/symbol
    int len = text.length();
    return qMax(1, static_cast<int>(len / 3.0));
}

int ContextOptimizer::estimateMessageTokens(const ChatMessage& msg) {
    int count = estimateTokens(msg.content);
    if (!msg.reasoningContent.isEmpty()) {
        count += estimateTokens(msg.reasoningContent);
    }
    for (const auto& att : msg.attachments) {
        if (att.isImage) {
            count += 1000; // Standard high-res image token cost
        } else {
            count += estimateTokens(att.fileName) + 100;
        }
    }
    return count;
}

QString ContextOptimizer::summarizeMessages(const QList<ChatMessage>& messages, int maxTokens) {
    if (messages.isEmpty()) return QString();

    const QString header = QStringLiteral("[Краткое резюме предшествующего диалога]:");
    int used = estimateTokens(header);
    QStringList lines;
    int omitted = 0;

    // Walk from newest to oldest: the most recent context is the most valuable.
    for (int i = messages.size() - 1; i >= 0; --i) {
        const ChatMessage& msg = messages.at(i);
        const QString roleName = (msg.role == MessageRole::User) ? QStringLiteral("Пользователь") : QStringLiteral("Ассистент");
        QString snippet = msg.content.left(100).replace('\n', ' ');
        if (msg.content.length() > 100) snippet += QStringLiteral("...");
        const QString line = QStringLiteral("- %1: %2").arg(roleName, snippet);
        const int t = estimateTokens(line);
        if (maxTokens > 0 && used + t > maxTokens) { omitted = i + 1; break; }
        lines.prepend(line);
        used += t;
    }
    if (omitted > 0)
        lines.prepend(QStringLiteral("- (ещё %1 более ранних сообщений опущено)").arg(omitted));
    lines.prepend(header);
    return lines.join('\n');
}

QJsonArray ContextOptimizer::optimizeContext(const QString& systemPrompt,
                                             const QList<ChatMessage>& rawHistory,
                                             int maxContextTokens,
                                             bool includeVision)
{
    QJsonArray result;

    // 1. System prompt
    const int systemTokens = estimateTokens(systemPrompt);
    QJsonObject sysObj;
    sysObj["role"] = "system";
    sysObj["content"] = systemPrompt;
    result.append(sysObj);

    if (rawHistory.isEmpty()) {
        return result;
    }

    // 2. Budget: reserve room for the reply (at most a quarter of the window), never exceed the window.
    const int reserve = qMin(2048, maxContextTokens / 4);
    int budget = maxContextTokens - systemTokens - reserve;
    if (budget < 256) budget = 256;

    // 3. Select newest messages that fit. The last message is always kept.
    auto selectTail = [&](int limit, QList<ChatMessage>& out) -> int {
        out.clear();
        int acc = 0;
        for (int i = rawHistory.size() - 1; i >= 0; --i) {
            const int t = estimateMessageTokens(rawHistory.at(i));
            if (!out.isEmpty() && acc + t > limit) return i;   // index of newest dropped message
            out.prepend(rawHistory.at(i));
            acc += t;
        }
        return -1;
    };

    QList<ChatMessage> selectedMessages;
    int cutoffIndex = selectTail(budget, selectedMessages);

    // 4. History was cut: give ~20% of the budget to a bounded summary of the older part.
    if (cutoffIndex >= 0) {
        const int summaryBudget = qMax(64, budget / 5);
        cutoffIndex = selectTail(budget - summaryBudget, selectedMessages);
        if (cutoffIndex >= 0) {
            QJsonObject summaryObj;
            summaryObj["role"] = "system";
            summaryObj["content"] = summarizeMessages(rawHistory.mid(0, cutoffIndex + 1), summaryBudget);
            result.append(summaryObj);
        }
    }

    // 5. Build JSON messages for selected messages
    for (const auto& msg : selectedMessages) {
        QJsonObject msgObj;
        QString roleStr = "user";
        if (msg.role == MessageRole::Assistant) roleStr = "assistant";
        else if (msg.role == MessageRole::Tool) roleStr = "tool";

        msgObj["role"] = roleStr;

        // If message has image attachments and model supports vision
        if (includeVision && !msg.attachments.isEmpty()) {
            bool hasImages = false;
            for (const auto& a : msg.attachments) {
                if (a.isImage) { hasImages = true; break; }
            }

            if (hasImages) {
                QJsonArray contentParts;
                // Add text part
                if (!msg.content.isEmpty()) {
                    QJsonObject textPart;
                    textPart["type"] = "text";
                    textPart["text"] = msg.content;
                    contentParts.append(textPart);
                }
                // Add image parts
                for (const auto& a : msg.attachments) {
                    if (a.isImage && !a.previewBase64.isEmpty()) {
                        QJsonObject imgPart;
                        imgPart["type"] = "image_url";
                        QJsonObject urlObj;
                        urlObj["url"] = QString("data:%1;base64,%2").arg(a.mimeType.isEmpty() ? "image/jpeg" : a.mimeType, a.previewBase64);
                        imgPart["image_url"] = urlObj;
                        contentParts.append(imgPart);
                    }
                }
                msgObj["content"] = contentParts;
            } else {
                msgObj["content"] = msg.content;
            }
        } else {
            msgObj["content"] = msg.content;
        }

        result.append(msgObj);
    }

    return result;
}

} // namespace Luxor
