#pragma once

#include <QString>
#include <QList>
#include <QJsonArray>
#include "../core/Types.h"

namespace Luxor {

class ContextOptimizer {
public:
    static int estimateTokens(const QString& text);
    static int estimateMessageTokens(const ChatMessage& msg);

    // Formats and prunes chat messages to fit within model context budget
    static QJsonArray optimizeContext(const QString& systemPrompt,
                                      const QList<ChatMessage>& rawHistory,
                                      int maxContextTokens = 16384,
                                      bool includeVision = false);

    // Creates condensed summary text of older messages.
    // maxTokens > 0 caps the summary size: newest older messages are kept, the rest are counted as omitted.
    static QString summarizeMessages(const QList<ChatMessage>& messages, int maxTokens = -1);
};

} // namespace Luxor
