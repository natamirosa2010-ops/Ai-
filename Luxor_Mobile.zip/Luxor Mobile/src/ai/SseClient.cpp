#include "SseClient.h"
#include "../core/Logger.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>

namespace Luxor {

SseClient::SseClient(QObject* parent)
    : QObject(parent), m_nam(new QNetworkAccessManager(this))
{
    m_timeoutTimer.setSingleShot(true);
    connect(&m_timeoutTimer, &QTimer::timeout, this, &SseClient::onTimeout);
}

SseClient::~SseClient() {
    abort();
}

bool SseClient::isRunning() const {
    return m_reply != nullptr && m_reply->isRunning();
}

void SseClient::abort() {
    m_aborted = true;
    m_timeoutTimer.stop();
    if (m_reply) {
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }
}

void SseClient::sendRequest(const QString& url, const QString& apiKey, const QJsonObject& payload, int timeoutSec) {
    abort();
    m_aborted = false;
    m_finishedEmitted = false;
    m_buffer.clear();
    m_accumulatedContent.clear();
    m_accumulatedReasoning.clear();
    m_partialToolCalls.clear();
    m_tokenCount = 0;
    m_timeToFirstTokenMs = -1;

    QNetworkRequest request{QUrl(url)};   // braces: avoid most vexing parse
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Accept", "text/event-stream");
    if (!apiKey.isEmpty()) {
        request.setRawHeader("Authorization", QString("Bearer %1").arg(apiKey).toUtf8());
    }

    QByteArray postData = QJsonDocument(payload).toJson(QJsonDocument::Compact);

    m_requestTimer.restart();
    m_timeoutTimer.start(timeoutSec * 1000);

    m_reply = m_nam->post(request, postData);
    connect(m_reply, &QNetworkReply::readyRead, this, &SseClient::onReadyRead);
    connect(m_reply, &QNetworkReply::finished, this, &SseClient::onReplyFinished);
    connect(m_reply, &QNetworkReply::errorOccurred, this, &SseClient::onReplyError);

    emit streamStarted();
    Logger::info("SseClient", "Initiated SSE streaming request to: " + url);
}

void SseClient::onTimeout() {
    if (m_reply && m_reply->isRunning()) {
        Logger::warn("SseClient", "Request timed out, aborting.");
        abort();
        emit errorOccurred(QStringLiteral("Превышено время ожидания ответа от сервера (тайм-аут)."), 408);
    }
}

void SseClient::onReadyRead() {
    if (!m_reply) return;

    // Reset timeout on receiving data
    if (m_timeoutTimer.isActive()) {
        m_timeoutTimer.start();
    }

    QByteArray bytes = m_reply->readAll();
    m_buffer.append(QString::fromUtf8(bytes));

    int newlineIndex = -1;
    while ((newlineIndex = m_buffer.indexOf('\n')) != -1) {
        QString line = m_buffer.left(newlineIndex).trimmed();
        m_buffer.remove(0, newlineIndex + 1);
        if (!line.isEmpty()) {
            processLine(line);
        }
    }
}

void SseClient::processLine(const QString& line) {
    if (!line.startsWith("data:")) return;

    QString dataPayload = line.mid(5).trimmed();
    if (dataPayload == "[DONE]") {
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(dataPayload.toUtf8());
    if (!doc.isObject()) return;

    QJsonObject root = doc.object();
    QJsonArray choices = root.value("choices").toArray();
    if (choices.isEmpty()) return;

    QJsonObject choice = choices.first().toObject();
    QJsonObject delta = choice.value("delta").toObject();

    QString contentDelta = delta.value("content").toString();
    QString reasoningDelta = delta.value("reasoning_content").toString();

    // Check for tool calls delta
    if (delta.contains("tool_calls")) {
        QJsonArray toolCallsArr = delta.value("tool_calls").toArray();
        for (const auto& item : toolCallsArr) {
            QJsonObject tc = item.toObject();
            int index = tc.value("index").toInt(0);
            if (!m_partialToolCalls.contains(index)) {
                m_partialToolCalls[index] = PartialToolCall();
            }
            if (tc.contains("id")) {
                m_partialToolCalls[index].id = tc.value("id").toString();
            }
            if (tc.contains("function")) {
                QJsonObject fn = tc.value("function").toObject();
                if (fn.contains("name")) {
                    m_partialToolCalls[index].name = fn.value("name").toString();
                }
                if (fn.contains("arguments")) {
                    QString argsDelta = fn.value("arguments").toString();
                    m_partialToolCalls[index].arguments += argsDelta;
                    emit toolCallDeltaReceived(m_partialToolCalls[index].id, m_partialToolCalls[index].name, argsDelta);
                }
            }
        }
    }

    if (!contentDelta.isEmpty() || !reasoningDelta.isEmpty()) {
        if (m_timeToFirstTokenMs < 0) {
            m_timeToFirstTokenMs = m_requestTimer.elapsed();
        }

        m_tokenCount++;
        m_accumulatedContent += contentDelta;
        m_accumulatedReasoning += reasoningDelta;

        double elapsedSec = m_requestTimer.elapsed() / 1000.0;
        double speed = elapsedSec > 0 ? (m_tokenCount / elapsedSec) : 0.0;
        emit metricsUpdated(speed, m_timeToFirstTokenMs, m_tokenCount);

        emit deltaReceived(contentDelta, reasoningDelta);
    }
}

void SseClient::onReplyFinished() {
    m_timeoutTimer.stop();
    if (m_aborted || m_finishedEmitted) return;

    int statusCode = 0;
    if (m_reply) {
        statusCode = m_reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    }

    if (m_reply && m_reply->error() != QNetworkReply::NoError) {
        // Error will be or was already handled by onReplyError
        return;
    }

    m_finishedEmitted = true;

    // Convert partial tool calls into ToolCallRecord list
    QList<ToolCallRecord> records;
    for (auto it = m_partialToolCalls.begin(); it != m_partialToolCalls.end(); ++it) {
        ToolCallRecord r;
        r.callId = it->id;
        r.toolName = it->name;
        QJsonDocument argsDoc = QJsonDocument::fromJson(it->arguments.toUtf8());
        if (argsDoc.isObject()) {
            r.arguments = argsDoc.object();
        }
        r.timestamp = QDateTime::currentDateTime();
        records.append(r);
    }

    Logger::info("SseClient", QString("Completed response. Total tokens: %1, TTFT: %2 ms, Tool calls: %3")
                                  .arg(m_tokenCount).arg(m_timeToFirstTokenMs).arg(records.size()));

    emit finished(m_accumulatedContent, m_accumulatedReasoning, records);

    if (m_reply) {
        m_reply->deleteLater();
        m_reply = nullptr;
    }
}

void SseClient::onReplyError(QNetworkReply::NetworkError code) {
    if (m_aborted) return;

    m_timeoutTimer.stop();
    int httpCode = 0;
    QString errorMsg;

    if (m_reply) {
        httpCode = m_reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        QByteArray errBody = m_reply->readAll();
        if (!errBody.isEmpty()) {
            QJsonDocument errDoc = QJsonDocument::fromJson(errBody);
            if (errDoc.isObject() && errDoc.object().contains("error")) {
                QJsonObject errObj = errDoc.object().value("error").toObject();
                errorMsg = errObj.value("message").toString();
            } else {
                errorMsg = QString::fromUtf8(errBody);
            }
        }
    }

    if (errorMsg.isEmpty()) {
        errorMsg = m_reply ? m_reply->errorString() : QStringLiteral("Неизвестная ошибка сети");
    }

    Logger::error("SseClient", QString("Network error (%1, HTTP %2): %3").arg(code).arg(httpCode).arg(errorMsg));
    emit errorOccurred(errorMsg, httpCode);

    if (m_reply) {
        m_reply->deleteLater();
        m_reply = nullptr;
    }
}

} // namespace Luxor
