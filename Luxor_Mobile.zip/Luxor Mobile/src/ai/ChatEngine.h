#pragma once

#include <QObject>
#include <QVariantList>
#include <QSet>
#include <QNetworkAccessManager>
#include "SseClient.h"
#include "../core/Types.h"

namespace Luxor {

/**
 * QML-facing chat engine ("aiClient" in QML).
 *
 * - OpenAI-compatible /chat/completions with SSE streaming (SseClient).
 * - Full multi-turn history, trimmed/summarised by ContextOptimizer.
 * - Retries ONLY before the first streamed chunk (max 2, exponential backoff),
 *   so a partially delivered answer is never duplicated.
 * - finished(success, error) is emitted exactly once per request.
 * - Thinking modes are orchestration presets (context budget, system strategy,
 *   Ultra verification pass). No reasoning_effort parameter is sent.
 * - The API key never leaves C++ (only a masked form is exposed).
 */
class ChatEngine : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
    Q_PROPERTY(QString currentModel READ currentModel NOTIFY currentModelChanged)
    Q_PROPERTY(int reasoningMode READ reasoningMode NOTIFY reasoningModeChanged)
    Q_PROPERTY(QString reasoningModeName READ reasoningModeName NOTIFY reasoningModeChanged)
    Q_PROPERTY(bool hasApiKey READ hasApiKey NOTIFY apiKeyChanged)
    Q_PROPERTY(QVariantList availableModels READ availableModels NOTIFY modelsChanged)
    Q_PROPERTY(QString lastError READ lastError NOTIFY lastErrorChanged)
    Q_PROPERTY(bool canRetry READ canRetry NOTIFY busyChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY statusTextChanged)
    Q_PROPERTY(QVariantList conversations READ conversations NOTIFY conversationsChanged)
    Q_PROPERTY(QString currentConversationId READ currentConversationId NOTIFY currentConversationChanged)
    Q_PROPERTY(QString currentTitle READ currentTitle NOTIFY currentConversationChanged)
    Q_PROPERTY(int messageCount READ messageCount NOTIFY historyChanged)
public:
    explicit ChatEngine(QObject* parent = nullptr);
    ~ChatEngine() override;

    bool busy() const { return m_busy; }
    QString currentModel() const { return m_model; }
    int reasoningMode() const { return static_cast<int>(m_mode); }
    QString reasoningModeName() const;
    bool hasApiKey() const;
    QVariantList availableModels() const;
    QString lastError() const { return m_lastError; }
    bool canRetry() const;
    QString statusText() const { return m_status; }
    QVariantList conversations() const { return m_conversations; }
    QString currentConversationId() const { return m_convId; }
    QString currentTitle() const { return m_convTitle; }
    int messageCount() const { return static_cast<int>(m_history.size()); }

    Q_INVOKABLE bool setApiKey(const QString& key);
    Q_INVOKABLE void clearApiKey();
    Q_INVOKABLE QString maskedApiKey() const;
    Q_INVOKABLE QString getEndpoint() const;
    Q_INVOKABLE void setEndpoint(const QString& baseUrl);
    Q_INVOKABLE void selectModel(const QString& modelId);
    Q_INVOKABLE void setReasoningMode(int mode);
    Q_INVOKABLE bool modelSupportsVision(const QString& modelId) const;
    /** Returns false (and sets lastError) when the prompt was not accepted; nothing is added then. */
    Q_INVOKABLE bool sendPrompt(const QString& text);
    Q_INVOKABLE void cancel();
    Q_INVOKABLE void retry();
    Q_INVOKABLE void newChat();
    Q_INVOKABLE void probeModels();

    // Multi-chat persistence (SQLite via ConversationStore)
    Q_INVOKABLE void refreshConversations();
    Q_INVOKABLE bool openConversation(const QString& conversationId);
    Q_INVOKABLE bool renameConversation(const QString& conversationId, const QString& title);
    Q_INVOKABLE bool deleteConversation(const QString& conversationId);
    Q_INVOKABLE QVariantList searchConversations(const QString& query) const;
    /** [{id, role: "user"|"assistant", content, reasoning, timestamp (ms)}] of the open chat. */
    Q_INVOKABLE QVariantList messagesForCurrent() const;
    /** Replaces a user message (and everything after it) with new text and sends it again. */
    Q_INVOKABLE bool editAndResend(const QString& messageId, const QString& newText);

    void shutdown();

signals:
    void busyChanged();
    void currentModelChanged();
    void reasoningModeChanged();
    void apiKeyChanged();
    void modelsChanged();
    void lastErrorChanged();
    void statusTextChanged();
    void streamingResponse(const QString& chunk);
    void reasoningChunk(const QString& chunk);
    void finished(bool success, const QString& errorMessage);
    // tokensPerSecond is an ESTIMATE (stream chunks/s) unless the server reports usage.
    void metricsUpdated(qint64 timeToFirstTokenMs, double tokensPerSecond, bool estimated);
    void modelsProbed(bool ok, const QString& info);
    void conversationsChanged();
    void currentConversationChanged();
    void historyChanged();

private:
    struct ModePreset { int contextBudget; bool verificationPass; int maxAgentIterations; QString strategy; };
    static ModePreset preset(ThinkingMode m);

    static QString normalizeBaseUrl(const QString& url);
    QString chatUrl() const;
    QString systemPrompt() const;
    void startAttempt(int attempt);
    void startVerification();
    void finishOnce(bool success, const QString& error);
    void setBusy(bool b);
    void setStatus(const QString& s);
    static bool isTransient(int httpStatus);
    void ensureConversation(const QString& firstPrompt);
    void persist(ChatMessage& msg);
    void setLastError(const QString& e);

    SseClient* m_sse = nullptr;
    QNetworkAccessManager* m_nam = nullptr;

    QString m_model;
    ThinkingMode m_mode = ThinkingMode::Medium;
    QList<ChatMessage> m_history;
    QSet<QString> m_serverModels;
    bool m_probed = false;

    bool m_busy = false;
    bool m_inFlight = false;
    bool m_finishEmitted = true;
    bool m_gotFirstChunk = false;
    bool m_verifying = false;
    int m_attempt = 0;
    quint64 m_requestSerial = 0;
    QString m_draft;
    QString m_lastError;
    QString m_status;
    QString m_convId;
    QString m_convTitle;
    QVariantList m_conversations;
};

} // namespace Luxor
