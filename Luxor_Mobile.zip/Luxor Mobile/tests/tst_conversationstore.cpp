#include <QtTest>
#include <QTemporaryDir>
#include "database/DatabaseManager.h"
#include "database/ConversationStore.h"
using namespace Luxor;

class TstConversationStore : public QObject {
    Q_OBJECT
    QTemporaryDir m_dir;

    static ChatMessage make(MessageRole role, const QString& text) {
        ChatMessage m;
        m.role = role;
        m.content = text;
        return m;
    }
    static bool listed(const QString& id) {
        for (const QVariant& v : ConversationStore::listConversations())
            if (v.toMap().value("id").toString() == id) return true;
        return false;
    }

private slots:
    void initTestCase() {
        QVERIFY(m_dir.isValid());
        QVERIFY(DatabaseManager::instance().init(m_dir.filePath("store.db")));
    }
    void cleanupTestCase() { DatabaseManager::instance().close(); }

    void titleIsSingleLineAndBounded() {
        QCOMPARE(ConversationStore::makeTitle(QStringLiteral("  Привет,\n  как   дела?  ")), QStringLiteral("Привет, как дела?"));
        QCOMPARE(ConversationStore::makeTitle(QStringLiteral("   ")), QStringLiteral("Новый чат"));
        const QString longTitle = ConversationStore::makeTitle(QString(200, QLatin1Char('a')));
        QVERIFY(longTitle.size() <= 49);
        QVERIFY(longTitle.endsWith(QStringLiteral("…")));
    }

    void roundTripKeepsOrderAndContent() {
        const QString id = ConversationStore::createConversation(QStringLiteral("Первый вопрос"), "deepseek-chat", ThinkingMode::Medium);
        QVERIFY(!id.isEmpty());
        ChatMessage u = make(MessageRole::User, QStringLiteral("Первый вопрос"));
        ChatMessage a = make(MessageRole::Assistant, QStringLiteral("Ответ **markdown**"));
        a.reasoningContent = QStringLiteral("рассуждение");
        ChatMessage u2 = make(MessageRole::User, QStringLiteral("Второй"));
        QVERIFY(ConversationStore::appendMessage(id, u));
        QVERIFY(ConversationStore::appendMessage(id, a));
        QVERIFY(ConversationStore::appendMessage(id, u2));   // same-millisecond timestamps must keep insertion order
        QVERIFY(!u.id.isEmpty());

        const QList<ChatMessage> loaded = ConversationStore::loadMessages(id);
        QCOMPARE(loaded.size(), 3);
        QCOMPARE(loaded.at(0).content, u.content);
        QCOMPARE(loaded.at(1).role, MessageRole::Assistant);
        QCOMPARE(loaded.at(1).reasoningContent, QStringLiteral("рассуждение"));
        QCOMPARE(loaded.at(2).content, QStringLiteral("Второй"));
        QCOMPARE(ConversationStore::titleOf(id), QStringLiteral("Первый вопрос"));
        QVERIFY(listed(id));

        a.content = QStringLiteral("Исправленный ответ");
        QVERIFY(ConversationStore::updateMessage(a));
        QCOMPARE(ConversationStore::loadMessages(id).at(1).content, QStringLiteral("Исправленный ответ"));
    }

    void removeMessagesAndCascadeDelete() {
        const QString id = ConversationStore::createConversation(QStringLiteral("Удаляемый"), "qwen", ThinkingMode::Weak);
        ChatMessage u = make(MessageRole::User, QStringLiteral("q"));
        ChatMessage a = make(MessageRole::Assistant, QStringLiteral("a"));
        QVERIFY(ConversationStore::appendMessage(id, u));
        QVERIFY(ConversationStore::appendMessage(id, a));
        QVERIFY(ConversationStore::removeMessages({a.id}));
        QCOMPARE(ConversationStore::loadMessages(id).size(), 1);

        QVERIFY(ConversationStore::rename(id, QStringLiteral("  Новое\nимя ")));
        QCOMPARE(ConversationStore::titleOf(id), QStringLiteral("Новое имя"));
        QVERIFY(!ConversationStore::rename(id, QStringLiteral("   ")));

        QVERIFY(ConversationStore::remove(id));
        QVERIFY(!listed(id));
        QCOMPARE(ConversationStore::loadMessages(id).size(), 0);
    }

    void searchFindsTitleAndContent() {
        const QString id = ConversationStore::createConversation(QStringLiteral("Отчёт по продажам"), "qwen", ThinkingMode::High);
        ChatMessage u = make(MessageRole::User, QStringLiteral("Посчитай квартальную выручку за год"));
        QVERIFY(ConversationStore::appendMessage(id, u));

        auto found = [&](const QString& q) {
            for (const QVariant& v : ConversationStore::search(q))
                if (v.toMap().value("id").toString() == id) return true;
            return false;
        };
        QVERIFY(found(QStringLiteral("отчёт")));      // title, case-insensitive
        QVERIFY(found(QStringLiteral("выручку")));    // message content
        QVERIFY(!found(QStringLiteral("несуществующее-слово")));
        QVERIFY(ConversationStore::search(QStringLiteral("  ")).isEmpty());
    }
};

QTEST_GUILESS_MAIN(TstConversationStore)
#include "tst_conversationstore.moc"
