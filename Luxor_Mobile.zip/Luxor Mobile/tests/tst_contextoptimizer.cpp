#include <QtTest>
#include <QJsonArray>
#include <QJsonObject>
#include "ai/ContextOptimizer.h"
using namespace Luxor;

static ChatMessage mk(MessageRole r, const QString& t) { ChatMessage m; m.role = r; m.content = t; return m; }

class TstContextOptimizer : public QObject {
    Q_OBJECT
private slots:
    void systemFirstAndLastUserKept() {
        QList<ChatMessage> h{ mk(MessageRole::User, "привет"), mk(MessageRole::Assistant, "здравствуйте"), mk(MessageRole::User, "последний вопрос") };
        const QJsonArray a = ContextOptimizer::optimizeContext("SYS", h, 16000);
        QVERIFY(a.size() >= 2);
        QCOMPARE(a.first().toObject().value("role").toString(), QString("system"));
        QCOMPARE(a.last().toObject().value("content").toString(), QString("последний вопрос"));
    }
    void longHistoryTrimmedToBudget() {
        QList<ChatMessage> h;
        for (int i = 0; i < 200; ++i) h << mk(i % 2 ? MessageRole::Assistant : MessageRole::User, QString(400, QChar('a' + i % 20)));
        h << mk(MessageRole::User, "финал");
        const QJsonArray a = ContextOptimizer::optimizeContext("SYS", h, 2000);
        int total = 0;
        for (const auto& v : a) total += ContextOptimizer::estimateTokens(v.toObject().value("content").toString());
        QVERIFY2(total <= 2600, qPrintable(QString("tokens=%1").arg(total)));
        QCOMPARE(a.last().toObject().value("content").toString(), QString("финал"));
    }
    void summaryIsBounded() {
        QList<ChatMessage> h;
        for (int i = 0; i < 500; ++i) h << mk(MessageRole::User, QString(300, QChar('x')));
        const QString s = ContextOptimizer::summarizeMessages(h, 300);
        QVERIFY2(ContextOptimizer::estimateTokens(s) <= 300 + 40, qPrintable(QString("tokens=%1").arg(ContextOptimizer::estimateTokens(s))));
        QVERIFY(s.contains(QStringLiteral("опущено")));
    }
    void hugeLastMessageKept() {
        QList<ChatMessage> h{ mk(MessageRole::User, "a"), mk(MessageRole::User, QString(30000, QChar('z'))) };
        const QJsonArray a = ContextOptimizer::optimizeContext("SYS", h, 2000);
        QCOMPARE(a.last().toObject().value("content").toString().size(), 30000);
    }
};
QTEST_GUILESS_MAIN(TstContextOptimizer)
#include "tst_contextoptimizer.moc"
