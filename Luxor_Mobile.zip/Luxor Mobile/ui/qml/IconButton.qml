import QtQuick
import QtQuick.Controls
import "Theme.js" as Theme

// Flat icon (+ optional label) button with hover feedback and tooltip.
Item {
    id: root
    property string glyph: ""
    property string label: ""
    property string tip: ""
    property bool active: false
    property bool danger: false
    property color glyphColor: Theme.textMuted
    property int glyphSize: 16
    property int labelSize: 13
    property real radius: 8
    readonly property bool hovered: ma.containsMouse
    signal clicked()

    implicitWidth: label === "" ? 40 : row.implicitWidth + 20
    implicitHeight: 40
    opacity: enabled ? 1.0 : 0.4

    Rectangle {
        anchors.fill: parent
        radius: root.radius
        color: root.active ? Theme.surfaceActive
                           : (ma.containsMouse ? (root.danger ? Theme.dangerSoft : Theme.surfaceHover) : "transparent")
        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
    }
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 7
        Text {
            visible: root.glyph !== ""
            text: root.glyph
            font.family: Theme.icons
            font.pixelSize: root.glyphSize
            color: root.danger && ma.containsMouse ? Theme.danger
                                                   : (ma.containsMouse || root.active ? Theme.text : root.glyphColor)
            anchors.verticalCenter: parent.verticalCenter
        }
        Text {
            visible: root.label !== ""
            text: root.label
            font.family: Theme.sans
            font.pixelSize: root.labelSize
            color: ma.containsMouse || root.active ? Theme.text : Theme.textMuted
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
    ToolTip.visible: root.tip !== "" && ma.containsMouse
    ToolTip.text: root.tip
    ToolTip.delay: 600
}
