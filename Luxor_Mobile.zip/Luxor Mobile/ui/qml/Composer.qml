import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Prompt input: auto-growing text, model and thinking-mode pickers, send / stop.
// Enter — send, Shift+Enter — new line, Esc — stop generation.
Rectangle {
    id: root
    property bool large: false
    property alias text: input.text
    property string placeholder: aiClient.hasApiKey ? "Спросите что угодно…" : "Сначала добавьте API-ключ в настройках"
    readonly property bool canSend: !aiClient.busy && aiClient.hasApiKey && input.text.trim() !== ""
    signal sent(string text)
    signal needSettings()

    function focusInput() { input.forceActiveFocus() }
    function setText(t) {
        input.text = t
        input.cursorPosition = input.length
        input.forceActiveFocus()
    }
    function trySend() {
        if (aiClient.busy) return
        if (!aiClient.hasApiKey) { root.needSettings(); return }
        var t = input.text.trim()
        if (t === "") return
        if (aiClient.sendPrompt(t)) {
            input.text = ""
            root.sent(t)
        }
    }

    implicitHeight: col.implicitHeight + 20
    radius: 20
    color: Theme.surface
    border.width: 1
    border.color: input.activeFocus ? Qt.rgba(0.478, 0.706, 1.0, 0.55) : Theme.border
    Behavior on border.color { ColorAnimation { duration: Theme.d(Theme.normal, appSettings.animationsEnabled) } }

    Rectangle {                     // soft shadow under the card
        z: -1
        anchors.fill: parent
        anchors.margins: -1
        anchors.topMargin: 4
        anchors.bottomMargin: -6
        radius: parent.radius + 2
        color: "#000000"
        opacity: 0.22
    }

    component Chip: Item {
        id: chip
        property string text: ""
        property string tip: ""
        signal clicked()
        implicitWidth: crow.implicitWidth + 20
        implicitHeight: 30
        Rectangle {
            anchors.fill: parent
            radius: 10
            color: cma.containsMouse ? Theme.surfaceHover : "transparent"
            Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        }
        Row {
            id: crow
            anchors.centerIn: parent
            spacing: 6
            Text {
                width: Math.min(implicitWidth, 120)
                text: chip.text
                elide: Text.ElideRight
                font.family: Theme.sans
                font.pixelSize: 13
                color: cma.containsMouse ? Theme.text : Theme.textMuted
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                text: Theme.ic.chevronDown
                font.family: Theme.icons
                font.pixelSize: 9
                color: Theme.textDim
                anchors.verticalCenter: parent.verticalCenter
            }
        }
        MouseArea {
            id: cma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: chip.clicked()
        }
        ToolTip.visible: chip.tip !== "" && cma.containsMouse
        ToolTip.text: chip.tip
        ToolTip.delay: 600
    }

    component Picker: Popup {
        parent: Overlay.overlay
        modal: true
        dim: true
        Overlay.modal: Rectangle { color: "#80000000" }
        padding: 6
        background: Rectangle { radius: 14; color: Theme.surface; border.color: Theme.border }
        enter: Transition {
            ParallelAnimation {
                NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.d(Theme.fast, appSettings.animationsEnabled) }
                NumberAnimation { property: "scale"; from: 0.97; to: 1; duration: Theme.d(Theme.fast, appSettings.animationsEnabled); easing.type: Easing.OutCubic }
            }
        }
        exit: Transition { NumberAnimation { property: "opacity"; to: 0; duration: Theme.d(100, appSettings.animationsEnabled) } }
    }

    ColumnLayout {
        id: col
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.topMargin: 10
        anchors.leftMargin: 14
        anchors.rightMargin: 10
        spacing: 6

        ScrollView {
            Layout.fillWidth: true
            Layout.preferredHeight: Math.min(Math.max(input.implicitHeight, root.large ? 64 : 40), 220)
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            TextArea {
                id: input
                wrapMode: TextEdit.Wrap
                font.family: Theme.sans
                font.pixelSize: 16
                color: Theme.text
                placeholderText: root.placeholder
                placeholderTextColor: Theme.textDim
                selectionColor: Theme.selection
                selectedTextColor: Theme.text
                selectByMouse: true
                background: null
                leftPadding: 2
                rightPadding: 2
                topPadding: 8
                bottomPadding: 6
                Keys.onPressed: function (e) {
                    if ((e.key === Qt.Key_Return || e.key === Qt.Key_Enter) && (e.modifiers & Qt.ControlModifier)) {
                        e.accepted = true
                        root.trySend()
                    } else if (e.key === Qt.Key_Escape && aiClient.busy) {
                        e.accepted = true
                        aiClient.cancel()
                    }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 2
            IconButton { glyph: "\uD83C\uDF99"; tip: "Голосовой ввод появится в следующей версии"; opacity: 0.5 }
            Item { Layout.fillWidth: true }

            Chip {
                id: modelChip
                text: Theme.modelName(aiClient.availableModels, aiClient.currentModel)
                tip: "Модель"
                onClicked: modelPop.opened ? modelPop.close() : modelPop.open()
                Picker {
                    id: modelPop
                    width: Math.min(420, Overlay.overlay.width - 24)
                    x: (Overlay.overlay.width - width) / 2
                    y: Overlay.overlay.height - height - 16
                    contentItem: Column {
                        spacing: 2
                        Repeater {
                            model: aiClient.availableModels
                            delegate: Rectangle {
                                id: mrow
                                readonly property bool current: modelData.id === aiClient.currentModel
                                readonly property bool missing: modelData.probed === true && modelData.availableOnServer === false
                                width: parent ? parent.width : 318
                                height: mcol.implicitHeight + 16
                                radius: 10
                                color: mma.containsMouse ? Theme.surfaceHover : "transparent"
                                Column {
                                    id: mcol
                                    x: 12
                                    y: 8
                                    width: parent.width - 48
                                    spacing: 2
                                    Text {
                                        text: modelData.name ? modelData.name : modelData.id
                                        color: mrow.missing ? Theme.textDim : Theme.text
                                        font.family: Theme.sans
                                        font.pixelSize: 14
                                    }
                                    Text {
                                        width: parent.width
                                        visible: text !== ""
                                        text: (modelData.description ? modelData.description : "") + (mrow.missing ? " · нет на сервере" : "")
                                        wrapMode: Text.Wrap
                                        color: Theme.textDim
                                        font.family: Theme.sans
                                        font.pixelSize: 12
                                    }
                                }
                                Text {
                                    visible: mrow.current
                                    anchors.right: parent.right
                                    anchors.rightMargin: 14
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: Theme.ic.check
                                    font.family: Theme.icons
                                    font.pixelSize: 13
                                    color: Theme.accent
                                }
                                MouseArea {
                                    id: mma
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        aiClient.selectModel(modelData.id)
                                        modelPop.close()
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Chip {
                id: modeChip
                text: Theme.modeNames[aiClient.reasoningMode] !== undefined ? Theme.modeNames[aiClient.reasoningMode] : aiClient.reasoningModeName
                tip: "Режим мышления"
                onClicked: modePop.opened ? modePop.close() : modePop.open()
                Picker {
                    id: modePop
                    width: Math.min(420, Overlay.overlay.width - 24)
                    x: (Overlay.overlay.width - width) / 2
                    y: Overlay.overlay.height - height - 16
                    contentItem: Column {
                        spacing: 2
                        Repeater {
                            model: 4
                            delegate: Rectangle {
                                id: prow
                                width: parent ? parent.width : 288
                                height: pcol.implicitHeight + 16
                                radius: 10
                                color: pma.containsMouse ? Theme.surfaceHover : "transparent"
                                Column {
                                    id: pcol
                                    x: 12
                                    y: 8
                                    width: parent.width - 48
                                    spacing: 2
                                    Text {
                                        text: Theme.modeNames[index]
                                        color: Theme.text
                                        font.family: Theme.sans
                                        font.pixelSize: 14
                                    }
                                    Text {
                                        width: parent.width
                                        text: Theme.modeHints[index]
                                        wrapMode: Text.Wrap
                                        color: Theme.textDim
                                        font.family: Theme.sans
                                        font.pixelSize: 12
                                    }
                                }
                                Text {
                                    visible: aiClient.reasoningMode === index
                                    anchors.right: parent.right
                                    anchors.rightMargin: 14
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: Theme.ic.check
                                    font.family: Theme.icons
                                    font.pixelSize: 13
                                    color: Theme.accent
                                }
                                MouseArea {
                                    id: pma
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        aiClient.setReasoningMode(index)
                                        modePop.close()
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Rectangle {
                id: sendBtn
                Layout.leftMargin: 4
                width: 36
                height: 36
                radius: 18
                color: !aiClient.busy && root.canSend ? (sma.containsMouse ? Qt.lighter(Theme.accent2, 1.12) : Theme.accent2)
                                                       : (sma.containsMouse && aiClient.busy ? Theme.surfaceHover : Theme.surfaceActive)
                scale: sma.pressed ? 0.94 : 1.0
                Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                Behavior on scale { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                Text {
                    anchors.centerIn: parent
                    text: aiClient.busy ? Theme.ic.stop : Theme.ic.up
                    font.family: Theme.icons
                    font.pixelSize: aiClient.busy ? 12 : 14
                    color: aiClient.busy ? Theme.text : (root.canSend ? "#FFFFFF" : Theme.textDim)
                }
                MouseArea {
                    id: sma
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: aiClient.busy ? aiClient.cancel() : root.trySend()
                }
                ToolTip.visible: sma.containsMouse
                ToolTip.delay: 600
                ToolTip.text: aiClient.busy ? "Остановить (Esc)" : (aiClient.hasApiKey ? "Отправить (Enter)" : "Добавьте API-ключ в настройках")
            }
        }
    }
}
