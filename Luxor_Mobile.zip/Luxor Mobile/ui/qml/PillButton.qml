import QtQuick
import "Theme.js" as Theme

// Rounded text button. Secondary by default; primary = accent fill; danger = red outline.
Item {
    id: root
    property string text: ""
    property string glyph: ""
    property bool primary: false
    property bool danger: false
    readonly property bool hovered: ma.containsMouse
    signal clicked()

    implicitWidth: row.implicitWidth + 32
    implicitHeight: 42
    opacity: enabled ? 1.0 : 0.45
    activeFocusOnTab: true
    Keys.onSpacePressed: root.clicked()

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: root.primary ? (ma.containsMouse ? Qt.lighter(Theme.accent2, 1.12) : Theme.accent2)
                            : (root.danger ? (ma.containsMouse ? Theme.dangerSoft : "transparent")
                                           : (ma.containsMouse ? Theme.surfaceHover : Theme.surface))
        border.width: 1
        border.color: root.primary ? "transparent"
                                   : (root.danger ? Theme.danger : (root.activeFocus ? Theme.accent : Theme.border))
        scale: ma.pressed ? 0.97 : 1.0
        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        Behavior on scale { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
    }
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 7
        Text {
            visible: root.glyph !== ""
            text: root.glyph
            font.family: Theme.icons
            font.pixelSize: 13
            color: lbl.color
            anchors.verticalCenter: parent.verticalCenter
        }
        Text {
            id: lbl
            text: root.text
            font.family: Theme.sans
            font.pixelSize: 13
            font.weight: Font.Medium
            color: root.primary ? "#FFFFFF" : (root.danger ? Theme.danger : Theme.text)
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
