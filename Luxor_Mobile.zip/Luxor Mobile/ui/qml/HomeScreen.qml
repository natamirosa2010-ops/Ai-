import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Start screen with the intro.
//  First launch: the logo appears and rises, "Hello" is handwritten, then the name question
//  (only if there is no name yet), the greeting, "Ну что, продолжим?" is typed, and the
//  composer and cards cascade in. Later launches play a short version (~1.5 s).
//  Any click or key skips to the end, but never past the name question.
Item {
    id: root
    signal openSettings()
    signal openConversation(string id)
    signal promptSent()

    readonly property string tagline: "Ну что, продолжим?"
    property bool running: false
    property bool instant: false
    property bool askingName: false
    property bool greetShown: false
    property bool composerShown: false
    property int revealed: 0
    property string typed: ""
    property int hour: new Date().getHours()
    property int gen: 0
    property var steps: []
    property int stepIdx: 0
    readonly property string greeting: Theme.greeting(hour) + (appSettings.userName !== "" ? ", " + appSettings.userName : "")
    readonly property var recent: aiClient.conversations.slice(0, 3)
    readonly property var examples: [
        { glyph: Theme.ic.code, title: "Разобрать код", hint: "Объяснить и найти ошибки", prompt: "Объясни, что делает этот код, и найди возможные ошибки:\n\n" },
        { glyph: Theme.ic.bulb, title: "Объяснить тему", hint: "Простыми словами, с примерами", prompt: "Объясни простыми словами, с примерами: " },
        { glyph: Theme.ic.history, title: "Составить план", hint: "По шагам и со сроками", prompt: "Составь пошаговый план со сроками: " },
        { glyph: Theme.ic.edit, title: "Улучшить текст", hint: "Сохранить смысл, убрать лишнее", prompt: "Улучши этот текст, сохранив смысл:\n\n" }
    ]

    function needName() { return appSettings.userName.trim() === "" }
    function play(list) {
        gen++
        steps = list
        stepIdx = 0
        running = true
        stepTimer.stop()
        runStep()
    }
    function runStep() {
        var g = gen
        if (stepIdx >= steps.length) { running = false; return }
        var s = steps[stepIdx]
        stepIdx++
        s.fn()
        if (g !== gen || !running) return
        if (stepIdx < steps.length) {
            stepTimer.interval = Math.max(1, steps[stepIdx].at - s.at)
            stepTimer.restart()
        } else {
            running = false
        }
    }
    function resetStage() {
        gen++
        stepTimer.stop()
        typeTimer.stop()
        cascadeTimer.stop()
        instant = true
        logoBox.opacity = 0
        logoBox.scale = 0.6
        logoBox.rotation = 45
        logoBox.lift = 0
        helloBox.opacity = 0
        hello.clear()
        askingName = false
        greetShown = false
        composerShown = false
        revealed = 0
        typed = ""
        instant = false
    }
    function start() {
        hour = new Date().getHours()
        resetStage()
        root.forceActiveFocus()
        if (!appSettings.animationsEnabled) { finish(); return }
        if (!appSettings.introSeen) playFull()
        else if (needName()) askName()
        else playMain(22, 250)
    }
    function refresh() {                 // the screen is shown again (new chat)
        hour = new Date().getHours()
        if (running || askingName) return
        if (!greetShown) { start(); return }
        if (appSettings.animationsEnabled) {
            revealed = 0
            cascadeTimer.start()
        }
        composer.focusInput()
    }
    function playFull() {
        play([
            { at: 0,    fn: function () { logoBox.opacity = 1; logoBox.scale = 1; logoBox.rotation = 0 } },
            { at: 1000, fn: function () { logoBox.lift = -130; logoBox.scale = 0.6 } },
            { at: 1400, fn: function () { helloBox.opacity = 1; hello.draw(2000) } },
            { at: 3900, fn: function () {
                if (root.needName()) root.askName()
                else { helloBox.opacity = 0; logoBox.opacity = 0 }
            } },
            { at: 4250, fn: function () { root.playMain(34, 400) } }
        ])
    }
    function playMain(typeMs, typeAt) {
        var typedEnd = typeAt + typeMs * tagline.length
        play([
            { at: 0,             fn: function () { root.greetShown = true } },
            { at: typeAt,        fn: function () { typeTimer.interval = typeMs; typeTimer.start() } },
            { at: typedEnd + 150,   fn: function () { root.composerShown = true } },
            { at: typedEnd + 400,   fn: function () { cascadeTimer.start() } },
            { at: typedEnd + 1100,  fn: function () { root.completeIntro() } }
        ])
    }
    function askName() {
        gen++
        running = false
        stepTimer.stop()
        helloBox.opacity = 0
        logoBox.opacity = 0
        askingName = true
        Qt.callLater(function () { nameField.forceActiveFocus() })
    }
    function submitName() {
        var n = nameField.text.trim()
        if (n === "") n = nameField.suggested
        if (n === "") { nameField.forceActiveFocus(); return }
        appSettings.userName = n
        askingName = false
        root.forceActiveFocus()
        if (appSettings.animationsEnabled) playMain(34, 450)
        else finish()
    }
    function completeIntro() {
        gen++
        running = false
        stepTimer.stop()
        cascadeTimer.stop()
        typed = tagline
        greetShown = true
        composerShown = true
        revealed = 99
        appSettings.introSeen = true
        composer.focusInput()
    }
    function finish() {                  // skip to the end
        gen++
        stepTimer.stop()
        typeTimer.stop()
        cascadeTimer.stop()
        instant = true
        logoBox.opacity = 0
        helloBox.opacity = 0
        hello.finish()
        if (needName()) {
            instant = false
            askName()
            return
        }
        askingName = false
        greetShown = true
        composerShown = true
        typed = tagline
        revealed = 99
        instant = false
        completeIntro()
    }

    Timer { id: stepTimer; onTriggered: root.runStep() }
    Timer {
        id: typeTimer
        interval: 34
        repeat: true
        onTriggered: {
            if (root.typed.length >= root.tagline.length) { stop(); return }
            root.typed = root.tagline.substring(0, root.typed.length + 1)
        }
    }
    Timer {
        id: cascadeTimer
        interval: 70
        repeat: true
        onTriggered: {
            root.revealed++
            if (root.revealed > 8) stop()
        }
    }

    Keys.onPressed: function (e) {
        if (root.running) {
            e.accepted = true
            root.finish()
        }
    }
    MouseArea {                          // click anywhere skips the intro
        anchors.fill: parent
        z: 50
        enabled: root.running
        visible: enabled
        onClicked: root.finish()
    }

    // ---------- intro: logo + handwritten "Hello"
    Item {
        id: logoBox
        property real lift: 0
        width: 96
        height: 96
        x: (root.width - width) / 2
        y: root.height / 2 - height / 2 - 60 + lift
        opacity: 0
        scale: 0.6
        rotation: 45
        visible: opacity > 0.01
        Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 600; easing.type: Easing.OutCubic } }
        Behavior on scale { enabled: !root.instant; NumberAnimation { duration: 700; easing.type: Easing.OutCubic } }
        Behavior on rotation { enabled: !root.instant; NumberAnimation { duration: 700; easing.type: Easing.OutCubic } }
        Behavior on lift { enabled: !root.instant; NumberAnimation { duration: 450; easing.type: Easing.InOutCubic } }
        SparkLogo { anchors.centerIn: parent; size: 88; glow: true }
    }
    Item {
        id: helloBox
        width: Math.min(root.width - 16, Math.max(300, hello.implicitWidth))
        height: hello.implicitHeight > 0 ? hello.implicitHeight : 140
        x: (root.width - width) / 2
        y: root.height / 2 - height / 2 + 10
        opacity: 0
        visible: opacity > 0.01
        Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 350 } }
        HelloWriter { id: hello; anchors.centerIn: parent }
    }

    // ---------- name question
    Column {
        id: namePrompt
        property real shiftY: root.askingName ? 0 : 14
        width: root.width - 40
        x: (root.width - width) / 2
        y: root.height / 2 - height / 2 - 20 + shiftY
        spacing: 14
        opacity: root.askingName ? 1 : 0
        visible: opacity > 0.01
        Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 350; easing.type: Easing.OutCubic } }
        Behavior on shiftY { enabled: !root.instant; NumberAnimation { duration: 350; easing.type: Easing.OutCubic } }
        SparkLogo { anchors.horizontalCenter: parent.horizontalCenter; size: 40; glow: true }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Как вас зовут?"
            font.family: Theme.serif
            font.pixelSize: 30
            color: Theme.text
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Так я смогу обращаться к вам по имени"
            font.family: Theme.sans
            font.pixelSize: 14
            color: Theme.textMuted
        }
        Rectangle {
            width: parent.width
            height: 50
            radius: 14
            color: Theme.surface
            border.color: nameField.activeFocus ? Theme.accent : Theme.border
            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 14
                anchors.rightMargin: 7
                spacing: 8
                TextField {
                    id: nameField
                    readonly property string suggested: uiBridge.systemUserName()
                    Layout.fillWidth: true
                    placeholderText: suggested !== "" ? "Например, " + suggested : "Ваше имя"
                    placeholderTextColor: Theme.textDim
                    color: Theme.text
                    selectionColor: Theme.selection
                    selectedTextColor: Theme.text
                    font.family: Theme.sans
                    font.pixelSize: 15
                    background: null
                    leftPadding: 0
                    selectByMouse: true
                    maximumLength: 40
                    onAccepted: root.submitName()
                }
                PillButton { text: "Продолжить"; primary: true; onClicked: root.submitName() }
            }
        }
    }

    // ---------- final layout
    ColumnLayout {
        id: mainCol
        width: root.width - 28
        x: (root.width - width) / 2
        y: Math.max(64, (root.height - implicitHeight) / 2 - 24)
        spacing: 0
        visible: root.greetShown

        RowLayout {
            id: greetRow
            property real shiftY: root.greetShown ? 0 : 14
            Layout.alignment: Qt.AlignHCenter
            Layout.maximumWidth: mainCol.width
            spacing: 14
            opacity: root.greetShown ? 1 : 0
            transform: Translate { y: greetRow.shiftY }
            Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 450; easing.type: Easing.OutCubic } }
            Behavior on shiftY { enabled: !root.instant; NumberAnimation { duration: 450; easing.type: Easing.OutCubic } }
            SparkLogo { size: 36; glow: true }
            Text {
                Layout.fillWidth: true
                text: root.greeting
                elide: Text.ElideRight
                font.family: Theme.serif
                font.pixelSize: 36
                color: Theme.text
            }
        }

        Item {                              // typed tagline, left-aligned in a fixed box so it does not jitter
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 10
            implicitWidth: fullTag.implicitWidth + 12
            implicitHeight: 28
            Text {
                id: fullTag
                visible: false
                text: root.tagline
                font.family: Theme.sans
                font.pixelSize: 18
            }
            Text {
                id: tagText
                anchors.verticalCenter: parent.verticalCenter
                text: root.typed
                font.family: Theme.sans
                font.pixelSize: 18
                color: Theme.textMuted
            }
            Rectangle {
                x: tagText.implicitWidth + 3
                anchors.verticalCenter: parent.verticalCenter
                width: 2
                height: 20
                color: Theme.accent
                visible: root.greetShown && root.running
                SequentialAnimation on opacity {
                    running: root.greetShown && root.running
                    loops: Animation.Infinite
                    NumberAnimation { to: 0; duration: 450 }
                    NumberAnimation { to: 1; duration: 450 }
                }
            }
        }

        Rectangle {                         // no API key yet
            visible: !aiClient.hasApiKey
            Layout.fillWidth: true
            Layout.topMargin: 24
            implicitHeight: bannerRow.implicitHeight + 20
            radius: 12
            color: Theme.accentSoft
            border.color: Qt.rgba(0.478, 0.706, 1.0, 0.3)
            opacity: root.composerShown ? 1 : 0
            Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 350 } }
            RowLayout {
                id: bannerRow
                x: 14
                y: 10
                width: parent.width - 28
                spacing: 10
                Text {
                    text: Theme.ic.info
                    font.family: Theme.icons
                    font.pixelSize: 14
                    color: Theme.accent
                }
                Text {
                    Layout.fillWidth: true
                    text: "Добавьте API-ключ в настройках, чтобы начать"
                    wrapMode: Text.Wrap
                    color: Theme.accentText
                    font.family: Theme.sans
                    font.pixelSize: 14
                }
                PillButton { text: "Открыть настройки"; primary: true; onClicked: root.openSettings() }
            }
        }

        Item {
            id: composerBox
            property real shiftY: root.composerShown ? 0 : 24
            Layout.fillWidth: true
            Layout.topMargin: aiClient.hasApiKey ? 30 : 14
            implicitHeight: composer.implicitHeight
            opacity: root.composerShown ? 1 : 0
            transform: Translate { y: composerBox.shiftY }
            Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 350; easing.type: Easing.OutCubic } }
            Behavior on shiftY { enabled: !root.instant; NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
            Composer {
                id: composer
                width: parent.width
                large: true
                onSent: root.promptSent()
                onNeedSettings: root.openSettings()
            }
        }

        GridLayout {
            Layout.fillWidth: true
            Layout.topMargin: 18
            columns: 1
            columnSpacing: 10
            rowSpacing: 10
            Repeater {
                model: root.examples
                delegate: Rectangle {
                    id: card
                    property real shiftY: index < root.revealed ? 0 : 10
                    Layout.fillWidth: true
                    implicitHeight: 64
                    radius: 14
                    color: cardHover.hovered ? Theme.surfaceHover : Theme.surface
                    border.color: cardHover.hovered ? Theme.border : Theme.borderSoft
                    opacity: index < root.revealed ? 1 : 0
                    scale: cardHover.hovered ? 1.02 : 1.0
                    transform: Translate { y: card.shiftY }
                    Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                    Behavior on shiftY { enabled: !root.instant; NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                    Behavior on scale { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled); easing.type: Easing.OutCubic } }
                    Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 14
                        spacing: 12
                        Rectangle {
                            width: 34
                            height: 34
                            radius: 10
                            color: Theme.accentSoft
                            Text {
                                anchors.centerIn: parent
                                text: modelData.glyph
                                font.family: Theme.icons
                                font.pixelSize: 14
                                color: Theme.accent
                            }
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2
                            Text {
                                text: modelData.title
                                color: Theme.text
                                font.family: Theme.sans
                                font.pixelSize: 14
                                font.weight: Font.Medium
                            }
                            Text {
                                Layout.fillWidth: true
                                text: modelData.hint
                                elide: Text.ElideRight
                                color: Theme.textDim
                                font.family: Theme.sans
                                font.pixelSize: 12
                            }
                        }
                    }
                    HoverHandler { id: cardHover; cursorShape: Qt.PointingHandCursor }
                    TapHandler { onTapped: composer.setText(modelData.prompt) }
                }
            }
        }

        ColumnLayout {
            visible: root.recent.length > 0
            Layout.fillWidth: true
            Layout.topMargin: 26
            spacing: 2
            Text {
                text: "Недавние чаты"
                color: Theme.textDim
                font.family: Theme.sans
                font.pixelSize: 12
                font.weight: Font.DemiBold
                opacity: root.revealed > 4 ? 1 : 0
                Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 300 } }
            }
            Repeater {
                model: root.recent
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 38
                    radius: 10
                    color: rh.hovered ? Theme.surfaceHover : "transparent"
                    opacity: index + 5 < root.revealed ? 1 : 0
                    Behavior on opacity { enabled: !root.instant; NumberAnimation { duration: 300 } }
                    Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 12
                        spacing: 10
                        Text {
                            text: Theme.ic.chat
                            font.family: Theme.icons
                            font.pixelSize: 12
                            color: Theme.textDim
                        }
                        Text {
                            Layout.fillWidth: true
                            text: modelData.title ? modelData.title : "Без названия"
                            elide: Text.ElideRight
                            color: Theme.text
                            font.family: Theme.sans
                            font.pixelSize: 13
                        }
                        Text {
                            text: Theme.timeLabel(modelData.updatedAt ? modelData.updatedAt : 0)
                            color: Theme.textDim
                            font.family: Theme.sans
                            font.pixelSize: 12
                        }
                    }
                    HoverHandler { id: rh; cursorShape: Qt.PointingHandCursor }
                    TapHandler { onTapped: root.openConversation(String(modelData.id)) }
                }
            }
        }
    }
}
