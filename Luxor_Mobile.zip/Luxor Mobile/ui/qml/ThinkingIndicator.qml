import QtQuick
import "Theme.js" as Theme

// Small breathing spark + the engine's real status text ("Отправка запроса...", "Проверяет результат...").
Row {
    id: root
    property string text: "Думает…"
    property bool active: true
    spacing: 10

    SparkLogo {
        size: 15
        glow: true
        pulsing: root.active && root.visible
        spinning: root.active && root.visible
        anchors.verticalCenter: parent.verticalCenter
    }
    Text {
        id: label
        text: root.text
        color: Theme.textMuted
        font.family: Theme.sans
        font.pixelSize: 14
        anchors.verticalCenter: parent.verticalCenter
    }
    SequentialAnimation {
        id: shimmer
        loops: Animation.Infinite
        running: root.active && root.visible && appSettings.animationsEnabled
        NumberAnimation { target: label; property: "opacity"; to: 0.45; duration: 900; easing.type: Easing.InOutSine }
        NumberAnimation { target: label; property: "opacity"; to: 1.0; duration: 900; easing.type: Easing.InOutSine }
        onRunningChanged: if (!running) label.opacity = 1.0
    }
}
