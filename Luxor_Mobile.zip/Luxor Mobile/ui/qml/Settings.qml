import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Settings page. Only options the backend really uses are shown.
Item {
    id: root
    signal back()
    signal replayIntro()

    property string keyStatus: ""
    property bool keyStatusOk: true
    property string endpointStatus: ""
    property bool endpointOk: true
    property string probeText: ""
    property bool probeOk: true
    property bool probing: false

    function saveKey() {
        var k = keyEdit.text.trim()
        if (k === "") return
        if (aiClient.setApiKey(k)) {
            keyEdit.text = ""
            keyEdit.reveal = false
            keyStatus = "Ключ сохранён"
            keyStatusOk = true
        } else {
            keyStatus = "Не удалось сохранить ключ"
            keyStatusOk = false
        }
    }
    function saveEndpoint() {
        var ok = aiClient.setEndpoint(endpointEdit.text.trim())
        endpointOk = ok !== false
        endpointStatus = endpointOk ? "Адрес сохранён" : "Некорректный адрес"
        endpointEdit.text = aiClient.getEndpoint()
    }
    function ctxLabel(n) {
        if (!n || n <= 0) return ""
        if (n >= 1000000) return (Math.round(n / 100000) / 10).toString().replace(".", ",") + "M"
        if (n % 1000 === 0) return (n / 1000) + "K"
        if (n % 1024 === 0) return (n / 1024) + "K"
        return Math.round(n / 1000) + "K"
    }

    Connections {
        target: aiClient
        function onModelsProbed(ok, info) {
            root.probing = false
            root.probeOk = ok
            root.probeText = info !== "" ? info : (ok ? "Сервер доступен" : "Сервер не ответил")
        }
    }

    component Section: ColumnLayout {
        id: sec
        default property alias body: inner.data
        property string title: ""
        property string subtitle: ""
        Layout.fillWidth: true
        spacing: 10
        ColumnLayout {
            spacing: 2
            Text { text: sec.title; font.family: Theme.serif; font.pixelSize: 19; color: Theme.text }
            Text { visible: sec.subtitle !== ""; text: sec.subtitle; font.family: Theme.sans; font.pixelSize: 13; color: Theme.textDim }
        }
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: inner.implicitHeight + 36
            radius: 14
            color: Theme.surface
            border.color: Theme.borderSoft
            ColumnLayout {
                id: inner
                x: 18
                y: 18
                width: parent.width - 36
                spacing: 14
            }
        }
    }
    component Field: TextField {
        Layout.fillWidth: true
        implicitHeight: 38
        color: Theme.text
        placeholderTextColor: Theme.textDim
        selectionColor: Theme.selection
        selectedTextColor: Theme.text
        font.family: Theme.sans
        font.pixelSize: 14
        selectByMouse: true
        leftPadding: 12
        rightPadding: 12
        background: Rectangle {
            radius: 10
            color: Theme.bg
            border.color: parent.activeFocus ? Theme.accent : Theme.border
        }
    }
    component Toggle: Item {
        id: tg
        property bool checked: false
        signal toggled(bool value)
        implicitWidth: 42
        implicitHeight: 24
        Rectangle {
            anchors.fill: parent
            radius: height / 2
            color: tg.checked ? Theme.accent2 : Theme.surfaceActive
            border.color: tg.checked ? "transparent" : Theme.border
            Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
            Rectangle {
                width: 18
                height: 18
                radius: 9
                y: 3
                x: tg.checked ? parent.width - width - 3 : 3
                color: "#FFFFFF"
                Behavior on x { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled); easing.type: Easing.OutCubic } }
            }
        }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: tg.toggled(!tg.checked) }
    }
    component Badge: Rectangle {
        id: bd
        property string text: ""
        property color tone: Theme.textMuted
        implicitWidth: bt.implicitWidth + 14
        implicitHeight: 20
        radius: 10
        color: Qt.rgba(tone.r, tone.g, tone.b, 0.14)
        Text { id: bt; anchors.centerIn: parent; text: bd.text; color: bd.tone; font.family: Theme.sans; font.pixelSize: 11 }
    }
    component Choice: Rectangle {
        id: ch
        property string title: ""
        property string hint: ""
        property bool selected: false
        signal picked()
        Layout.fillWidth: true
        implicitHeight: chCol.implicitHeight + 22
        radius: 12
        color: selected ? Theme.accentSoft : (chHover.hovered ? Theme.surfaceHover : Theme.bg)
        border.color: selected ? Qt.rgba(0.478, 0.706, 1.0, 0.45) : Theme.borderSoft
        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        Rectangle {
            x: 14
            anchors.verticalCenter: parent.verticalCenter
            width: 18
            height: 18
            radius: 9
            color: "transparent"
            border.width: 2
            border.color: ch.selected ? Theme.accent : Theme.textDim
            Rectangle { anchors.centerIn: parent; width: 8; height: 8; radius: 4; color: Theme.accent; visible: ch.selected }
        }
        ColumnLayout {
            id: chCol
            x: 44
            y: 11
            width: parent.width - 58
            spacing: 2
            Text {
                Layout.fillWidth: true
                text: ch.title
                wrapMode: Text.Wrap
                color: Theme.text
                font.family: Theme.sans
                font.pixelSize: 14
                font.weight: ch.selected ? Font.DemiBold : Font.Normal
            }
            Text {
                Layout.fillWidth: true
                visible: ch.hint !== ""
                text: ch.hint
                wrapMode: Text.Wrap
                color: Theme.textMuted
                font.family: Theme.sans
                font.pixelSize: 12
            }
        }
        HoverHandler { id: chHover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: ch.picked() }
    }
    component Sep: Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.borderSoft }

    Rectangle { anchors.fill: parent; color: Theme.bg }

    Item {
        id: head
        z: 2
        width: parent.width
        height: 56
        IconButton {
            x: 14
            anchors.verticalCenter: parent.verticalCenter
            glyph: Theme.ic.back
            label: "Назад"
            tip: "Esc"
            onClicked: root.back()
        }
        Text {
            anchors.centerIn: parent
            text: "Настройки"
            font.family: Theme.serif
            font.pixelSize: 18
            color: Theme.text
        }
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 1
            color: Theme.borderSoft
            opacity: flick.contentY > 4 ? 1 : 0
        }
    }

    Flickable {
        id: flick
        anchors.top: head.bottom
        anchors.bottom: parent.bottom
        width: parent.width
        contentWidth: width
        contentHeight: content.implicitHeight + 64
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

        ColumnLayout {
            id: content
            width: flick.width - 24
            x: (flick.width - width) / 2
            y: 16
            spacing: 26

            Section {
                title: "Профиль"
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 14
                    Rectangle {
                        width: 44
                        height: 44
                        radius: 22
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: Theme.accent }
                            GradientStop { position: 1.0; color: Theme.accent2 }
                        }
                        Text {
                            anchors.centerIn: parent
                            text: appSettings.userName !== "" ? appSettings.userName.charAt(0).toUpperCase() : "?"
                            color: "#FFFFFF"
                            font.family: Theme.sans
                            font.pixelSize: 18
                            font.weight: Font.DemiBold
                        }
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Text { text: "Как к вам обращаться"; color: Theme.textMuted; font.family: Theme.sans; font.pixelSize: 13 }
                        Field {
                            text: appSettings.userName
                            placeholderText: "Ваше имя"
                            maximumLength: 40
                            onEditingFinished: if (text.trim() !== appSettings.userName) appSettings.userName = text.trim()
                        }
                    }
                }
                RowLayout {
                    PillButton { text: "Показать знакомство снова"; glyph: Theme.ic.refresh; onClicked: root.replayIntro() }
                }
            }

            Section {
                title: "Подключение"
                subtitle: "Сервер моделей и ваш API-ключ"
                RowLayout {
                    spacing: 8
                    Rectangle { width: 8; height: 8; radius: 4; color: aiClient.hasApiKey ? Theme.success : Theme.danger }
                    Text {
                        text: aiClient.hasApiKey ? "Ключ сохранён · " + aiClient.maskedApiKey() : "Ключ не задан"
                        color: Theme.text
                        font.family: Theme.sans
                        font.pixelSize: 14
                    }
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field {
                        id: keyEdit
                        property bool reveal: false
                        echoMode: reveal ? TextInput.Normal : TextInput.Password
                        placeholderText: aiClient.hasApiKey ? "Новый ключ — заменит текущий" : "Вставьте API-ключ"
                        onAccepted: root.saveKey()
                    }
                    IconButton {
                        glyph: keyEdit.reveal ? "\uD83D\uDE48" : "\uD83D\uDC41"
                        tip: keyEdit.reveal ? "Скрыть" : "Показать"
                        onClicked: keyEdit.reveal = !keyEdit.reveal
                    }
                }
                PillButton { Layout.alignment: Qt.AlignRight; text: "Сохранить ключ"; primary: true; enabled: keyEdit.text.trim() !== ""; onClicked: root.saveKey() }
                Text {
                    visible: root.keyStatus !== ""
                    text: root.keyStatus
                    color: root.keyStatusOk ? Theme.success : Theme.danger
                    font.family: Theme.sans
                    font.pixelSize: 12
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Text {
                        Layout.fillWidth: true
                        text: "Ключ хранится в закрытой памяти приложения и никогда не показывается целиком."
                        wrapMode: Text.Wrap
                        color: Theme.textDim
                        font.family: Theme.sans
                        font.pixelSize: 12
                    }
                    PillButton { visible: aiClient.hasApiKey; text: "Удалить ключ"; danger: true; onClicked: deleteKeyDialog.open() }
                }
                Sep {}
                Text { text: "Адрес API"; color: Theme.textMuted; font.family: Theme.sans; font.pixelSize: 13 }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field {
                        id: endpointEdit
                        placeholderText: "https://models.sjtu.edu.cn/api/v1/chat/completions"
                        Component.onCompleted: text = aiClient.getEndpoint()
                        onAccepted: root.saveEndpoint()
                    }
                }
                PillButton { Layout.alignment: Qt.AlignRight; text: "Сохранить адрес"; onClicked: root.saveEndpoint() }
                Text {
                    visible: root.endpointStatus !== ""
                    text: root.endpointStatus
                    color: root.endpointOk ? Theme.success : Theme.danger
                    font.family: Theme.sans
                    font.pixelSize: 12
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    PillButton {
                        text: root.probing ? "Проверяем…" : "Проверить подключение"
                        glyph: Theme.ic.refresh
                        enabled: aiClient.hasApiKey && !root.probing
                        onClicked: {
                            root.probing = true
                            root.probeText = ""
                            aiClient.probeModels()
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        visible: root.probeText !== ""
                        text: root.probeText
                        wrapMode: Text.Wrap
                        color: root.probeOk ? Theme.success : Theme.danger
                        font.family: Theme.sans
                        font.pixelSize: 12
                    }
                }
                Sep {}
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Text { text: "Таймаут сети"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                        Text { text: "Сколько ждать ответа сервера"; color: Theme.textDim; font.family: Theme.sans; font.pixelSize: 12 }
                    }
                    IconButton {
                        glyph: "\u2212"
                        tip: "Меньше"
                        enabled: appSettings.networkTimeoutSec > 10
                        onClicked: appSettings.networkTimeoutSec = Math.max(10, appSettings.networkTimeoutSec - 10)
                    }
                    Text {
                        Layout.preferredWidth: 64
                        horizontalAlignment: Text.AlignHCenter
                        text: appSettings.networkTimeoutSec + " с"
                        color: Theme.text
                        font.family: Theme.mono
                        font.pixelSize: 14
                    }
                    IconButton {
                        glyph: Theme.ic.add
                        tip: "Больше"
                        enabled: appSettings.networkTimeoutSec < 600
                        onClicked: appSettings.networkTimeoutSec = Math.min(600, appSettings.networkTimeoutSec + 10)
                    }
                }
            }

            Section {
                title: "Модель"
                subtitle: "Используется для новых сообщений"
                Repeater {
                    model: aiClient.availableModels
                    delegate: Rectangle {
                        id: mcard
                        readonly property bool current: modelData.id === aiClient.currentModel
                        readonly property bool missing: modelData.probed === true && modelData.availableOnServer === false
                        Layout.fillWidth: true
                        implicitHeight: mc.implicitHeight + 24
                        radius: 12
                        color: current ? Theme.accentSoft : (mh.hovered ? Theme.surfaceHover : Theme.bg)
                        border.color: current ? Qt.rgba(0.478, 0.706, 1.0, 0.45) : Theme.borderSoft
                        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                        ColumnLayout {
                            id: mc
                            x: 14
                            y: 12
                            width: parent.width - 28
                            spacing: 6
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 8
                                Text {
                                    Layout.fillWidth: true
                                    text: modelData.name ? modelData.name : modelData.id
                                    elide: Text.ElideRight
                                    color: mcard.missing ? Theme.textMuted : Theme.text
                                    font.family: Theme.sans
                                    font.pixelSize: 14
                                    font.weight: Font.Medium
                                }
                                Text { visible: mcard.current; text: Theme.ic.check; font.family: Theme.icons; font.pixelSize: 13; color: Theme.accent }
                            }
                            Text {
                                Layout.fillWidth: true
                                visible: text !== ""
                                text: modelData.description ? modelData.description : ""
                                wrapMode: Text.Wrap
                                color: Theme.textDim
                                font.family: Theme.sans
                                font.pixelSize: 12
                            }
                            Flow {
                                Layout.fillWidth: true
                                spacing: 6
                                Badge { visible: root.ctxLabel(modelData.contextWindow) !== ""; text: root.ctxLabel(modelData.contextWindow) + " контекст" }
                                Badge { visible: modelData.supportsVision === true; text: "Зрение"; tone: Theme.accent }
                                Badge { visible: modelData.supportsTools === true; text: "Инструменты"; tone: Theme.accent }
                                Badge {
                                    visible: modelData.probed === true
                                    text: mcard.missing ? "Нет на сервере" : "Доступна"
                                    tone: mcard.missing ? Theme.danger : Theme.success
                                }
                            }
                        }
                        HoverHandler { id: mh; cursorShape: Qt.PointingHandCursor }
                        TapHandler { onTapped: aiClient.selectModel(modelData.id) }
                    }
                }
                Text {
                    visible: aiClient.availableModels.length === 0
                    text: "Список моделей пуст — проверьте подключение"
                    color: Theme.textDim
                    font.family: Theme.sans
                    font.pixelSize: 13
                }
            }

            Section {
                title: "Режим мышления"
                subtitle: "Насколько глубоко модель обдумывает ответ"
                GridLayout {
                    Layout.fillWidth: true
                    columns: content.width > 520 ? 2 : 1
                    columnSpacing: 10
                    rowSpacing: 10
                    Repeater {
                        model: 4
                        delegate: Choice {
                            title: Theme.modeNames[index]
                            hint: Theme.modeHints[index]
                            selected: aiClient.reasoningMode === index
                            onPicked: aiClient.setReasoningMode(index)
                        }
                    }
                }
            }

            Section {
                title: "Интерфейс"
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Text { text: "Плавные анимации"; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                        Text { text: "Появление сообщений, переходы, знакомство"; color: Theme.textDim; font.family: Theme.sans; font.pixelSize: 12 }
                    }
                    Toggle {
                        checked: appSettings.animationsEnabled
                        onToggled: function (value) { appSettings.animationsEnabled = value }
                    }
                }
            }

            Section {
                title: "О программе"
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    SparkLogo { size: 30 }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Text { text: "Luxor Studio " + uiBridge.appVersion; color: Theme.text; font.family: Theme.sans; font.pixelSize: 14 }
                        Text {
                            Layout.fillWidth: true
                            text: "Журнал: " + uiBridge.logFilePath()
                            elide: Text.ElideMiddle
                            color: Theme.textDim
                            font.family: Theme.mono
                            font.pixelSize: 11
                        }
                    }
                }
            }
        }
    }

    Popup {
        id: deleteKeyDialog
        parent: Overlay.overlay
        anchors.centerIn: parent
        width: Math.min(400, Overlay.overlay.width - 32)
        modal: true
        dim: true
        padding: 22
        Overlay.modal: Rectangle { color: "#A0000000" }
        background: Rectangle { radius: 16; color: Theme.surface; border.color: Theme.border }
        contentItem: ColumnLayout {
            spacing: 12
            Text { text: "Удалить API-ключ?"; font.family: Theme.serif; font.pixelSize: 20; color: Theme.text }
            Text {
                Layout.fillWidth: true
                text: "Без ключа отправлять сообщения не получится. Ключ можно будет добавить снова."
                wrapMode: Text.Wrap
                font.family: Theme.sans
                font.pixelSize: 14
                color: Theme.textMuted
            }
            RowLayout {
                Layout.alignment: Qt.AlignRight
                Layout.topMargin: 6
                spacing: 8
                PillButton { text: "Отмена"; onClicked: deleteKeyDialog.close() }
                PillButton {
                    text: "Удалить"
                    danger: true
                    onClicked: {
                        aiClient.clearApiKey()
                        root.keyStatus = "Ключ удалён"
                        root.keyStatusOk = true
                        deleteKeyDialog.close()
                    }
                }
            }
        }
    }
}
