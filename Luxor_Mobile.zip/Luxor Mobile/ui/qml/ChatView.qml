import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Conversation: header, centred message column (~760 px), composer.
// History comes from aiClient.messagesForCurrent(); the answer being generated is a
// temporary "__stream__" row fed by streamingResponse / reasoningChunk.
Item {
    id: root
    property bool activityOpen: false
    signal toggleActivity()
    signal openSettings()
    signal openMenu()

    property string streamBuf: ""
    property string reasonBuf: ""
    property string partialText: ""
    property string errorText: ""
    property string pendingMetrics: ""
    property var metricsById: ({})
    property bool stick: true
    property bool scrolling: false
    property bool initialLoad: true
    readonly property int columnWidth: width - 24

    function focusComposer() { composer.focusInput() }
    function fmtMetrics(ttft, tps, est) {
        var parts = []
        if (ttft > 0) parts.push("первый токен " + (ttft / 1000).toFixed(1).replace(".", ",") + " с")
        if (tps > 0) parts.push((est ? "≈" : "") + Math.round(tps) + " ток/с")
        return parts.join(" · ")
    }
    function mkRow(mid, role, content, reasoning, streaming, metrics) {
        return { mid: mid, role: role, content: content, reasoning: reasoning, streaming: streaming, metrics: metrics, fresh: false }
    }
    function reload() {
        var list = aiClient.messagesForCurrent()
        var rows = []
        for (var i = 0; i < list.length; ++i) {
            var m = list[i]
            var id = String(m.id)
            rows.push(mkRow(id, m.role === "user" ? "user" : "assistant", m.content ? m.content : "",
                            m.reasoning ? m.reasoning : "", false, metricsById[id] ? metricsById[id] : ""))
        }
        if (pendingMetrics !== "" && !aiClient.busy) {
            for (var j = rows.length - 1; j >= 0; --j) {
                if (rows[j].role === "assistant") {
                    rows[j].metrics = pendingMetrics
                    metricsById[rows[j].mid] = pendingMetrics
                    break
                }
            }
            pendingMetrics = ""
        }
        if (aiClient.busy) {
            rows.push(mkRow("__stream__", "assistant", streamBuf, reasonBuf, true, ""))
        } else {
            if (partialText !== "") {
                var last = rows.length > 0 ? rows[rows.length - 1] : null
                var saved = last !== null && last.role === "assistant" && last.content.indexOf(partialText.substring(0, 40)) === 0
                if (!saved) rows.push(mkRow("__partial__", "assistant", partialText, "", false, ""))
            }
            if (errorText !== "") rows.push(mkRow("__error__", "error", errorText, "", false, ""))
        }
        var n = 0
        for (; n < rows.length && n < msgs.count; ++n) {
            var cur = msgs.get(n)
            if (cur.mid !== rows[n].mid) break
            if (cur.content !== rows[n].content) msgs.setProperty(n, "content", rows[n].content)
            if (cur.reasoning !== rows[n].reasoning) msgs.setProperty(n, "reasoning", rows[n].reasoning)
            if (cur.streaming !== rows[n].streaming) msgs.setProperty(n, "streaming", rows[n].streaming)
            if (cur.metrics !== rows[n].metrics) msgs.setProperty(n, "metrics", rows[n].metrics)
        }
        var replacedStream = false
        for (var k = n; k < msgs.count; ++k) if (msgs.get(k).mid === "__stream__") replacedStream = true
        while (msgs.count > n) msgs.remove(msgs.count - 1)
        for (; n < rows.length; ++n) {
            rows[n].fresh = !initialLoad && !(replacedStream && rows[n].role === "assistant")
            msgs.append(rows[n])
        }
        initialLoad = false
        if (stick) scrollToEnd()
    }
    function resetForConversation() {
        flush.stop()
        streamBuf = ""
        reasonBuf = ""
        partialText = ""
        errorText = ""
        pendingMetrics = ""
        initialLoad = true
        stick = true
        msgs.clear()
        reload()
    }
    function scrollToEnd() {
        Qt.callLater(function () {
            root.scrolling = true
            list.positionViewAtEnd()
            root.scrolling = false
        })
    }
    function retry() {
        errorText = ""
        partialText = ""
        aiClient.retry()
    }
    function pushStream() {
        var i = msgs.count - 1
        if (i < 0 || msgs.get(i).mid !== "__stream__") { reload(); return }
        if (msgs.get(i).content !== streamBuf) msgs.setProperty(i, "content", streamBuf)
        if (msgs.get(i).reasoning !== reasonBuf) msgs.setProperty(i, "reasoning", reasonBuf)
    }

    ListModel { id: msgs }
    Timer { id: flush; interval: 40; onTriggered: root.pushStream() }   // ~25 fps re-render while streaming

    Connections {
        target: aiClient
        function onStreamingResponse(chunk) {
            root.streamBuf += chunk
            if (!flush.running) flush.start()
        }
        function onReasoningChunk(chunk) {
            root.reasonBuf += chunk
            if (!flush.running) flush.start()
        }
        function onBusyChanged() {
            if (aiClient.busy) {
                root.streamBuf = ""
                root.reasonBuf = ""
                root.partialText = ""
                root.errorText = ""
                root.stick = true
            }
            Qt.callLater(root.reload)
        }
        function onFinished(success, errorMessage) {
            flush.stop()
            root.partialText = success ? "" : root.streamBuf
            root.errorText = success ? "" : (errorMessage !== "" ? errorMessage : "Ответ не получен.")
            root.streamBuf = ""
            root.reasonBuf = ""
            Qt.callLater(root.reload)
        }
        function onMetricsUpdated(timeToFirstTokenMs, tokensPerSecond, estimated) {
            root.pendingMetrics = root.fmtMetrics(timeToFirstTokenMs, tokensPerSecond, estimated)
        }
        function onHistoryChanged() { Qt.callLater(root.reload) }
        function onCurrentConversationChanged() { root.resetForConversation() }
    }
    Component.onCompleted: reload()

    // ---------- header
    Rectangle {
        id: header
        z: 2
        anchors.top: parent.top
        width: parent.width
        height: 56
        color: Theme.bg
        IconButton {
            id: menuBtn
            anchors.left: parent.left
            anchors.leftMargin: 6
            anchors.verticalCenter: parent.verticalCenter
            glyph: Theme.ic.menu
            onClicked: root.openMenu()
        }
        Text {
            anchors.left: menuBtn.right
            anchors.leftMargin: 6
            anchors.right: headRow.left
            anchors.rightMargin: 12
            anchors.verticalCenter: parent.verticalCenter
            text: aiClient.currentTitle !== "" ? aiClient.currentTitle : "Новый чат"
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.serif
            font.pixelSize: 17
        }
        Row {
            id: headRow
            anchors.right: parent.right
            anchors.rightMargin: 12
            anchors.verticalCenter: parent.verticalCenter
            spacing: 6
            ConnectionIndicator {
                anchors.verticalCenter: parent.verticalCenter
                onOpenSettings: root.openSettings()
            }
            IconButton {
                glyph: Theme.ic.activity
                active: root.activityOpen
                tip: "Активность и источники"
                onClicked: root.toggleActivity()
            }
        }
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 1
            color: Theme.borderSoft
            opacity: list.contentY - list.originY > 4 ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        }
    }

    // ---------- messages
    ListView {
        id: list
        anchors.top: header.bottom
        anchors.bottom: bottomArea.top
        width: parent.width
        model: msgs
        clip: true
        cacheBuffer: 2400
        boundsBehavior: Flickable.StopAtBounds
        topMargin: 20
        bottomMargin: 16
        onContentHeightChanged: if (root.stick) root.scrollToEnd()
        onContentYChanged: {
            if (root.scrolling || contentHeight <= 0) return
            var remain = (1.0 - visibleArea.yPosition - visibleArea.heightRatio) * contentHeight
            root.stick = remain < 60
        }
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
        delegate: Item {
            width: list.width
            height: item.height
            MessageItem {
                id: item
                width: root.columnWidth
                anchors.horizontalCenter: parent.horizontalCenter
                mid: model.mid
                role: model.role
                content: model.content
                reasoning: model.reasoning
                streaming: model.streaming
                metrics: model.metrics
                animateIn: model.fresh
                isLast: index === list.count - 1
                onRetryRequested: root.retry()
            }
        }
    }

    // ---------- jump to the latest message
    Rectangle {
        z: 3
        width: 34
        height: 34
        radius: 17
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: bottomArea.top
        anchors.bottomMargin: 12
        color: tma.containsMouse ? Theme.surfaceHover : Theme.surface
        border.color: Theme.border
        opacity: root.stick ? 0 : 1
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        Text {
            anchors.centerIn: parent
            text: Theme.ic.down
            font.family: Theme.icons
            font.pixelSize: 13
            color: Theme.text
        }
        MouseArea {
            id: tma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                root.stick = true
                root.scrollToEnd()
            }
        }
    }

    // ---------- composer
    Item {
        id: bottomArea
        z: 2
        anchors.bottom: parent.bottom
        width: parent.width
        height: composer.height + 20
        Rectangle {
            anchors.bottom: parent.top
            width: parent.width
            height: 24
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(0.137, 0.137, 0.149, 0.0) }
                GradientStop { position: 1.0; color: Theme.bg }
            }
        }
        Rectangle { anchors.fill: parent; color: Theme.bg }
        Composer {
            id: composer
            y: 4
            width: root.columnWidth
            anchors.horizontalCenter: parent.horizontalCenter
            onNeedSettings: root.openSettings()
            onSent: root.stick = true
        }
    }
}
