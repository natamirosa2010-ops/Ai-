import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme
import "Markdown.js" as Md

// One chat message.
//  user      — bubble on the right; copy / edit-and-resend on hover
//  assistant — plain Markdown (no bubble), code blocks, collapsible reasoning, soft streaming caret
//  error     — red card with "Повторить"
Item {
    id: root
    property string mid: ""
    property string role: "assistant"
    property string content: ""
    property string reasoning: ""
    property bool streaming: false
    property bool isLast: false
    property bool animateIn: false
    property string metrics: ""
    property bool editing: false
    property bool copied: false
    property bool showReasoning: false
    readonly property bool isUser: role === "user"
    readonly property bool isError: role === "error"
    readonly property bool isAnswer: !isUser && !isError
    signal retryRequested()

    implicitHeight: col.implicitHeight + 22
    height: implicitHeight

    transform: Translate { id: shift; y: 0 }
    Component.onCompleted: {
        if (isAnswer) Md.apply(segs, Md.split(content))
        if (animateIn && appSettings.animationsEnabled) {
            opacity = 0
            shift.y = 8
            appear.start()
        }
    }
    onContentChanged: if (isAnswer) Md.apply(segs, Md.split(content))

    ParallelAnimation {
        id: appear
        NumberAnimation { target: root; property: "opacity"; to: 1; duration: Theme.normal; easing.type: Easing.OutCubic }
        NumberAnimation { target: shift; property: "y"; to: 0; duration: Theme.normal; easing.type: Easing.OutCubic }
    }

    ListModel { id: segs }
    HoverHandler { id: hover }
    Timer { id: copyTimer; interval: 1500; onTriggered: root.copied = false }

    Column {
        id: col
        width: parent.width
        spacing: 6

        // ---------- user bubble
        Item {
            visible: root.isUser
            width: parent.width
            height: visible ? bubble.height : 0
            Text {
                id: measure
                visible: false
                text: root.content
                font.family: Theme.sans
                font.pixelSize: 15
            }
            Rectangle {
                id: bubble
                anchors.right: parent.right
                width: root.editing ? parent.width : Math.min(measure.implicitWidth + 34, parent.width * 0.82)
                height: root.editing ? editCol.implicitHeight + 24 : userText.implicitHeight + 22
                radius: 18
                color: Theme.userBubble
                border.width: 1
                border.color: root.editing ? Theme.accent : "transparent"
                TextEdit {
                    id: userText
                    visible: !root.editing
                    x: 16
                    y: 11
                    width: parent.width - 32
                    text: root.content
                    textFormat: TextEdit.PlainText
                    wrapMode: TextEdit.Wrap
                    readOnly: true
                    selectByMouse: true
                    color: Theme.text
                    selectionColor: Theme.selection
                    selectedTextColor: Theme.text
                    font.family: Theme.sans
                    font.pixelSize: 15
                }
                ColumnLayout {
                    id: editCol
                    visible: root.editing
                    x: 14
                    y: 12
                    width: parent.width - 28
                    spacing: 10
                    TextArea {
                        id: editArea
                        Layout.fillWidth: true
                        wrapMode: TextEdit.Wrap
                        font.family: Theme.sans
                        font.pixelSize: 15
                        color: Theme.text
                        selectionColor: Theme.selection
                        selectedTextColor: Theme.text
                        selectByMouse: true
                        background: null
                        padding: 0
                        Keys.onEscapePressed: root.editing = false
                    }
                    RowLayout {
                        Layout.alignment: Qt.AlignRight
                        spacing: 8
                        PillButton { text: "Отмена"; onClicked: root.editing = false }
                        PillButton {
                            text: "Отправить"
                            primary: true
                            enabled: !aiClient.busy && editArea.text.trim() !== ""
                            onClicked: if (aiClient.editAndResend(root.mid, editArea.text.trim())) root.editing = false
                        }
                    }
                }
            }
        }

        // ---------- reasoning (collapsible)
        Item {
            visible: root.isAnswer && root.reasoning !== ""
            width: parent.width
            height: visible ? rcol.implicitHeight + 4 : 0
            Column {
                id: rcol
                width: parent.width
                spacing: 8
                Row {
                    spacing: 6
                    Text {
                        text: Theme.ic.bulb
                        font.family: Theme.icons
                        font.pixelSize: 12
                        color: Theme.textDim
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        text: root.streaming && root.content === "" ? "Размышляет…" : "Ход мыслей"
                        font.family: Theme.sans
                        font.pixelSize: 13
                        color: rhover.hovered ? Theme.text : Theme.textMuted
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        text: root.showReasoning ? Theme.ic.chevronUp : Theme.ic.chevronDown
                        font.family: Theme.icons
                        font.pixelSize: 9
                        color: Theme.textDim
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    HoverHandler { id: rhover; cursorShape: Qt.PointingHandCursor }
                    TapHandler { onTapped: root.showReasoning = !root.showReasoning }
                }
                Item {
                    visible: root.showReasoning
                    width: parent.width
                    height: visible ? rtext.implicitHeight : 0
                    Rectangle { width: 2; height: parent.height; radius: 1; color: Theme.border }
                    TextEdit {
                        id: rtext
                        x: 14
                        width: parent.width - 14
                        text: root.reasoning
                        readOnly: true
                        selectByMouse: true
                        textFormat: TextEdit.PlainText
                        wrapMode: TextEdit.Wrap
                        color: Theme.textMuted
                        selectionColor: Theme.selection
                        selectedTextColor: Theme.text
                        font.family: Theme.sans
                        font.pixelSize: 13
                    }
                }
            }
        }

        // ---------- waiting for the first token
        ThinkingIndicator {
            visible: root.streaming && root.content === "" && root.reasoning === ""
            active: visible
            text: aiClient.statusText !== "" ? aiClient.statusText.replace(/\.\.\.$/, "…") : "Думает…"
        }

        // ---------- answer: Markdown text + code blocks
        Column {
            id: answer
            visible: root.isAnswer
            width: parent.width
            spacing: 10
            Repeater {
                model: segs
                delegate: Column {
                    width: answer.width
                    CodeBlock {
                        visible: model.kind === "code"
                        width: parent.width
                        code: model.kind === "code" ? model.body : ""
                        lang: model.lang
                        closed: model.closed
                    }
                    TextEdit {
                        id: md
                        visible: model.kind === "text"
                        width: parent.width
                        text: model.kind === "text" ? Md.sanitize(model.body) : ""
                        textFormat: TextEdit.MarkdownText
                        wrapMode: TextEdit.Wrap
                        readOnly: true
                        selectByMouse: true
                        color: Theme.text
                        selectionColor: Theme.selection
                        selectedTextColor: Theme.text
                        font.family: Theme.sans
                        font.pixelSize: 15
                        onLinkActivated: function (link) { if (Md.isSafeLink(link)) Qt.openUrlExternally(link) }
                        HoverHandler { enabled: md.hoveredLink !== ""; cursorShape: Qt.PointingHandCursor }
                        Rectangle {        // soft caret at the end of the streaming text
                            id: caret
                            property rect r: { md.contentHeight; md.width; return md.positionToRectangle(md.length) }
                            visible: root.streaming && model.kind === "text" && index === segs.count - 1
                            x: r.x + 3
                            y: r.y + 3
                            width: 7
                            height: Math.max(10, r.height - 6)
                            radius: 2
                            color: Theme.accent
                            SequentialAnimation on opacity {
                                running: caret.visible && appSettings.animationsEnabled
                                loops: Animation.Infinite
                                NumberAnimation { to: 0.25; duration: 530; easing.type: Easing.InOutSine }
                                NumberAnimation { to: 1.0; duration: 530; easing.type: Easing.InOutSine }
                            }
                        }
                    }
                }
            }
        }

        // ---------- error card
        Rectangle {
            visible: root.isError
            width: parent.width
            height: visible ? errRow.implicitHeight + 24 : 0
            radius: 12
            color: Theme.dangerSoft
            border.color: Qt.rgba(0.94, 0.48, 0.48, 0.35)
            RowLayout {
                id: errRow
                x: 14
                y: 12
                width: parent.width - 28
                spacing: 12
                Text {
                    Layout.alignment: Qt.AlignTop
                    topPadding: 2
                    text: Theme.ic.warning
                    font.family: Theme.icons
                    font.pixelSize: 15
                    color: Theme.danger
                }
                Text {
                    Layout.fillWidth: true
                    text: root.content
                    wrapMode: Text.Wrap
                    color: Theme.text
                    font.family: Theme.sans
                    font.pixelSize: 14
                }
                PillButton {
                    visible: aiClient.canRetry
                    enabled: !aiClient.busy
                    text: "Повторить"
                    glyph: Theme.ic.refresh
                    onClicked: root.retryRequested()
                }
            }
        }

        // ---------- actions
        Item {
            visible: !root.isError && !root.streaming && !root.editing && root.content !== ""
            width: parent.width
            height: visible ? 30 : 0
            opacity: 1
            Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
            Row {
                anchors.right: root.isUser ? parent.right : undefined
                anchors.left: root.isUser ? undefined : parent.left
                anchors.leftMargin: -6
                spacing: 2
                IconButton {
                    glyph: root.copied ? Theme.ic.check : Theme.ic.copy
                    glyphColor: root.copied ? Theme.success : Theme.textMuted
                    tip: root.copied ? "Скопировано" : "Копировать"
                    onClicked: {
                        uiBridge.copyToClipboard(root.content)
                        root.copied = true
                        copyTimer.restart()
                    }
                }
                IconButton {
                    visible: root.isUser
                    enabled: !aiClient.busy
                    glyph: Theme.ic.edit
                    tip: "Изменить и отправить заново"
                    onClicked: {
                        editArea.text = root.content
                        root.editing = true
                        editArea.forceActiveFocus()
                        editArea.cursorPosition = editArea.length
                    }
                }
                IconButton {
                    visible: root.isAnswer && root.isLast && aiClient.canRetry
                    enabled: !aiClient.busy
                    glyph: Theme.ic.refresh
                    tip: "Сгенерировать заново"
                    onClicked: root.retryRequested()
                }
            }
            Text {
                visible: root.isAnswer && root.metrics !== ""
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                text: root.metrics
                color: Theme.textDim
                font.family: Theme.sans
                font.pixelSize: 11
            }
        }
    }
}
