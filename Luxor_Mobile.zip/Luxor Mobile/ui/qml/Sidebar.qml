import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Left sidebar: new chat, search, chats grouped by day, profile.
// Collapses to a 56-px icon rail (MainWindow animates the width).
Rectangle {
    id: root
    property bool collapsed: false
    property string query: ""
    property string renamingId: ""
    property string menuId: ""
    property string menuTitle: ""
    signal newChat()
    signal openConversation(string id)
    signal openSettings()
    signal toggleCollapse()

    color: Theme.sidebar
    clip: true

    function focusSearch() {
        if (collapsed) toggleCollapse()
        searchField.forceActiveFocus()
        searchField.selectAll()
    }
    function rebuild() {
        var q = query.trim()
        var src = q !== "" ? aiClient.searchConversations(q) : aiClient.conversations
        convs.clear()
        for (var i = 0; i < src.length; ++i) {
            var c = src[i]
            var t = c.updatedAt ? c.updatedAt : 0
            convs.append({
                cid: String(c.id),
                title: c.title ? c.title : "Без названия",
                grp: q !== "" ? "Результаты поиска" : Theme.dayGroup(t),
                snippet: c.snippet ? c.snippet : ""
            })
        }
    }
    function openMenu(item, cid, title) {
        menuId = cid
        menuTitle = title
        var p = item.mapToItem(root, 0, item.height)
        rowMenu.x = Math.min(p.x, root.width - rowMenu.width - 8)
        rowMenu.y = Math.min(p.y + 4, root.height - rowMenu.height - 8)
        rowMenu.open()
    }
    function commitRename(cid, text) {
        var t = text.trim()
        if (t !== "") aiClient.renameConversation(cid, t)
        renamingId = ""
    }

    ListModel { id: convs }
    Timer { id: searchDebounce; interval: 200; onTriggered: root.rebuild() }
    onQueryChanged: searchDebounce.restart()
    Connections {
        target: aiClient
        function onConversationsChanged() { root.rebuild() }
    }
    Component.onCompleted: rebuild()

    // ================= expanded
    Item {
        id: full
        width: 264
        height: parent.height
        opacity: root.collapsed ? 0 : 1
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }

        ColumnLayout {
            anchors.fill: parent
            spacing: 0

            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 52
                Layout.leftMargin: 16
                Layout.rightMargin: 8
                spacing: 10
                SparkLogo { size: 22 }
                Text {
                    text: "Luxor"
                    font.family: Theme.serif
                    font.pixelSize: 19
                    color: Theme.text
                }
                Item { Layout.fillWidth: true }
                IconButton {
                    glyph: Theme.ic.menu
                    tip: "Свернуть панель (Ctrl+B)"
                    onClicked: root.toggleCollapse()
                }
            }

            Rectangle {                          // new chat
                Layout.fillWidth: true
                Layout.leftMargin: 10
                Layout.rightMargin: 10
                Layout.preferredHeight: 38
                radius: 10
                color: ncHover.hovered ? Theme.surfaceHover : "transparent"
                Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 10
                    anchors.rightMargin: 10
                    spacing: 10
                    Rectangle {
                        width: 22
                        height: 22
                        radius: 11
                        color: Theme.accentSoft
                        Text {
                            anchors.centerIn: parent
                            text: Theme.ic.add
                            font.family: Theme.icons
                            font.pixelSize: 11
                            color: Theme.accent
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        text: "Новый чат"
                        font.family: Theme.sans
                        font.pixelSize: 14
                        color: Theme.text
                    }
                    Text {
                        text: "Ctrl+N"
                        font.family: Theme.sans
                        font.pixelSize: 11
                        color: Theme.textDim
                        visible: ncHover.hovered
                    }
                }
                HoverHandler { id: ncHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: root.newChat() }
            }

            Rectangle {                          // search
                Layout.fillWidth: true
                Layout.leftMargin: 10
                Layout.rightMargin: 10
                Layout.topMargin: 6
                Layout.preferredHeight: 36
                radius: 10
                color: Theme.bg
                border.color: searchField.activeFocus ? Theme.accent : Theme.borderSoft
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 10
                    anchors.rightMargin: 4
                    spacing: 6
                    Text {
                        text: Theme.ic.search
                        font.family: Theme.icons
                        font.pixelSize: 12
                        color: Theme.textDim
                    }
                    TextField {
                        id: searchField
                        Layout.fillWidth: true
                        placeholderText: "Поиск по чатам"
                        placeholderTextColor: Theme.textDim
                        color: Theme.text
                        selectionColor: Theme.selection
                        selectedTextColor: Theme.text
                        font.family: Theme.sans
                        font.pixelSize: 13
                        background: null
                        leftPadding: 0
                        selectByMouse: true
                        onTextChanged: root.query = text
                        Keys.onEscapePressed: { text = ""; focus = false }
                    }
                    IconButton {
                        visible: searchField.text !== ""
                        width: 26
                        height: 26
                        glyph: Theme.ic.close
                        glyphSize: 10
                        tip: "Очистить"
                        onClicked: searchField.text = ""
                    }
                }
            }

            ListView {
                id: chatList
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.topMargin: 6
                model: convs
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
                section.property: "grp"
                section.criteria: ViewSection.FullString
                section.delegate: Item {
                    width: chatList.width
                    height: 30
                    Text {
                        x: 18
                        anchors.bottom: parent.bottom
                        anchors.bottomMargin: 6
                        text: section
                        color: Theme.textDim
                        font.family: Theme.sans
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                    }
                }
                delegate: Item {
                    id: rowItem
                    readonly property bool current: model.cid === aiClient.currentConversationId
                    readonly property bool renaming: root.renamingId === model.cid
                    width: chatList.width
                    height: model.snippet !== "" ? 60 : 48
                    Rectangle {
                        anchors.fill: parent
                        anchors.leftMargin: 8
                        anchors.rightMargin: 8
                        anchors.topMargin: 1
                        anchors.bottomMargin: 1
                        radius: 8
                        color: rowItem.current ? Theme.surfaceActive : (rowHover.hovered ? Theme.surfaceHover : "transparent")
                        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                        HoverHandler { id: rowHover; cursorShape: Qt.PointingHandCursor }
                        TapHandler {
                            enabled: !rowItem.renaming
                            acceptedButtons: Qt.LeftButton
                            onTapped: root.openConversation(model.cid)
                        }
                        TapHandler {            // long press = row menu on touch screens
                            enabled: !rowItem.renaming
                            onLongPressed: root.openMenu(moreBtn, model.cid, model.title)
                        }
                        TapHandler {
                            enabled: !rowItem.renaming
                            acceptedButtons: Qt.RightButton
                            onTapped: root.openMenu(moreBtn, model.cid, model.title)
                        }
                        Column {
                            visible: !rowItem.renaming
                            anchors.left: parent.left
                            anchors.leftMargin: 10
                            anchors.right: moreBtn.left
                            anchors.rightMargin: 4
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 2
                            Text {
                                width: parent.width
                                text: model.title
                                elide: Text.ElideRight
                                color: rowItem.current || rowHover.hovered ? Theme.text : Theme.textMuted
                                font.family: Theme.sans
                                font.pixelSize: 13
                            }
                            Text {
                                visible: model.snippet !== ""
                                width: parent.width
                                text: model.snippet
                                elide: Text.ElideRight
                                color: Theme.textDim
                                font.family: Theme.sans
                                font.pixelSize: 11
                            }
                        }
                        TextField {
                            id: renameField
                            visible: rowItem.renaming
                            anchors.fill: parent
                            anchors.margins: 3
                            color: Theme.text
                            selectionColor: Theme.selection
                            selectedTextColor: Theme.text
                            font.family: Theme.sans
                            font.pixelSize: 13
                            selectByMouse: true
                            background: Rectangle { radius: 6; color: Theme.bg; border.color: Theme.accent }
                            onVisibleChanged: if (visible) { text = model.title; forceActiveFocus(); selectAll() }
                            onAccepted: root.commitRename(model.cid, text)
                            Keys.onEscapePressed: root.renamingId = ""
                            onActiveFocusChanged: if (!activeFocus && rowItem.renaming) root.commitRename(model.cid, text)
                        }
                        IconButton {
                            id: moreBtn
                            anchors.right: parent.right
                            anchors.rightMargin: 4
                            anchors.verticalCenter: parent.verticalCenter
                            width: 40
                            height: 40
                            visible: !rowItem.renaming
                            opacity: 1
                            glyph: Theme.ic.more
                            glyphSize: 12
                            tip: "Действия"
                            onClicked: root.openMenu(moreBtn, model.cid, model.title)
                        }
                    }
                }
            }

            Text {
                visible: convs.count === 0
                Layout.fillWidth: true
                Layout.bottomMargin: 20
                horizontalAlignment: Text.AlignHCenter
                text: root.query.trim() !== "" ? "Ничего не найдено" : "Здесь появятся ваши чаты"
                color: Theme.textDim
                font.family: Theme.sans
                font.pixelSize: 13
            }

            Rectangle { Layout.fillWidth: true; height: 1; color: Theme.borderSoft }

            RowLayout {                          // profile
                Layout.fillWidth: true
                Layout.margins: 10
                spacing: 10
                Rectangle {
                    width: 32
                    height: 32
                    radius: 16
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: Theme.accent }
                        GradientStop { position: 1.0; color: Theme.accent2 }
                    }
                    Text {
                        anchors.centerIn: parent
                        text: appSettings.userName !== "" ? appSettings.userName.charAt(0).toUpperCase() : "?"
                        color: "#FFFFFF"
                        font.family: Theme.sans
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                    }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Text {
                        Layout.fillWidth: true
                        text: appSettings.userName !== "" ? appSettings.userName : "Гость"
                        elide: Text.ElideRight
                        color: Theme.text
                        font.family: Theme.sans
                        font.pixelSize: 13
                    }
                    Text {
                        Layout.fillWidth: true
                        text: "Luxor Mobile " + uiBridge.appVersion
                        elide: Text.ElideRight
                        color: Theme.textDim
                        font.family: Theme.sans
                        font.pixelSize: 11
                    }
                }
                IconButton { glyph: Theme.ic.settings; tip: "Настройки"; onClicked: root.openSettings() }
            }
        }
    }

    // ================= collapsed rail
    Item {
        width: 56
        height: parent.height
        opacity: root.collapsed ? 1 : 0
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 10
            spacing: 6
            IconButton { glyph: Theme.ic.menu; tip: "Развернуть панель (Ctrl+B)"; onClicked: root.toggleCollapse() }
            IconButton { glyph: Theme.ic.add; tip: "Новый чат (Ctrl+N)"; onClicked: root.newChat() }
            IconButton { glyph: Theme.ic.search; tip: "Поиск по чатам (Ctrl+K)"; onClicked: root.focusSearch() }
        }
        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 12
            spacing: 6
            IconButton { glyph: Theme.ic.settings; tip: "Настройки"; onClicked: root.openSettings() }
        }
    }

    Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.borderSoft }

    // ================= row menu + delete confirmation
    Popup {
        id: rowMenu
        width: 190
        padding: 6
        background: Rectangle { radius: 12; color: Theme.surface; border.color: Theme.border }
        enter: Transition { NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        contentItem: Column {
            spacing: 2
            Repeater {
                model: [ { glyph: Theme.ic.rename, label: "Переименовать", act: "rename" },
                         { glyph: Theme.ic.del, label: "Удалить", act: "delete" } ]
                delegate: Rectangle {
                    width: 178
                    height: 34
                    radius: 8
                    color: mh.hovered ? (modelData.act === "delete" ? Theme.dangerSoft : Theme.surfaceHover) : "transparent"
                    Row {
                        anchors.verticalCenter: parent.verticalCenter
                        x: 10
                        spacing: 10
                        Text {
                            text: modelData.glyph
                            font.family: Theme.icons
                            font.pixelSize: 12
                            color: modelData.act === "delete" ? Theme.danger : Theme.textMuted
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: modelData.label
                            font.family: Theme.sans
                            font.pixelSize: 13
                            color: modelData.act === "delete" ? Theme.danger : Theme.text
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    HoverHandler { id: mh; cursorShape: Qt.PointingHandCursor }
                    TapHandler {
                        onTapped: {
                            rowMenu.close()
                            if (modelData.act === "rename") root.renamingId = root.menuId
                            else deleteDialog.open()
                        }
                    }
                }
            }
        }
    }

    Popup {
        id: deleteDialog
        parent: Overlay.overlay
        anchors.centerIn: parent
        width: 400
        modal: true
        dim: true
        padding: 22
        Overlay.modal: Rectangle { color: "#A0000000" }
        background: Rectangle { radius: 16; color: Theme.surface; border.color: Theme.border }
        contentItem: ColumnLayout {
            spacing: 12
            Text {
                text: "Удалить чат?"
                font.family: Theme.serif
                font.pixelSize: 20
                color: Theme.text
            }
            Text {
                Layout.fillWidth: true
                text: "«" + root.menuTitle + "» будет удалён без возможности восстановления."
                wrapMode: Text.Wrap
                font.family: Theme.sans
                font.pixelSize: 14
                color: Theme.textMuted
            }
            RowLayout {
                Layout.alignment: Qt.AlignRight
                Layout.topMargin: 6
                spacing: 8
                PillButton { text: "Отмена"; onClicked: deleteDialog.close() }
                PillButton {
                    text: "Удалить"
                    danger: true
                    onClicked: {
                        aiClient.deleteConversation(root.menuId)
                        deleteDialog.close()
                    }
                }
            }
        }
    }
}
