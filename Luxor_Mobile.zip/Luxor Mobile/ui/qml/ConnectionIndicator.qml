import QtQuick
import QtQuick.Controls.Basic
import "Theme.js" as Theme

// Model-server connection state: no key / checking / connected / no connection. Click to re-check.
Item {
    id: root
    signal openSettings()
    property bool checking: false
    property int result: -1                 // -1 not checked, 0 failed, 1 ok
    property string info: ""
    readonly property string mode: !aiClient.hasApiKey ? "nokey"
                                  : (checking ? "checking" : (result === 1 ? "ok" : (result === 0 ? "error" : "unknown")))
    readonly property color dotColor: mode === "ok" ? Theme.success
                                     : (mode === "checking" ? Theme.warning : (mode === "unknown" ? Theme.textDim : Theme.danger))
    readonly property string caption: mode === "ok" ? "Подключено"
                                     : mode === "checking" ? "Проверка…"
                                     : mode === "error" ? "Нет связи"
                                     : mode === "nokey" ? "Нет ключа" : "Не проверено"

    implicitWidth: row.implicitWidth + 22
    implicitHeight: 28

    function check() {
        if (!aiClient.hasApiKey) { root.openSettings(); return }
        if (checking) return
        checking = true
        aiClient.probeModels()
    }

    Connections {
        target: aiClient
        function onModelsProbed(ok, details) {
            root.checking = false
            root.result = ok ? 1 : 0
            root.info = details
        }
        function onApiKeyChanged() {
            root.result = -1
            root.info = ""
            if (aiClient.hasApiKey) autoTimer.restart()
        }
        function onFinished(success, errorMessage) { if (success) root.result = 1 }
    }
    Timer { id: autoTimer; interval: 900; onTriggered: if (aiClient.hasApiKey && !root.checking && root.result === -1) root.check() }
    Component.onCompleted: if (aiClient.hasApiKey) autoTimer.start()

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: ma.containsMouse ? Theme.surfaceHover : "transparent"
        border.color: Theme.borderSoft
        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
    }
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 8
        Rectangle {
            width: 8; height: 8; radius: 4
            anchors.verticalCenter: parent.verticalCenter
            color: root.dotColor
            Behavior on color { ColorAnimation { duration: Theme.d(Theme.normal, appSettings.animationsEnabled) } }
            SequentialAnimation on opacity {
                running: root.mode === "checking" && appSettings.animationsEnabled
                loops: Animation.Infinite
                alwaysRunToEnd: true
                NumberAnimation { to: 0.3; duration: 500; easing.type: Easing.InOutSine }
                NumberAnimation { to: 1.0; duration: 500; easing.type: Easing.InOutSine }
            }
        }
        Text {
            text: root.caption
            color: Theme.textMuted
            font.family: Theme.sans
            font.pixelSize: 12
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.check()
    }
    ToolTip.visible: ma.containsMouse
    ToolTip.delay: 500
    ToolTip.text: root.mode === "nokey" ? "Добавьте API-ключ в настройках"
                 : (root.info !== "" ? root.info + "\nНажмите, чтобы проверить снова" : "Нажмите, чтобы проверить подключение")
}
