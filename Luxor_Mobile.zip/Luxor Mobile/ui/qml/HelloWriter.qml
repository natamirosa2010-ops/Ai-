import QtQuick
import "Theme.js" as Theme
import "HelloPath.js" as HelloPath

// Draws the hand-lettered "Hello" like a pen (HelloPath.js, generated from design/hello.py).
// progress 0..1 maps to arc length, with a short "pen lift" between strokes and a glowing tip.
Item {
    id: root
    property real progress: 0
    property color colorStart: "#BFDCFF"
    property color colorEnd: Theme.accent2
    property bool penGlow: true
    readonly property real s: width / HelloPath.width
    signal drawn()

    implicitWidth: 320
    implicitHeight: Math.round(width * HelloPath.height / HelloPath.width)
    height: implicitHeight

    property var _lens: []
    property real _total: 1
    readonly property real _gap: 70           // pen-lift distance between strokes, design units

    function draw(duration) {
        anim.stop();
        progress = 0;
        if (duration <= 0) { progress = 1; drawn(); return; }
        anim.duration = duration;
        anim.start();
    }
    function finish() { anim.stop(); progress = 1; }
    function clear() { anim.stop(); progress = 0; }

    NumberAnimation {
        id: anim
        target: root
        property: "progress"
        from: 0
        to: 1
        duration: 2000
        easing.type: Easing.InOutSine
        onFinished: root.drawn()
    }

    Component.onCompleted: {
        var lens = [];
        var total = 0;
        for (var k = 0; k < HelloPath.strokes.length; ++k) {
            var p = HelloPath.strokes[k];
            var acc = [0];
            var len = 0;
            for (var i = 2; i + 1 < p.length; i += 2) {
                var dx = p[i] - p[i - 2];
                var dy = p[i + 1] - p[i - 1];
                len += Math.sqrt(dx * dx + dy * dy);
                acc.push(len);
            }
            lens.push(acc);
            total += len;
        }
        total += _gap * (HelloPath.strokes.length - 1);
        _lens = lens;
        _total = total > 0 ? total : 1;
        canvas.requestPaint();
    }
    onProgressChanged: canvas.requestPaint()
    onWidthChanged: canvas.requestPaint()

    Canvas {
        id: canvas
        anchors.fill: parent
        onPaint: {
            var ctx = getContext("2d");
            ctx.reset();
            ctx.clearRect(0, 0, width, height);
            if (root._lens.length === 0 || root.progress <= 0) return;
            var s = root.s;
            var budget = root.progress * root._total;
            var grad = ctx.createLinearGradient(0, 0, width, 0);
            grad.addColorStop(0, root.colorStart);
            grad.addColorStop(1, root.colorEnd);
            ctx.strokeStyle = grad;
            ctx.lineWidth = HelloPath.strokeWidth * s;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            var tipX = -1;
            var tipY = -1;
            for (var k = 0; k < HelloPath.strokes.length && budget > 0; ++k) {
                var p = HelloPath.strokes[k];
                var acc = root._lens[k];
                var n = acc.length;
                ctx.beginPath();
                ctx.moveTo(p[0] * s, p[1] * s);
                var j = 1;
                while (j < n && acc[j] <= budget) {
                    ctx.lineTo(p[2 * j] * s, p[2 * j + 1] * s);
                    ++j;
                }
                if (j < n) {
                    var seg = acc[j] - acc[j - 1];
                    var t = seg > 0 ? (budget - acc[j - 1]) / seg : 0;
                    var x = p[2 * (j - 1)] + (p[2 * j] - p[2 * (j - 1)]) * t;
                    var y = p[2 * (j - 1) + 1] + (p[2 * j + 1] - p[2 * (j - 1) + 1]) * t;
                    ctx.lineTo(x * s, y * s);
                    tipX = x * s;
                    tipY = y * s;
                }
                ctx.stroke();
                budget -= acc[n - 1] + root._gap;
            }
            if (root.penGlow && tipX >= 0 && root.progress < 1) {
                ctx.save();
                ctx.shadowColor = "rgba(170, 210, 255, 0.95)";
                ctx.shadowBlur = 10 + 14 * s;
                ctx.fillStyle = "#E4F0FF";
                ctx.beginPath();
                ctx.arc(tipX, tipY, Math.max(1.5, HelloPath.strokeWidth * s * 0.55), 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
        }
    }
}
