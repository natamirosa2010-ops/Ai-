.pragma library
// Luxor Studio design tokens (docs/DESIGN.md). Dark graphite, soft blue accents.

// ---- palette
var bg = "#232326";
var sidebar = "#1C1C1F";
var surface = "#2C2C30";
var surfaceHover = "#34343A";
var surfaceActive = "#3B3B42";
var border = "#3A3A40";
var borderSoft = "#303035";
var text = "#ECECEE";
var textMuted = "#9A9AA3";
var textDim = "#6E6E78";
var accent = "#7AB4FF";
var accent2 = "#4F86F7";
var accentSoft = "#2A3550";
var accentText = "#CFE3FF";
var danger = "#F07A7A";
var dangerSoft = "#3A2729";
var success = "#7AD9A0";
var warning = "#E6C877";
var userBubble = "#34343A";
var codeBg = "#19191C";
var codeHeader = "#242428";
var codeText = "#D7DAE0";
var selection = "#355286";
var sparkLight = "#CFE6FF";
var sparkMid = "#7AB4FF";
var sparkDeep = "#4F86F7";

// ---- fonts
var serif = "serif";
var sans = "sans-serif";
var mono = "monospace";
var icons = "sans-serif";   // system font + Noto symbols fallback

// ---- Segoe MDL2 Assets glyphs
var ic = {
    menu: "\u2630", add: "+", close: "\u2715", more: "\u22EF", settings: "\u2699",
    pin: "\u25C9", unpin: "\u25CB", stop: "\u25A0", search: "\uD83D\uDD0D", send: "\u2191",
    refresh: "\u21BB", chevronDown: "\u25BE", chevronUp: "\u25B4", edit: "\u270E",
    check: "\u2713", up: "\u2191", down: "\u2193", del: "\uD83D\uDDD1", back: "\u2190",
    chevronLeft: "\u2039", chevronRight: "\u203A", person: "\u263A", warning: "\u26A0",
    history: "\u25F7", clock: "\u25F7", rename: "\u270E", chat: "\uD83D\uDCAC", copy: "\u2750",
    tools: "\u2692", code: "</>", info: "\u24D8", activity: "\u26A1", shield: "\u26E8",
    bulb: "\uD83D\uDCA1", globe: "\uD83C\uDF10", terminal: ">_", folder: "\uD83D\uDCC1", dockRight: "\u25AF"
};

// ---- motion (ms); OutCubic for appearing, InOutCubic for moving
var fast = 150;
var normal = 250;
var slow = 350;

/** Duration honouring the "animations" setting (0 = instant). */
function d(ms, enabled) { return enabled ? ms : 0; }

// ---- thinking modes (names agreed with the user)
var modeNames = ["Слабый", "Средний", "Высокий", "Ультра"];
var modeHints = [
    "Быстрые короткие ответы, малый контекст",
    "Баланс скорости и полноты",
    "План, альтернативы и допущения, больше контекста",
    "По этапам + отдельная перепроверка ответа"
];

function greeting(hour) {
    if (hour >= 5 && hour < 12) return "Доброе утро";
    if (hour >= 12 && hour < 18) return "Добрый день";
    if (hour >= 18 && hour < 23) return "Добрый вечер";
    return "Доброй ночи";
}

function _dayStart() {
    var n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
}

/** Sidebar group for a timestamp (ms since epoch). */
function dayGroup(ms) {
    if (!ms) return "Ранее";
    var start = _dayStart();
    if (ms >= start) return "Сегодня";
    if (ms >= start - 86400000) return "Вчера";
    if (ms >= start - 6 * 86400000) return "Последние 7 дней";
    return "Ранее";
}

function _pad(n) { return n < 10 ? "0" + n : "" + n; }

/** Short label: "14:05" today, "вчера", otherwise "09.11". */
function timeLabel(ms) {
    if (!ms) return "";
    var t = new Date(ms);
    var start = _dayStart();
    if (ms >= start) return _pad(t.getHours()) + ":" + _pad(t.getMinutes());
    if (ms >= start - 86400000) return "вчера";
    return _pad(t.getDate()) + "." + _pad(t.getMonth() + 1);
}

function clockNow() {
    var t = new Date();
    return _pad(t.getHours()) + ":" + _pad(t.getMinutes()) + ":" + _pad(t.getSeconds());
}

/** Display name of a model id from aiClient.availableModels. */
function modelName(list, id) {
    if (list) {
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === id) return list[i].name;
    }
    return id;
}
