import QtQuick
import QtQuick.Controls.Basic
import "Theme.js" as Theme

// Fenced code block: language label, copy button, horizontal scrolling, selectable text.
Rectangle {
    id: root
    property string code: ""
    property string lang: ""
    property bool closed: true
    property bool copied: false

    implicitHeight: header.height + body.height
    radius: 10
    color: Theme.codeBg
    border.color: Theme.borderSoft
    clip: true

    Rectangle {
        id: header
        width: parent.width
        height: 34
        radius: 10
        color: Theme.codeHeader
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 10; color: Theme.codeHeader }
        Text {
            anchors.left: parent.left
            anchors.leftMargin: 14
            anchors.verticalCenter: parent.verticalCenter
            text: root.lang !== "" ? root.lang : "код"
            color: Theme.textMuted
            font.family: Theme.mono
            font.pixelSize: 12
        }
        IconButton {
            anchors.right: parent.right
            anchors.rightMargin: 6
            anchors.verticalCenter: parent.verticalCenter
            height: 26
            glyph: root.copied ? Theme.ic.check : Theme.ic.copy
            label: root.copied ? "Скопировано" : "Копировать"
            glyphSize: 12
            labelSize: 12
            glyphColor: root.copied ? Theme.success : Theme.textMuted
            onClicked: {
                uiBridge.copyToClipboard(root.code)
                root.copied = true
                copiedTimer.restart()
            }
        }
    }

    Flickable {
        id: body
        anchors.top: header.bottom
        width: parent.width
        height: codeText.implicitHeight + 24 + (hbar.visible ? 8 : 0)
        contentWidth: Math.max(width, codeText.implicitWidth + 28)
        contentHeight: height
        interactive: false          // keep mouse drag for text selection; scroll with the bar or Shift+wheel
        clip: true
        TextEdit {
            id: codeText
            x: 14
            y: 12
            text: root.code
            readOnly: true
            selectByMouse: true
            textFormat: TextEdit.PlainText
            wrapMode: TextEdit.NoWrap
            color: Theme.codeText
            selectionColor: Theme.selection
            selectedTextColor: Theme.text
            font.family: Theme.mono
            font.pixelSize: 13
        }
        WheelHandler {
            acceptedModifiers: Qt.ShiftModifier
            onWheel: function (e) {
                var dx = e.angleDelta.y !== 0 ? e.angleDelta.y : e.angleDelta.x
                body.contentX = Math.max(0, Math.min(body.contentWidth - body.width, body.contentX - dx))
            }
        }
        ScrollBar.horizontal: ScrollBar {
            id: hbar
            visible: body.contentWidth > body.width + 1
            policy: ScrollBar.AlwaysOn
        }
    }
    Timer { id: copiedTimer; interval: 1600; onTriggered: root.copied = false }
}
