import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme

// Phone layout: one screen at a time. Chat list lives in a left drawer,
// "Активность / Источники" in a right drawer, Settings opens full screen.
ApplicationWindow {
    id: win
    width: 412          // desktop preview size; on a phone the window fills the screen
    height: 860
    visible: true
    title: "Luxor Mobile"
    color: Theme.bg
    font.family: Theme.sans

    property string view: "home"            // "home" | "chat"
    property string overlay: ""              // "" | "settings"

    function showHome() { overlay = ""; view = "home"; home.refresh() }
    function showChat() { overlay = ""; view = "chat" }
    function newChat() {
        if (aiClient.busy) aiClient.cancel()
        aiClient.newChat()
        menu.close()
        showHome()
    }
    function openConversation(id) {
        menu.close()
        if (id === aiClient.currentConversationId && aiClient.messageCount > 0) { showChat(); return }
        if (aiClient.busy) aiClient.cancel()
        if (aiClient.openConversation(id)) showChat()
    }
    function openSettings() { menu.close(); overlay = "settings" }
    function closeOverlay() { overlay = "" }
    function replayIntro() {
        appSettings.introSeen = false
        if (aiClient.busy) aiClient.cancel()
        aiClient.newChat()
        overlay = ""
        view = "home"
        home.start()
    }

    Connections {
        target: aiClient
        function onBusyChanged() { if (aiClient.busy && win.view !== "chat") win.view = "chat" }
        function onCurrentConversationChanged() {
            if (aiClient.messageCount > 0 || aiClient.busy) {
                win.view = "chat"
            } else if (win.view !== "home") {
                win.view = "home"
                home.refresh()
            }
        }
    }

    Component.onCompleted: {
        if (aiClient.messageCount > 0) view = "chat"
        else { view = "home"; home.start() }
    }

    // Android "Back": close drawers / settings first, then leave the app
    onClosing: function (close) {
        if (menu.opened) { menu.close(); close.accepted = false }
        else if (actDrawer.opened) { actDrawer.close(); close.accepted = false }
        else if (overlay !== "") { closeOverlay(); close.accepted = false }
    }

    Item {
        id: center
        anchors.fill: parent
        clip: true

        HomeScreen {
            id: home
            anchors.fill: parent
            opacity: win.view === "home" && win.overlay === "" ? 1 : 0
            visible: opacity > 0.01
            enabled: opacity > 0.99
            Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.normal, appSettings.animationsEnabled); easing.type: Easing.OutCubic } }
            onOpenSettings: win.openSettings()
            onOpenConversation: function (id) { win.openConversation(id) }
            onPromptSent: win.showChat()
        }

        ChatView {
            id: chat
            anchors.fill: parent
            opacity: win.view === "chat" && win.overlay === "" ? 1 : 0
            visible: opacity > 0.01
            enabled: opacity > 0.99
            Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.normal, appSettings.animationsEnabled); easing.type: Easing.OutCubic } }
            activityOpen: actDrawer.opened
            onToggleActivity: actDrawer.opened ? actDrawer.close() : actDrawer.open()
            onOpenSettings: win.openSettings()
            onOpenMenu: menu.open()
        }

        // menu button on the start screen (the chat has its own in the header)
        IconButton {
            x: 8
            y: 8
            z: 5
            visible: win.view === "home" && win.overlay === "" && !home.running
            glyph: Theme.ic.menu
            onClicked: menu.open()
        }

        Loader {
            id: overlayLoader
            anchors.fill: parent
            active: win.overlay === "settings"
            source: active ? "Settings.qml" : ""
            opacity: status === Loader.Ready ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.d(Theme.normal, appSettings.animationsEnabled); easing.type: Easing.OutCubic } }
        }
        Connections {
            target: overlayLoader.item
            ignoreUnknownSignals: true
            function onBack() { win.closeOverlay() }
            function onReplayIntro() { win.replayIntro() }
        }
    }

    Drawer {
        id: menu
        edge: Qt.LeftEdge
        width: Math.min(win.width * 0.86, 340)
        height: win.height
        background: Rectangle { color: Theme.sidebar }
        Overlay.modal: Rectangle { color: "#80000000" }
        onOpened: sidebar.rebuild()
        Sidebar {
            id: sidebar
            anchors.fill: parent
            collapsed: false
            onNewChat: win.newChat()
            onOpenConversation: function (id) { win.openConversation(id) }
            onOpenSettings: win.openSettings()
            onToggleCollapse: menu.close()
        }
    }

    Connections {                       // the panel's own "close" button
        target: activity
        function onOpenChanged() { if (!activity.open && actDrawer.opened) actDrawer.close() }
    }

    Drawer {
        id: actDrawer
        edge: Qt.RightEdge
        width: Math.min(win.width * 0.92, 380)
        height: win.height
        background: Rectangle { color: Theme.sidebar }
        Overlay.modal: Rectangle { color: "#80000000" }
        onClosed: if (activity.open) activity.hide()
        onAboutToShow: if (!activity.open) activity.show(false)
        ActivityPanel {
            id: activity
            anchors.fill: parent
        }
    }
}
