import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import "Theme.js" as Theme
import "Markdown.js" as Md

// Right panel "Активность / Источники".
// Opens by itself only for longer work (retries, checking results, tools) and hides
// about 4 s after the work ends — unless it is pinned or was opened by hand.
Rectangle {
    id: root
    property bool open: false
    property bool pinned: false
    property bool autoOpened: false
    property int tab: 0
    property string lastStatus: ""
    property string lastMetrics: ""
    color: Theme.sidebar
    clip: true

    function log(glyph, text, tone) {
        events.insert(0, { time: Theme.clockNow(), glyph: glyph, text: text, tone: tone ? tone : "muted" })
        while (events.count > 100) events.remove(events.count - 1)
    }
    function show(auto) {
        hideTimer.stop()
        if (auto === true) return          // phone: the panel opens only by hand, never over the answer
        if (!open) {
            open = true
            autoOpened = auto === true
        }
    }
    function hide() {
        open = false
        autoOpened = false
    }
    function toggle() { if (open) hide(); else show(false) }
    function addSource(url, title, seen) {
        if (seen[url] || !Md.isSafeLink(url)) return
        seen[url] = true
        var host = url.replace(/^https?:\/\//, "").split("/")[0].replace(/^www\./, "")
        sources.append({ url: url, title: title !== "" ? title : host, host: host })
    }
    function collectSources() {
        var list = aiClient.messagesForCurrent()
        var text = ""
        for (var i = list.length - 1; i >= 0; --i) {
            if (list[i].role === "assistant") { text = list[i].content ? list[i].content : ""; break }
        }
        sources.clear()
        var seen = {}
        var m
        var md = /\[([^\]\n]{1,200})\]\((https?:\/\/[^\s)]+)\)/g
        while ((m = md.exec(text)) !== null) addSource(m[2], m[1], seen)
        var bare = /https?:\/\/[^\s<>()\[\]"']+/g
        while ((m = bare.exec(text)) !== null) addSource(m[0].replace(/[.,;:!?]+$/, ""), "", seen)
    }

    ListModel { id: events }
    ListModel { id: sources }

    Connections {
        target: aiClient
        function onStatusTextChanged() {
            var s = aiClient.statusText
            if (s === "" || s === root.lastStatus) return
            root.lastStatus = s
            root.log(Theme.ic.activity, s.replace(/\.\.\.$/, "…"), "muted")
            if (/Повтор|Проверя/.test(s)) root.show(true)
        }
        function onBusyChanged() {
            if (aiClient.busy) {
                hideTimer.stop()
                root.lastStatus = ""
                root.lastMetrics = ""
            } else if (root.autoOpened && !root.pinned) {
                hideTimer.restart()
            }
        }
        function onMetricsUpdated(timeToFirstTokenMs, tokensPerSecond, estimated) {
            if (tokensPerSecond > 0)
                root.lastMetrics = "Первый токен " + (timeToFirstTokenMs / 1000).toFixed(1).replace(".", ",") + " с · "
                                 + (estimated ? "≈" : "") + Math.round(tokensPerSecond) + " ток/с"
        }
        function onFinished(success, errorMessage) {
            if (success) {
                root.log(Theme.ic.check, "Ответ получен", "ok")
                if (root.lastMetrics !== "") root.log(Theme.ic.clock, root.lastMetrics, "muted")
                Qt.callLater(root.collectSources)
            } else {
                root.log(Theme.ic.warning, errorMessage !== "" ? errorMessage : "Ответ не получен", "bad")
            }
        }
        function onCurrentConversationChanged() {
            sources.clear()
            Qt.callLater(root.collectSources)
        }
    }
    Timer {
        id: hideTimer
        interval: 4000
        onTriggered: {
            if (panelHover.hovered) { restart(); return }
            if (root.autoOpened && !root.pinned && !aiClient.busy) root.hide()
        }
    }
    HoverHandler { id: panelHover }

    component TabChip: Rectangle {
        id: tc
        property string text: ""
        property int count: -1
        property bool selected: false
        signal clicked()
        implicitWidth: tcRow.implicitWidth + 20
        implicitHeight: 28
        radius: 8
        color: selected ? Theme.surfaceActive : (tcHover.hovered ? Theme.surfaceHover : "transparent")
        Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
        Row {
            id: tcRow
            anchors.centerIn: parent
            spacing: 6
            Text {
                text: tc.text
                color: tc.selected ? Theme.text : Theme.textMuted
                font.family: Theme.sans
                font.pixelSize: 13
                anchors.verticalCenter: parent.verticalCenter
            }
            Rectangle {
                visible: tc.count > 0
                width: Math.max(18, cnt.implicitWidth + 8)
                height: 16
                radius: 8
                color: Theme.accentSoft
                anchors.verticalCenter: parent.verticalCenter
                Text {
                    id: cnt
                    anchors.centerIn: parent
                    text: tc.count
                    color: Theme.accentText
                    font.family: Theme.sans
                    font.pixelSize: 10
                }
            }
        }
        HoverHandler { id: tcHover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: tc.clicked() }
    }

    Item {
        anchors.right: parent.right               // fixed width: the panel slides in instead of squeezing
        width: 320
        height: parent.height
        Rectangle { width: 1; height: parent.height; color: Theme.borderSoft }

        ColumnLayout {
            anchors.fill: parent
            anchors.leftMargin: 1
            spacing: 0

            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 52
                Layout.leftMargin: 12
                Layout.rightMargin: 8
                spacing: 4
                TabChip { text: "Активность"; selected: root.tab === 0; onClicked: root.tab = 0 }
                TabChip { text: "Источники"; count: sources.count; selected: root.tab === 1; onClicked: root.tab = 1 }
                Item { Layout.fillWidth: true }
                IconButton {
                    glyph: root.pinned ? Theme.ic.unpin : Theme.ic.pin
                    active: root.pinned
                    tip: root.pinned ? "Открепить" : "Закрепить — не скрывать автоматически"
                    onClicked: {
                        root.pinned = !root.pinned
                        if (root.pinned) hideTimer.stop()
                    }
                }
                IconButton { glyph: Theme.ic.close; tip: "Скрыть"; onClicked: root.hide() }
            }
            Rectangle { Layout.fillWidth: true; height: 1; color: Theme.borderSoft }

            ThinkingIndicator {
                visible: aiClient.busy
                active: visible
                Layout.leftMargin: 16
                Layout.topMargin: 12
                Layout.bottomMargin: 4
                text: aiClient.statusText !== "" ? aiClient.statusText.replace(/\.\.\.$/, "…")
                                                 : "Думает…"
            }

            StackLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                currentIndex: root.tab

                Item {
                    ListView {
                        id: evList
                        anchors.fill: parent
                        anchors.margins: 8
                        model: events
                        spacing: 2
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
                        delegate: Item {
                            width: evList.width
                            height: evRow.implicitHeight + 12
                            RowLayout {
                                id: evRow
                                x: 6
                                y: 6
                                width: parent.width - 12
                                spacing: 10
                                Text {
                                    Layout.alignment: Qt.AlignTop
                                    topPadding: 2
                                    text: model.glyph
                                    font.family: Theme.icons
                                    font.pixelSize: 12
                                    color: model.tone === "ok" ? Theme.success : (model.tone === "bad" ? Theme.danger : Theme.textMuted)
                                }
                                Text {
                                    Layout.fillWidth: true
                                    text: model.text
                                    wrapMode: Text.Wrap
                                    color: Theme.text
                                    font.family: Theme.sans
                                    font.pixelSize: 13
                                }
                                Text {
                                    Layout.alignment: Qt.AlignTop
                                    topPadding: 2
                                    text: model.time
                                    color: Theme.textDim
                                    font.family: Theme.mono
                                    font.pixelSize: 11
                                }
                            }
                        }
                    }
                    Text {
                        visible: events.count === 0
                        anchors.centerIn: parent
                        width: parent.width - 48
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        text: "Здесь появятся статусы запросов и результаты инструментов"
                        color: Theme.textDim
                        font.family: Theme.sans
                        font.pixelSize: 13
                    }
                }

                Item {
                    ListView {
                        id: srcList
                        anchors.fill: parent
                        anchors.margins: 8
                        model: sources
                        spacing: 6
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
                        delegate: Rectangle {
                            width: srcList.width
                            height: sc.implicitHeight + 20
                            radius: 10
                            color: sh.hovered ? Theme.surfaceHover : Theme.surface
                            border.color: Theme.borderSoft
                            Behavior on color { ColorAnimation { duration: Theme.d(Theme.fast, appSettings.animationsEnabled) } }
                            Column {
                                id: sc
                                x: 12
                                y: 10
                                width: parent.width - 24
                                spacing: 3
                                Text {
                                    width: parent.width
                                    text: model.title
                                    elide: Text.ElideRight
                                    color: Theme.text
                                    font.family: Theme.sans
                                    font.pixelSize: 13
                                }
                                Text {
                                    width: parent.width
                                    text: model.host
                                    elide: Text.ElideRight
                                    color: Theme.accent
                                    font.family: Theme.sans
                                    font.pixelSize: 11
                                }
                            }
                            HoverHandler { id: sh; cursorShape: Qt.PointingHandCursor }
                            TapHandler { onTapped: Qt.openUrlExternally(model.url) }
                            ToolTip.visible: sh.hovered
                            ToolTip.delay: 600
                            ToolTip.text: model.url
                        }
                    }
                    Text {
                        visible: sources.count === 0
                        anchors.centerIn: parent
                        width: parent.width - 48
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        text: "Ссылки из последнего ответа появятся здесь"
                        color: Theme.textDim
                        font.family: Theme.sans
                        font.pixelSize: 13
                    }
                }
            }
        }
    }
}
