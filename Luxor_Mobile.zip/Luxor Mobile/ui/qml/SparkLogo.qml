import QtQuick
import "Theme.js" as Theme

// Four-ray "spark" logo with a soft blue gradient and glow.
// pulsing: gentle breathing (thinking indicator); spinning: slow rotation.
Item {
    id: root
    property real size: 48
    property bool glow: true
    property bool pulsing: false
    property bool spinning: false
    readonly property bool motion: appSettings.animationsEnabled

    width: size
    height: size
    implicitWidth: size
    implicitHeight: size

    Canvas {
        id: canvas
        anchors.centerIn: parent
        width: Math.ceil(root.size * 1.7)
        height: width
        onPaint: {
            var ctx = getContext("2d");
            ctx.reset();
            ctx.clearRect(0, 0, width, height);
            var cx = width / 2;
            var cy = height / 2;
            var r = root.size / 2;
            var k = r * 0.17;                 // waist of the rays
            var g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
            g.addColorStop(0.0, Theme.sparkLight);
            g.addColorStop(0.5, Theme.sparkMid);
            g.addColorStop(1.0, Theme.sparkDeep);
            ctx.fillStyle = g;
            if (root.glow) {
                ctx.shadowColor = "rgba(122, 180, 255, 0.55)";
                ctx.shadowBlur = Math.max(4, r * 0.55);
            }
            ctx.beginPath();
            ctx.moveTo(cx, cy - r);
            ctx.quadraticCurveTo(cx + k, cy - k, cx + r, cy);
            ctx.quadraticCurveTo(cx + k, cy + k, cx, cy + r);
            ctx.quadraticCurveTo(cx - k, cy + k, cx - r, cy);
            ctx.quadraticCurveTo(cx - k, cy - k, cx, cy - r);
            ctx.closePath();
            ctx.fill();
        }
        onWidthChanged: requestPaint()
        Component.onCompleted: requestPaint()
    }
    onGlowChanged: canvas.requestPaint()

    SequentialAnimation {
        id: pulseAnim
        loops: Animation.Infinite
        NumberAnimation { target: root; property: "scale"; to: 1.14; duration: 700; easing.type: Easing.InOutSine }
        NumberAnimation { target: root; property: "scale"; to: 1.0; duration: 700; easing.type: Easing.InOutSine }
    }
    RotationAnimation {
        id: spinAnim
        target: root
        property: "rotation"
        from: 0
        to: 360
        duration: 2600
        loops: Animation.Infinite
    }

    function _sync() {
        if (pulsing && motion) { if (!pulseAnim.running) pulseAnim.start(); }
        else { pulseAnim.stop(); root.scale = 1.0; }
        if (spinning && motion) { if (!spinAnim.running) spinAnim.start(); }
        else { spinAnim.stop(); root.rotation = 0; }
    }
    onPulsingChanged: _sync()
    onSpinningChanged: _sync()
    onMotionChanged: _sync()
    Component.onCompleted: _sync()
}
