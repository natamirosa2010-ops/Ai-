.pragma library
// Helpers for rendering assistant Markdown.
//  - split():    text / fenced-code segments, so code blocks get their own component
//                (language label + copy button). An unclosed fence (still streaming)
//                is treated as code up to the end.
//  - apply():    updates a ListModel in place so a streaming answer re-renders only
//                the block that changed.
//  - sanitize(): model output is untrusted: raw HTML is shown as text and images are
//                turned into plain links (no automatic remote loading). Inline code
//                spans are left untouched.

function split(src) {
    var out = [];
    if (!src) return out;
    var lines = src.split("\n");
    var buf = [];
    var inCode = false;
    var fence = "";
    var lang = "";

    function flushText() {
        var t = buf.join("\n");
        if (t.replace(/\s+/g, "") !== "") out.push({ kind: "text", lang: "", body: t, closed: true });
        buf = [];
    }

    for (var i = 0; i < lines.length; ++i) {
        var line = lines[i];
        if (!inCode) {
            var open = /^ {0,3}(`{3,}|~{3,})\s*([^`\s]*)/.exec(line);
            if (open) {
                flushText();
                inCode = true;
                fence = open[1];
                lang = open[2] || "";
                continue;
            }
            buf.push(line);
        } else {
            var close = /^ {0,3}(`{3,}|~{3,})\s*$/.exec(line);
            if (close && close[1].charAt(0) === fence.charAt(0) && close[1].length >= fence.length) {
                out.push({ kind: "code", lang: lang, body: buf.join("\n"), closed: true });
                buf = [];
                inCode = false;
                fence = "";
                lang = "";
                continue;
            }
            buf.push(line);
        }
    }
    if (inCode) out.push({ kind: "code", lang: lang, body: buf.join("\n"), closed: false });
    else flushText();
    return out;
}

function apply(model, segs) {
    var i;
    for (i = 0; i < segs.length; ++i) {
        var s = segs[i];
        if (i < model.count) {
            var row = model.get(i);
            if (row.kind !== s.kind) { model.set(i, s); continue; }
            if (row.body !== s.body) model.setProperty(i, "body", s.body);
            if (row.lang !== s.lang) model.setProperty(i, "lang", s.lang);
            if (row.closed !== s.closed) model.setProperty(i, "closed", s.closed);
        } else {
            model.append(s);
        }
    }
    while (model.count > segs.length) model.remove(model.count - 1);
}

function _clean(s) {
    return s.replace(/<(?=[A-Za-z\/!?])/g, "&lt;")
            .replace(/!\[([^\]]*)\]\(/g, "[\uD83D\uDDBC $1](");
}

function sanitize(t) {
    if (!t) return "";
    var out = "";
    var i = 0;
    while (i < t.length) {
        var tick = t.indexOf("`", i);
        if (tick < 0) { out += _clean(t.substring(i)); break; }
        out += _clean(t.substring(i, tick));
        var run = 0;
        while (tick + run < t.length && t.charAt(tick + run) === "`") run++;
        var ticks = t.substr(tick, run);
        var end = t.indexOf(ticks, tick + run);
        if (end < 0) { out += t.substring(tick); break; }
        out += t.substring(tick, end + run);
        i = end + run;
    }
    return out;
}

/** Only these schemes are opened from rendered answers. */
function isSafeLink(link) {
    return /^(https?:|mailto:)/i.test(link || "");
}
